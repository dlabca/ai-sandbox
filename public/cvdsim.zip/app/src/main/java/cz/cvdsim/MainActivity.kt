package cz.cvdsim

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.SurfaceTexture
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.Gravity
import android.view.Surface
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var glView: GLSurfaceView
    private lateinit var renderer: CvdRenderer
    private lateinit var label: TextView
    private var surfaceTex: SurfaceTexture? = null
    private var granted = false

    private val names = listOf(
        "Normální vidění", "Protanopie (chybí červená)", "Deuteranopie (chybí zelená)",
        "Tritanopie (chybí modrá)", "Achromatopsie (šedá)"
    )

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        granted = it
        tryStart()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        glView = GLSurfaceView(this)
        glView.setEGLContextClientVersion(2)
        renderer = CvdRenderer(glView) { st -> surfaceTex = st; tryStart() }
        glView.setRenderer(renderer)
        glView.renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY

        label = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(0x99000000.toInt())
            textSize = 18f
            setPadding(32, 24, 32, 24)
            gravity = Gravity.CENTER
        }
        updateLabel()

        val root = FrameLayout(this)
        root.addView(glView)
        root.addView(label, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        setContentView(root)

        glView.setOnClickListener {
            renderer.mode = (renderer.mode + 1) % names.size
            updateLabel()
            glView.requestRender()
        }

        granted = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted) permLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun updateLabel() { label.text = "${names[renderer.mode]}  (klepni = další)" }

    private fun tryStart() {
        val st = surfaceTex ?: return
        if (!granted) return
        val exec = ContextCompat.getMainExecutor(this)
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build()
            preview.setSurfaceProvider(exec) { req ->
                val size = req.resolution
                st.setDefaultBufferSize(size.width, size.height)
                renderer.bufW = size.width
                renderer.bufH = size.height
                req.setTransformationInfoListener(exec) { info -> renderer.rotation = info.rotationDegrees }
                val surface = Surface(st)
                req.provideSurface(surface, exec) { surface.release() }
            }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview)
        }, exec)
    }

    override fun onResume() { super.onResume(); glView.onResume() }
    override fun onPause() { glView.onPause(); super.onPause() }
}
