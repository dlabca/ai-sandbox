package cz.cvdsim

import android.graphics.SurfaceTexture
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class CvdRenderer(
    private val view: GLSurfaceView,
    private val onReady: (SurfaceTexture) -> Unit
) : GLSurfaceView.Renderer {

    @Volatile var mode = 1
    @Volatile var rotation = 90
    @Volatile var bufW = 1280
    @Volatile var bufH = 720

    private var vw = 1
    private var vh = 1
    private var prog = 0
    private var tex = 0
    private var st: SurfaceTexture? = null
    @Volatile private var newFrame = false

    private val texM = FloatArray(16).also { Matrix.setIdentityM(it, 0) }
    private val proj = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)

    private val quad = ByteBuffer.allocateDirect(32).order(ByteOrder.nativeOrder())
        .asFloatBuffer().apply { put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)); position(0) }

    // Machado et al. 2009, severity 1.0, row-major, v lineárním RGB
    private val mats = arrayOf(
        floatArrayOf(1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f),                                   // normální
        floatArrayOf(0.152286f, 1.052583f, -0.204868f, 0.114503f, 0.786281f, 0.099216f,
            -0.003882f, -0.048116f, 1.051998f),                                              // protanopie
        floatArrayOf(0.367322f, 0.860646f, -0.227968f, 0.280085f, 0.672501f, 0.047413f,
            -0.011820f, 0.042940f, 0.968881f),                                               // deuteranopie
        floatArrayOf(1.255528f, -0.076749f, -0.178779f, -0.078411f, 0.930809f, 0.147602f,
            0.004733f, 0.691367f, 0.303900f),                                                // tritanopie
        floatArrayOf(0.2126f, 0.7152f, 0.0722f, 0.2126f, 0.7152f, 0.0722f,
            0.2126f, 0.7152f, 0.0722f)                                                       // achromatopsie
    )

    private val vsh = """
        uniform mat4 uMvp;
        uniform mat4 uTex;
        attribute vec2 aPos;
        varying vec2 vUv;
        void main() {
            gl_Position = uMvp * vec4(aPos, 0.0, 1.0);
            vUv = (uTex * vec4(aPos * 0.5 + 0.5, 0.0, 1.0)).xy;
        }
    """.trimIndent()

    private val fsh = """
        #extension GL_OES_EGL_image_external : require
        precision mediump float;
        uniform samplerExternalOES uSampler;
        uniform mat3 uM;
        varying vec2 vUv;
        void main() {
            vec3 c = texture2D(uSampler, vUv).rgb;
            vec3 l = pow(c, vec3(2.2));
            l = clamp(uM * l, 0.0, 1.0);
            gl_FragColor = vec4(pow(l, vec3(1.0 / 2.2)), 1.0);
        }
    """.trimIndent()

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        return s
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        tex = t[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        val s = SurfaceTexture(tex)
        s.setOnFrameAvailableListener { newFrame = true; view.requestRender() }
        st = s

        prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, compile(GLES20.GL_VERTEX_SHADER, vsh))
        GLES20.glAttachShader(prog, compile(GLES20.GL_FRAGMENT_SHADER, fsh))
        GLES20.glLinkProgram(prog)

        view.post { onReady(s) }
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        vw = width; vh = height
        GLES20.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        val s = st ?: return
        if (newFrame) {
            newFrame = false
            s.updateTexImage()
            s.getTransformMatrix(texM)
        }
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)

        val rot = rotation
        val rw = if (rot % 180 == 0) bufW else bufH
        val rh = if (rot % 180 == 0) bufH else bufW
        val sc = maxOf(vw.toFloat() / rw, vh.toFloat() / rh) // cover (ořez)
        Matrix.orthoM(proj, 0, -vw / 2f, vw / 2f, -vh / 2f, vh / 2f, -1f, 1f)
        Matrix.setIdentityM(model, 0)
        Matrix.scaleM(model, 0, sc, sc, 1f)
        Matrix.rotateM(model, 0, -rot.toFloat(), 0f, 0f, 1f)
        Matrix.scaleM(model, 0, bufW / 2f, bufH / 2f, 1f)
        Matrix.multiplyMM(mvp, 0, proj, 0, model, 0)

        val m = mats[mode.coerceIn(0, mats.size - 1)]
        val mt = floatArrayOf(m[0], m[3], m[6], m[1], m[4], m[7], m[2], m[5], m[8])

        GLES20.glUseProgram(prog)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog, "uMvp"), 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog, "uTex"), 1, false, texM, 0)
        GLES20.glUniformMatrix3fv(GLES20.glGetUniformLocation(prog, "uM"), 1, false, mt, 0)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uSampler"), 0)
        val a = GLES20.glGetAttribLocation(prog, "aPos")
        GLES20.glEnableVertexAttribArray(a)
        GLES20.glVertexAttribPointer(a, 2, GLES20.GL_FLOAT, false, 8, quad)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(a)
    }
}
