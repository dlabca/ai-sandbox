package app.r2backup

import android.app.Application
import android.os.Build
import android.util.Log

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        L.init(this)
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            L.log("!!! CRASH ve vlákně ${t.name}:\n" + Log.getStackTraceString(e))
            old?.uncaughtException(t, e)
        }
        L.log("Aplikace spuštěna (v1.1, Android ${Build.VERSION.SDK_INT}, ${Build.MODEL})")
    }
}
