package app.r2backup

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.work.WorkInfo
import androidx.work.WorkManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val PRIMARY = 0xFF1F6FEB.toInt()
    private val BG = 0xFFF2F4F7.toInt()
    private val TEXT = 0xFF1B1F24.toInt()
    private val MUTED = 0xFF6B7280.toInt()
    private val ERR = 0xFFCF222E.toInt()
    private val WARN = 0xFFB35900.toInt()

    private val handler = Handler(Looper.getMainLooper())
    private val fields = LinkedHashMap<String, EditText>()
    private val intervals = listOf(15, 60, 360, 1440)
    private val intervalLabels = listOf("každých 15 minut", "každou hodinu", "každých 6 hodin", "jednou denně")

    private lateinit var titleTv: TextView
    private lateinit var detailTv: TextView
    private lateinit var bar: ProgressBar
    private lateinit var progTv: TextView
    private lateinit var curTv: TextView
    private lateinit var permTv: TextView
    private lateinit var nLib: TextView
    private lateinit var nDone: TextView
    private lateinit var nRem: TextView
    private lateinit var startBtn: Button
    private lateinit var stopBtn: Button
    private lateinit var settingsBody: LinearLayout
    private lateinit var wifi: CheckBox
    private lateinit var auto: CheckBox
    private lateinit var interval: Spinner
    private lateinit var logTv: TextView
    private lateinit var logScroll: ScrollView

    @Volatile private var queuedInfo = ""
    @Volatile private var libTotal = -1
    @Volatile private var bgBusy = false
    private var lastLibRefresh = 0L
    private var lastSent = 0L
    private var lastT = 0L
    private var speed = 0.0
    private var lastLogVer = -1L
    private var wasRunning = false
    private var tickN = 0

    // ---------- pomocné UI ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
    }

    private fun lp(w: Int = -1, h: Int = -2, top: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top) }

    private fun tv(parent: ViewGroup, s: String, size: Float = 14f, color: Int = TEXT, bold: Boolean = false, top: Int = 0): TextView {
        val t = TextView(this)
        t.text = s; t.textSize = size; t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        parent.addView(t, lp(top = top))
        return t
    }

    private fun card(parent: ViewGroup): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = shape(Color.WHITE, 16)
        c.setPadding(dp(16), dp(16), dp(16), dp(16))
        c.elevation = dp(2).toFloat()
        parent.addView(c, lp(top = 12))
        return c
    }

    private fun btn(label: String, primary: Boolean, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(if (primary) Color.WHITE else PRIMARY)
        b.background = shape(if (primary) PRIMARY else 0xFFE8F0FE.toInt(), 12)
        b.stateListAnimator = null
        b.setOnClickListener { safe(onClick) }
        return b
    }

    private fun addBtn(parent: ViewGroup, label: String, primary: Boolean = false, top: Int = 8, onClick: () -> Unit) {
        parent.addView(btn(label, primary, onClick), lp(top = top))
    }

    private fun field(parent: ViewGroup, key: String, label: String, hintText: String, secret: Boolean = false) {
        tv(parent, label, 12f, MUTED, top = 10)
        val e = EditText(this)
        e.inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        e.setSingleLine()
        e.hint = hintText
        e.textSize = 14f
        e.setPadding(dp(12), dp(10), dp(12), dp(10))
        e.background = shape(BG, 10)
        e.setText(Store.prefs(this).getString(key, ""))
        parent.addView(e, lp(top = 4))
        fields[key] = e
    }

    private fun counter(row: LinearLayout, label: String): TextView {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        val n = tv(col, "–", 20f, TEXT, true)
        n.gravity = Gravity.CENTER
        val l = tv(col, label, 11f, MUTED)
        l.gravity = Gravity.CENTER
        return n
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun safe(f: () -> Unit) {
        try { f() } catch (t: Throwable) {
            L.log("CHYBA UI:\n" + android.util.Log.getStackTraceString(t))
            toast("Chyba: ${t.message}")
        }
    }

    private fun fmt(b: Long): String = when {
        b >= 1L shl 30 -> "%.2f GB".format(b / 1073741824.0)
        b >= 1L shl 20 -> "%.1f MB".format(b / 1048576.0)
        b >= 1024 -> "%.0f kB".format(b / 1024.0)
        else -> "$b B"
    }

    // ---------- vytvoření UI ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        L.init(this)
        val p = Store.prefs(this)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(24), dp(16), dp(24))
        val sv = ScrollView(this)
        sv.setBackgroundColor(BG)
        sv.addView(col)
        setContentView(sv)

        tv(col, "R2 Záloha", 26f, TEXT, true)
        tv(col, "Fotky a videa → Cloudflare R2", 13f, MUTED)

        // --- Stav ---
        val st = card(col)
        titleTv = tv(st, "Nečinný", 18f, TEXT, true)
        detailTv = tv(st, "", 13f, MUTED, top = 2)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 1000
        st.addView(bar, lp(top = 12))
        progTv = tv(st, "", 13f, TEXT, top = 4)
        curTv = tv(st, "", 12f, MUTED, top = 2)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        st.addView(row, lp(top = 12))
        nLib = counter(row, "v galerii")
        nDone = counter(row, "zálohováno")
        nRem = counter(row, "zbývá")
        permTv = tv(st, "", 12f, ERR, top = 10)
        val br = LinearLayout(this)
        br.orientation = LinearLayout.HORIZONTAL
        startBtn = btn("Spustit zálohu", true) { start() }
        stopBtn = btn("Zastavit", false) { stop() }
        br.addView(startBtn, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })
        br.addView(stopBtn, LinearLayout.LayoutParams(0, -2, 1f))
        st.addView(br, lp(top = 12))

        // --- Nastavení ---
        val sc = card(col)
        val hdr = tv(sc, "Nastavení  ▾", 16f, TEXT, true)
        settingsBody = LinearLayout(this)
        settingsBody.orientation = LinearLayout.VERTICAL
        settingsBody.visibility = if (Store.load(this) == null) View.VISIBLE else View.GONE
        sc.addView(settingsBody, lp())
        hdr.setOnClickListener {
            settingsBody.visibility = if (settingsBody.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        field(settingsBody, "endpoint", "Endpoint", "https://<account-id>.r2.cloudflarestorage.com")
        field(settingsBody, "bucket", "Bucket", "název bucketu")
        field(settingsBody, "access", "Access Key ID", "")
        field(settingsBody, "secret", "Secret Access Key", "", true)
        wifi = CheckBox(this)
        wifi.text = "Zálohovat jen přes Wi-Fi"
        wifi.isChecked = p.getBoolean("wifi", true)
        settingsBody.addView(wifi, lp(top = 8))
        auto = CheckBox(this)
        auto.text = "Automatická záloha na pozadí"
        auto.isChecked = p.getBoolean("auto", false)
        settingsBody.addView(auto, lp())
        interval = Spinner(this)
        interval.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, intervalLabels)
        interval.setSelection(intervals.indexOf(p.getInt("interval", 60)).coerceAtLeast(0))
        settingsBody.addView(interval, lp())
        addBtn(settingsBody, "Uložit", true, 12) { save(); toast("Uloženo") }
        addBtn(settingsBody, "Test připojení") { save(); test() }
        addBtn(settingsBody, "Povolit přístup k fotkám") { askPermissions() }
        addBtn(settingsBody, "Nastavení aplikace v systému") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        addBtn(settingsBody, "Smazat historii (nahrát vše znovu)") {
            AlertDialog.Builder(this).setMessage("Smazat seznam už zálohovaných souborů? Při další záloze se vše nahraje znovu (přepíše stejné klíče).")
                .setPositiveButton("Smazat") { _, _ ->
                    Store.prefs(this).edit().remove("done").apply(); L.log("Historie zálohování smazána"); lastLibRefresh = 0
                }.setNegativeButton("Zrušit", null).show()
        }

        // --- Log ---
        val lc = card(col)
        tv(lc, "Log", 16f, TEXT, true)
        logScroll = ScrollView(this)
        logScroll.background = shape(0xFF111827.toInt(), 10)
        logScroll.setPadding(dp(8), dp(8), dp(8), dp(8))
        logScroll.setOnTouchListener { v, _ -> v.parent.requestDisallowInterceptTouchEvent(true); false }
        logTv = TextView(this)
        logTv.typeface = Typeface.MONOSPACE
        logTv.textSize = 10.5f
        logTv.setTextColor(0xFFD1D5DB.toInt())
        logScroll.addView(logTv)
        lc.addView(logScroll, lp(h = dp(280), top = 8))
        addBtn(lc, "Zkopírovat log", false, 8) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("log", L.tail(100_000)))
            toast("Log zkopírován")
        }
        addBtn(lc, "Smazat log") { L.clear() }
    }

    override fun onResume() {
        super.onResume()
        lastLibRefresh = 0
        handler.post(object : Runnable {
            override fun run() {
                try { render() } catch (t: Throwable) { L.log("render: $t") }
                handler.postDelayed(this, 500)
            }
        })
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacksAndMessages(null)
    }

    // ---------- akce ----------
    private fun save() {
        val e = Store.prefs(this).edit()
        fields.forEach { (k, v) -> e.putString(k, v.text.toString().trim()) }
        e.putBoolean("wifi", wifi.isChecked)
            .putBoolean("auto", auto.isChecked)
            .putInt("interval", intervals[interval.selectedItemPosition])
            .apply()
        Sync.applyAuto(this)
        L.log("Nastavení uloženo (wifi=${wifi.isChecked}, auto=${auto.isChecked}, interval=${intervals[interval.selectedItemPosition]} min)")
    }

    private fun start() {
        save()
        if (Store.load(this) == null) {
            toast("Nejdřív vyplň nastavení R2")
            settingsBody.visibility = View.VISIBLE
            return
        }
        if (Media.access(this) == 0) {
            toast("Nejdřív povol přístup k fotkám")
            askPermissions()
            return
        }
        if (SyncState.running) { toast("Záloha už běží"); return }
        SyncState.stop = false
        Store.setStatus(this, "Ve frontě…")
        L.log("Spuštěno uživatelem")
        Sync.runNow(this)
    }

    private fun stop() {
        if (SyncState.running) {
            SyncState.stop = true
            L.log("Požadavek na zastavení (dokončím aktuální krok)")
        } else {
            WorkManager.getInstance(this).cancelUniqueWork("now")
            Store.setStatus(this, "Zrušeno")
            L.log("Čekající záloha zrušena")
        }
    }

    private fun test() {
        val cfg = Store.load(this)
        if (cfg == null) { toast("Vyplň všechna pole"); return }
        Store.setStatus(this, "Testuji připojení…")
        Thread {
            val r = try { R2Client(cfg).check(); "Připojení k R2 OK ✓" } catch (e: Exception) { "Test selhal: ${e.message}" }
            L.log(r)
            Store.setStatus(this, r)
        }.start()
    }

    private fun askPermissions() {
        val l = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            l += Manifest.permission.READ_MEDIA_IMAGES
            l += Manifest.permission.READ_MEDIA_VIDEO
            if (Build.VERSION.SDK_INT >= 34) l += Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
            l += Manifest.permission.POST_NOTIFICATIONS
        } else l += Manifest.permission.READ_EXTERNAL_STORAGE
        if (Build.VERSION.SDK_INT >= 29) l += Manifest.permission.ACCESS_MEDIA_LOCATION
        requestPermissions(l.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val s = permissions.indices.joinToString(", ") {
            permissions[it].substringAfterLast('.') + "=" + (grantResults.getOrNull(it) == 0)
        }
        L.log("Oprávnění: $s")
        lastLibRefresh = 0
    }

    // ---------- pozadí ----------
    private fun bgRefresh() {
        if (bgBusy) return
        bgBusy = true
        Thread {
            try {
                val infos = WorkManager.getInstance(this).getWorkInfosForUniqueWork("now").get()
                val state = infos.firstOrNull()?.state
                queuedInfo = if (state == WorkInfo.State.ENQUEUED && !SyncState.running) {
                    if (Store.prefs(this).getBoolean("wifi", true)) "Čeká na Wi-Fi…" else "Čeká na připojení k síti…"
                } else ""
                val now = System.currentTimeMillis()
                if (!SyncState.running && now - lastLibRefresh > 10000 && Media.access(this) > 0) {
                    libTotal = Media.query(this).count { it.size > 0 }
                    lastLibRefresh = now
                }
            } catch (t: Throwable) {
                L.log("bgRefresh: $t")
            } finally {
                bgBusy = false
            }
        }.start()
    }

    // ---------- vykreslení ----------
    private fun render() {
        val p = Store.prefs(this)
        val running = SyncState.running
        if (tickN++ % 3 == 0) bgRefresh()
        if (wasRunning && !running) lastLibRefresh = 0
        wasRunning = running

        val now = System.currentTimeMillis()
        val sent = SyncState.sent.get()
        if (running) {
            val dt = (now - lastT) / 1000.0
            if (dt > 0 && lastT > 0) {
                val inst = (sent - lastSent) / dt
                speed = if (speed == 0.0) inst else speed * 0.7 + inst * 0.3
            }
        } else speed = 0.0
        lastSent = sent
        lastT = now

        val (title, color) = when {
            running -> "Zálohuji…" to PRIMARY
            queuedInfo.isNotEmpty() -> queuedInfo to WARN
            else -> "Nečinný" to TEXT
        }
        titleTv.text = title
        titleTv.setTextColor(color)
        var detail = p.getString("status", "Připraveno") ?: ""
        val last = p.getLong("last_run", 0)
        if (!running && last > 0) {
            detail += "\nPoslední běh: " + SimpleDateFormat("d. M. HH:mm", Locale.getDefault()).format(Date(last))
        }
        detailTv.text = detail

        if (running && SyncState.total > 0) {
            val tot = SyncState.total
            val partial = if (SyncState.curSize > 0) (SyncState.curBytes.toDouble() / SyncState.curSize).coerceIn(0.0, 1.0) else 0.0
            bar.progress = (((SyncState.done + SyncState.failed + partial) / tot) * 1000).toInt()
            progTv.text = "${SyncState.done + SyncState.failed} / $tot • chyb ${SyncState.failed}" +
                (if (speed > 0) " • ${fmt(speed.toLong())}/s" else "")
            curTv.text = "${SyncState.current}  ${fmt(SyncState.curBytes)} / ${fmt(SyncState.curSize)}"
        } else {
            bar.progress = 0
            progTv.text = ""
            curTv.text = ""
        }

        val backed = p.getStringSet("done", emptySet())?.size ?: 0
        if (running && SyncState.total > 0) {
            nLib.text = if (libTotal >= 0) libTotal.toString() else "–"
            nDone.text = (backed).toString()
            nRem.text = (SyncState.total - SyncState.done - SyncState.failed).coerceAtLeast(0).toString()
        } else if (libTotal >= 0) {
            nLib.text = libTotal.toString()
            nDone.text = minOf(backed, libTotal).toString()
            nRem.text = (libTotal - backed).coerceAtLeast(0).toString()
        } else {
            nLib.text = "–"; nDone.text = backed.toString(); nRem.text = "–"
        }

        val acc = Media.access(this)
        val notif = Build.VERSION.SDK_INT < 33 || Media.granted(this, Manifest.permission.POST_NOTIFICATIONS)
        val perm = when {
            acc == 0 -> "⚠ Chybí oprávnění k fotkám – otevři Nastavení → Povolit přístup k fotkám"
            acc == 1 -> "⚠ Částečný přístup – v nastavení aplikace povol „Všechny fotky a videa“"
            !notif -> "ℹ Notifikace nejsou povoleny (záloha poběží i tak)"
            else -> ""
        }
        permTv.text = perm
        permTv.visibility = if (perm.isEmpty()) View.GONE else View.VISIBLE

        startBtn.isEnabled = !running
        startBtn.alpha = if (running) 0.4f else 1f
        stopBtn.isEnabled = running || queuedInfo.isNotEmpty()
        stopBtn.alpha = if (stopBtn.isEnabled) 1f else 0.4f

        val v = L.version()
        if (v != lastLogVer) {
            lastLogVer = v
            val child = logScroll.getChildAt(0)
            val atBottom = child == null || child.bottom - (logScroll.height + logScroll.scrollY) < dp(40)
            logTv.text = L.tail()
            if (atBottom) logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
        }
    }
}
