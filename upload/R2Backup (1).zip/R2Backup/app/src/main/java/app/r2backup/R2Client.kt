package app.r2backup

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okio.Buffer
import okio.BufferedSink
import okio.source
import java.io.IOException
import java.io.InputStream
import java.security.MessageDigest
import java.time.ZoneOffset
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/** Minimální S3 klient pro Cloudflare R2 (SigV4, PUT + multipart pro velké soubory). */
class R2Client(private val cfg: Config) {
    class Stopped : IOException("Zastaveno")

    companion object {
        const val PART = 8 * 1024 * 1024
        const val MULTIPART_FROM = 32L * 1024 * 1024
    }

    private class Res(val body: String, val etag: String?)

    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .callTimeout(0, TimeUnit.SECONDS)
        .retryOnConnectionFailure(false)
        .build()

    private val host = cfg.endpoint.trim().removePrefix("https://").removePrefix("http://")
        .substringBefore('/').trim()

    private fun enc(s: String): String {
        val sb = StringBuilder()
        for (b in s.toByteArray(Charsets.UTF_8)) {
            val c = b.toInt() and 0xff
            val ch = c.toChar()
            if ((ch in 'A'..'Z') || (ch in 'a'..'z') || (ch in '0'..'9') || ch == '-' || ch == '_' || ch == '.' || ch == '~') sb.append(ch)
            else sb.append("%%%02X".format(c))
        }
        return sb.toString()
    }

    private fun hmac(key: ByteArray, data: String): ByteArray {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(key, "HmacSHA256"))
        return m.doFinal(data.toByteArray(Charsets.UTF_8))
    }

    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
    private fun sha256(s: String) = hex(MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)))

    private fun sign(method: String, path: String, query: String): Map<String, String> {
        val now = ZonedDateTime.now(ZoneOffset.UTC)
        val amzDate = now.format(DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss'Z'"))
        val date = amzDate.substring(0, 8)
        val payload = "UNSIGNED-PAYLOAD"
        val signed = "host;x-amz-content-sha256;x-amz-date"
        val canonical = "$method\n$path\n$query\nhost:$host\nx-amz-content-sha256:$payload\nx-amz-date:$amzDate\n\n$signed\n$payload"
        val scope = "$date/auto/s3/aws4_request"
        val sts = "AWS4-HMAC-SHA256\n$amzDate\n$scope\n${sha256(canonical)}"
        var k = hmac(("AWS4" + cfg.secret).toByteArray(), date)
        k = hmac(k, "auto"); k = hmac(k, "s3"); k = hmac(k, "aws4_request")
        val sig = hex(hmac(k, sts))
        return mapOf(
            "x-amz-date" to amzDate,
            "x-amz-content-sha256" to payload,
            "Authorization" to "AWS4-HMAC-SHA256 Credential=${cfg.accessKey}/$scope, SignedHeaders=$signed, Signature=$sig",
        )
    }

    private fun bucketPath() = "/" + enc(cfg.bucket)
    private fun objectPath(key: String) = bucketPath() + "/" + key.split('/').joinToString("/") { enc(it) }

    private fun describe(code: Int, body: String): String {
        val c = Regex("<Code>(.*?)</Code>").find(body)?.groupValues?.get(1)
        val hint = when {
            c == "SignatureDoesNotMatch" -> "špatný Secret Access Key nebo endpoint"
            c == "InvalidAccessKeyId" -> "špatný Access Key ID"
            c == "NoSuchBucket" || (c == null && code == 404) -> "bucket neexistuje (zkontroluj název a endpoint)"
            c == "AccessDenied" || (c == null && code == 403) -> "token nemá oprávnění Object Read & Write pro tento bucket"
            c == "RequestTimeTooSkewed" -> "špatný čas v telefonu"
            else -> ""
        }
        return "HTTP $code ${c ?: ""} $hint".trim()
    }

    private fun exec(method: String, path: String, query: String, body: RequestBody?): Res {
        val url = "https://$host$path" + (if (query.isEmpty()) "" else "?$query")
        val rb = Request.Builder().url(url)
        when (method) {
            "PUT" -> rb.put(body!!)
            "POST" -> rb.post(body!!)
            "DELETE" -> rb.delete()
            else -> rb.head()
        }
        sign(method, path, query).forEach { (k, v) -> rb.header(k, v) }
        http.newCall(rb.build()).execute().use { r ->
            val txt = if (method == "HEAD") "" else (r.body?.string() ?: "")
            if (!r.isSuccessful) throw IOException(describe(r.code, txt))
            return Res(txt, r.header("ETag"))
        }
    }

    /** Ověření přístupu: HEAD na bucket. */
    fun check() {
        exec("HEAD", bucketPath(), "", null)
    }

    fun upload(
        key: String, mime: String, size: Long, open: () -> InputStream,
        onBytes: (Long) -> Unit, stopped: () -> Boolean,
    ) {
        open().use { s ->
            if (size >= MULTIPART_FROM) putMultipart(key, mime, s, onBytes, stopped)
            else putSingle(key, mime, size, s, onBytes, stopped)
        }
    }

    private fun putSingle(
        key: String, mime: String, size: Long, stream: InputStream,
        onBytes: (Long) -> Unit, stopped: () -> Boolean,
    ) {
        val body = object : RequestBody() {
            override fun contentType() = mime.toMediaTypeOrNull()
            override fun contentLength() = size
            override fun writeTo(sink: BufferedSink) {
                val buf = Buffer()
                stream.source().use { src ->
                    while (true) {
                        val n = src.read(buf, 65536)
                        if (n < 0L) break
                        sink.write(buf, n)
                        onBytes(n)
                        if (stopped()) throw Stopped()
                    }
                }
            }
        }
        exec("PUT", objectPath(key), "", body)
    }

    private fun readFull(s: InputStream, b: ByteArray): Int {
        var off = 0
        while (off < b.size) {
            val n = s.read(b, off, b.size - off)
            if (n < 0) break
            off += n
        }
        return off
    }

    private fun putMultipart(
        key: String, mime: String, stream: InputStream,
        onBytes: (Long) -> Unit, stopped: () -> Boolean,
    ) {
        val path = objectPath(key)
        val init = exec("POST", path, "uploads=", ByteArray(0).toRequestBody()).body
        val uploadId = Regex("<UploadId>(.*?)</UploadId>").find(init)?.groupValues?.get(1)
            ?: throw IOException("R2 nevrátilo UploadId")
        val q = enc(uploadId)
        try {
            val etags = ArrayList<String>()
            val buf = ByteArray(PART)
            var n = 1
            val ct = mime.toMediaTypeOrNull()
            while (true) {
                if (stopped()) throw Stopped()
                val len = readFull(stream, buf)
                if (len <= 0) break
                var attempt = 0
                var etag: String
                while (true) {
                    attempt++
                    try {
                        etag = exec("PUT", path, "partNumber=$n&uploadId=$q", buf.toRequestBody(ct, 0, len)).etag
                            ?: throw IOException("Chybí ETag části $n")
                        break
                    } catch (e: IOException) {
                        if (stopped() || attempt >= 3) throw e
                        L.log("  část $n selhala (${e.message}), opakuji")
                        Thread.sleep(2000L * attempt)
                    }
                }
                etags.add(etag)
                onBytes(len.toLong())
                n++
                if (len < PART) break
            }
            if (etags.isEmpty()) throw IOException("Prázdný soubor")
            val xml = "<CompleteMultipartUpload>" + etags.mapIndexed { i, e ->
                "<Part><PartNumber>${i + 1}</PartNumber><ETag>$e</ETag></Part>"
            }.joinToString("") + "</CompleteMultipartUpload>"
            val res = exec("POST", path, "uploadId=$q", xml.toRequestBody("application/xml".toMediaType()))
            if (res.body.contains("<Error>")) throw IOException("Dokončení multipart selhalo: " + res.body.take(200))
        } catch (e: Exception) {
            try { exec("DELETE", path, "uploadId=$q", null) } catch (_: Exception) {}
            throw e
        }
    }
}
