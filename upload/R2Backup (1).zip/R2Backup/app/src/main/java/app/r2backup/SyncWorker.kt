package app.r2backup

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentUris
import android.content.Context
import android.content.pm.ServiceInfo
import android.content.res.AssetFileDescriptor
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext
import java.io.IOException
import java.time.Instant
import java.time.ZoneId

class SyncWorker(private val ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    private fun info(text: String, total: Int = 0, done: Int = 0): ForegroundInfo {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("sync", "Záloha", NotificationManager.IMPORTANCE_LOW))
        val b = Notification.Builder(ctx, "sync")
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("R2 záloha")
            .setContentText(text)
            .setOngoing(true)
        if (total > 0) b.setProgress(total, done, false)
        val n = b.build()
        return if (Build.VERSION.SDK_INT >= 29)
            ForegroundInfo(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo(1, n)
    }

    override suspend fun getForegroundInfo(): ForegroundInfo = info("Zálohuji…")

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        L.init(ctx)
        if (!lock.tryLock()) {
            L.log("Záloha už běží – přeskakuji")
            return@withContext Result.success()
        }
        SyncState.reset()
        SyncState.running = true
        try {
            runSync()
        } catch (e: CancellationException) {
            L.log("Záloha přerušena systémem")
            Store.setStatus(ctx, "Přerušeno systémem – pokračuje při dalším běhu")
            throw e
        } catch (t: Throwable) {
            L.log("NEOČEKÁVANÁ CHYBA:\n" + Log.getStackTraceString(t))
            Store.setStatus(ctx, "Chyba: ${t.message}")
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        } finally {
            SyncState.running = false
            lock.unlock()
        }
    }

    private suspend fun runSync(): Result {
        val cfg = Store.load(ctx)
        if (cfg == null) {
            L.log("Chybí nastavení R2")
            Store.setStatus(ctx, "Vyplň nastavení R2")
            return Result.failure()
        }
        val access = Media.access(ctx)
        if (access == 0) {
            L.log("Chybí oprávnění k fotkám")
            Store.setStatus(ctx, "Chybí oprávnění k fotkám")
            return Result.failure()
        }
        L.log("=== Start zálohy (přístup k médiím: ${if (access == 2) "plný" else "částečný"}) ===")
        try { setForeground(info("Příprava…")) } catch (e: Exception) {
            L.log("Foreground služba nespuštěna (${e.javaClass.simpleName}) – pokračuji bez ní")
        }

        val done = Store.doneSet(ctx)
        val all = Media.query(ctx)
        val pending = all.filter { it.size > 0 && it.id.toString() !in done }
        SyncState.total = pending.size
        L.log("V galerii ${all.size}, už zálohováno ${done.size}, ke zpracování ${pending.size}")

        val client = R2Client(cfg)
        var ok = 0
        var consecutive = 0
        var lastErr = ""
        try {
            for ((i, item) in pending.withIndex()) {
                if (SyncState.stop) { L.log("Zastaveno uživatelem"); break }
                currentCoroutineContext().ensureActive()
                SyncState.current = item.name
                SyncState.curSize = item.size
                SyncState.curBytes = 0
                val msg = "${i + 1}/${pending.size}: ${item.name}"
                Store.setStatus(ctx, "Nahrávám $msg")
                try { setForeground(info(msg, pending.size, i)) } catch (_: Exception) {}
                val t = System.currentTimeMillis()
                try {
                    uploadItem(client, item)
                    done.add(item.id.toString())
                    ok++
                    SyncState.done++
                    consecutive = 0
                    if (ok % 5 == 0) Store.saveDone(ctx, done)
                    L.log("OK   ${item.name} (${item.size / 1024} kB, ${System.currentTimeMillis() - t} ms)")
                } catch (e: Exception) {
                    if (SyncState.stop || isStopped) { L.log("Přerušeno: ${item.name}"); break }
                    SyncState.failed++
                    consecutive++
                    lastErr = e.message ?: e.javaClass.simpleName
                    L.log("ERR  ${item.name}: $lastErr")
                    if (consecutive >= 3) { L.log("3 chyby po sobě – končím, zkusím znovu později"); break }
                }
            }
        } finally {
            Store.saveDone(ctx, done)
        }

        Store.prefs(ctx).edit().putLong("last_run", System.currentTimeMillis()).apply()
        val msg = when {
            SyncState.stop -> "Zastaveno • nahráno $ok, chyb ${SyncState.failed}"
            consecutive >= 3 -> "Chyba: $lastErr • nahráno $ok"
            else -> "Hotovo • nahráno $ok, chyb ${SyncState.failed} • zálohováno celkem ${done.size}"
        }
        Store.setStatus(ctx, msg)
        L.log("=== $msg ===")
        return if (consecutive >= 3) Result.retry() else Result.success()
    }

    private fun openAfd(item: Media.Item): AssetFileDescriptor {
        val base = if (item.type == 1) MediaStore.Images.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val uri = ContentUris.withAppendedId(base, item.id)
        val canLoc = Build.VERSION.SDK_INT >= 29 && item.type == 1 &&
            Media.granted(ctx, Manifest.permission.ACCESS_MEDIA_LOCATION)
        val afd = try {
            ctx.contentResolver.openAssetFileDescriptor(if (canLoc) MediaStore.setRequireOriginal(uri) else uri, "r")
        } catch (e: Exception) {
            ctx.contentResolver.openAssetFileDescriptor(uri, "r")
        }
        return afd ?: throw IOException("Nelze otevřít soubor")
    }

    private fun uploadItem(client: R2Client, item: Media.Item) {
        val d = Instant.ofEpochMilli(item.takenMs).atZone(ZoneId.systemDefault())
        val key = "%04d/%02d/%d_%s".format(d.year, d.monthValue, item.id, item.name)
        var attempt = 0
        while (true) {
            attempt++
            try {
                SyncState.curBytes = 0
                openAfd(item).use { afd ->
                    val size = if (afd.length >= 0) afd.length else item.size
                    SyncState.curSize = size
                    client.upload(
                        key, item.mime, size,
                        open = { afd.createInputStream() },
                        onBytes = { n -> SyncState.curBytes += n; SyncState.sent.addAndGet(n) },
                        stopped = { SyncState.stop || isStopped },
                    )
                }
                return
            } catch (e: Exception) {
                if (SyncState.stop || isStopped) throw R2Client.Stopped()
                if (attempt >= 3) throw e
                L.log("  pokus $attempt selhal: ${e.message} – zkouším znovu")
                Thread.sleep(3000L * attempt)
            }
        }
    }

    companion object {
        private val lock = Mutex()
    }
}
