package app.r2backup

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentUris
import android.content.Context
import android.content.pm.ServiceInfo
import android.content.res.AssetFileDescriptor
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext
import java.io.IOException
import java.security.MessageDigest

class SyncWorker(private val ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    private fun info(text: String, total: Int = 0, done: Int = 0): ForegroundInfo {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("sync", "Záloha", NotificationManager.IMPORTANCE_LOW))
        val b = Notification.Builder(ctx, "sync")
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("R2 záloha")
            .setContentText(text)
            .setOngoing(true)
        if (total > 0) b.setProgress(total, done, false)
        val n = b.build()
        return if (Build.VERSION.SDK_INT >= 29)
            ForegroundInfo(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo(1, n)
    }

    override suspend fun getForegroundInfo(): ForegroundInfo = info("Zálohuji…")

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        L.init(ctx)
        if (!lock.tryLock()) {
            L.log("Záloha už běží – přeskakuji")
            return@withContext Result.success()
        }
        SyncState.reset()
        SyncState.running = true
        try {
            runSync()
        } catch (e: CancellationException) {
            L.log("Záloha přerušena systémem")
            Store.setStatus(ctx, "Přerušeno systémem – pokračuje při dalším běhu")
            throw e
        } catch (t: Throwable) {
            L.log("NEOČEKÁVANÁ CHYBA:\n" + Log.getStackTraceString(t))
            Store.setStatus(ctx, "Chyba: ${t.message}")
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        } finally {
            SyncState.running = false
            lock.unlock()
        }
    }

    private suspend fun runSync(): Result {
        val cfg = Store.load(ctx)
        if (cfg == null) {
            L.log("Chybí nastavení R2")
            Store.setStatus(ctx, "Vyplň nastavení R2")
            return Result.failure()
        }
        val access = Media.access(ctx)
        if (access == 0) {
            L.log("Chybí oprávnění k fotkám")
            Store.setStatus(ctx, "Chybí oprávnění k fotkám")
            return Result.failure()
        }
        L.log("=== Start zálohy (přístup k médiím: ${if (access == 2) "plný" else "částečný"}) ===")
        try { setForeground(info("Příprava…")) } catch (e: Exception) {
            L.log("Foreground služba nespuštěna (${e.javaClass.simpleName}) – pokračuji bez ní")
        }

        val client = R2Client(cfg)
        val device = Store.device(ctx)
        Manifest.load(ctx)
        val legacy = Store.doneSet(ctx)
        if (Manifest.size() == 0 && legacy.isEmpty() && Store.prefs(ctx).getLong("last_run", 0) == 0L) {
            try {
                Store.setStatus(ctx, "Zjišťuji, co už je v R2…")
                L.log("Čistá instalace: " + Restore.fromR2(ctx, client, device))
                legacy.addAll(Store.doneSet(ctx))
            } catch (e: Exception) {
                L.log("Obnova historie z R2 selhala: ${e.message}")
            }
        }

        val isExcluded = Media.excluded(ctx)
        val all = Media.query(ctx)
        val skipped = all.count { isExcluded(it.folder) }
        val pending = all.filter {
            if (it.size <= 0 || isExcluded(it.folder)) false
            else {
                val e = Manifest.get(Media.pathKey(device, it))
                !(e != null && e.size == it.size && e.mod == it.modSec)
            }
        }
        SyncState.total = pending.size
        L.log("V galerii ${all.size}, vyloučeno $skipped, v manifestu ${Manifest.size()}, ke zpracování ${pending.size} (zařízení: $device)")

        var uploaded = 0
        var indexed = 0
        var processed = 0
        var consecutive = 0
        var lastErr = ""
        try {
            for ((i, item) in pending.withIndex()) {
                if (SyncState.stop) { L.log("Zastaveno uživatelem"); break }
                currentCoroutineContext().ensureActive()
                SyncState.current = item.name
                SyncState.curSize = item.size
                SyncState.curBytes = 0
                val msg = "${i + 1}/${pending.size}: ${item.name}"
                Store.setStatus(ctx, "Zpracovávám $msg")
                try { setForeground(info(msg, pending.size, i)) } catch (_: Exception) {}
                val t = System.currentTimeMillis()
                val path = Media.pathKey(device, item)
                try {
                    val old = Manifest.get(path)
                    val sha = hashItem(item)
                    val what: String
                    if (old != null && old.sha == sha) {
                        Manifest.put(Entry(path, old.obj, item.size, item.modSec, sha))
                        indexed++; what = "beze změny"
                    } else if (old == null && item.id.toString() in legacy) {
                        Manifest.put(Entry(path, Media.legacyKey(item), item.size, item.modSec, sha))
                        indexed++; what = "zaindexováno (už v R2)"
                    } else {
                        val dup = Manifest.byHash(sha)
                        if (dup != null) {
                            Manifest.put(Entry(path, dup.obj, item.size, item.modSec, sha))
                            indexed++; what = "duplicita (${dup.path})"
                        } else {
                            val obj = if (old != null && Manifest.refs(old.obj) > 1) path + "#" + sha.take(8) else path
                            SyncState.curBytes = 0
                            uploadItem(client, item, obj)
                            Manifest.put(Entry(path, obj, item.size, item.modSec, sha))
                            uploaded++; what = "nahráno"
                        }
                    }
                    SyncState.done++
                    consecutive = 0
                    if (++processed % 25 == 0) Manifest.save(ctx)
                    L.log("OK   ${item.name} – $what (${item.size / 1024} kB, ${System.currentTimeMillis() - t} ms)")
                } catch (e: Exception) {
                    if (SyncState.stop || isStopped) { L.log("Přerušeno: ${item.name}"); break }
                    SyncState.failed++
                    consecutive++
                    lastErr = e.message ?: e.javaClass.simpleName
                    L.log("ERR  ${item.name}: $lastErr")
                    if (consecutive >= 3) { L.log("3 chyby po sobě – končím, zkusím znovu později"); break }
                }
            }
        } finally {
            try { Manifest.save(ctx) } catch (e: Exception) { L.log("Uložení manifestu: ${e.message}") }
        }

        if (Manifest.changed) {
            try {
                Restore.push(client, device)
                Manifest.changed = false
                L.log("Manifest nahrán do R2 (${Manifest.size()} záznamů)")
            } catch (e: Exception) {
                L.log("Nahrání manifestu selhalo: ${e.message}")
            }
        }

        Store.prefs(ctx).edit().putLong("last_run", System.currentTimeMillis()).apply()
        val msg = when {
            SyncState.stop -> "Zastaveno • nahráno $uploaded, zaindexováno $indexed, chyb ${SyncState.failed}"
            consecutive >= 3 -> "Chyba: $lastErr • nahráno $uploaded"
            else -> "Hotovo • nahráno $uploaded, zaindexováno $indexed, chyb ${SyncState.failed} • v manifestu ${Manifest.size()}"
        }
        Store.setStatus(ctx, msg)
        L.log("=== $msg ===")
        return if (consecutive >= 3) Result.retry() else Result.success()
    }

    private fun hashItem(item: Media.Item): String {
        val md = MessageDigest.getInstance("SHA-256")
        openAfd(item).use { afd ->
            afd.createInputStream().use { s ->
                val buf = ByteArray(256 * 1024)
                while (true) {
                    val n = s.read(buf)
                    if (n < 0) break
                    md.update(buf, 0, n)
                    SyncState.curBytes += n
                    if (SyncState.stop || isStopped) throw R2Client.Stopped()
                }
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun openAfd(item: Media.Item): AssetFileDescriptor {
        val base = if (item.type == 1) MediaStore.Images.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val uri = ContentUris.withAppendedId(base, item.id)
        val canLoc = Build.VERSION.SDK_INT >= 29 && item.type == 1 &&
            Media.granted(ctx, Manifest.permission.ACCESS_MEDIA_LOCATION)
        val afd = try {
            ctx.contentResolver.openAssetFileDescriptor(if (canLoc) MediaStore.setRequireOriginal(uri) else uri, "r")
        } catch (e: Exception) {
            ctx.contentResolver.openAssetFileDescriptor(uri, "r")
        }
        return afd ?: throw IOException("Nelze otevřít soubor")
    }

    private fun uploadItem(client: R2Client, item: Media.Item, key: String) {
        var attempt = 0
        while (true) {
            attempt++
            try {
                SyncState.curBytes = 0
                openAfd(item).use { afd ->
                    val size = if (afd.length >= 0) afd.length else item.size
                    SyncState.curSize = size
                    client.upload(
                        key, item.mime, size,
                        open = { afd.createInputStream() },
                        onBytes = { n -> SyncState.curBytes += n; SyncState.sent.addAndGet(n) },
                        stopped = { SyncState.stop || isStopped },
                    )
                }
                return
            } catch (e: Exception) {
                if (SyncState.stop || isStopped) throw R2Client.Stopped()
                if (attempt >= 3) throw e
                L.log("  pokus $attempt selhal: ${e.message} – zkouším znovu")
                Thread.sleep(3000L * attempt)
            }
        }
    }

    companion object {
        private val lock = Mutex()
    }
}
