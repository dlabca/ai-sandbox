package app.r2backup

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

object Sync {
    private fun constraints(ctx: Context, auto: Boolean): Constraints {
        val wifi = Store.prefs(ctx).getBoolean("wifi", true)
        val b = Constraints.Builder()
            .setRequiredNetworkType(if (wifi) NetworkType.UNMETERED else NetworkType.CONNECTED)
        // POZOR: expedited (ruční) práce nesmí mít jiné omezení než síť/úložiště, jinak build() spadne
        if (auto) b.setRequiresBatteryNotLow(true)
        return b.build()
    }

    fun runNow(ctx: Context) {
        val req = OneTimeWorkRequestBuilder<SyncWorker>()
            .setConstraints(constraints(ctx, false))
            .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork("now", ExistingWorkPolicy.REPLACE, req)
    }

    fun applyAuto(ctx: Context) {
        val p = Store.prefs(ctx)
        val wm = WorkManager.getInstance(ctx)
        if (p.getBoolean("auto", false)) {
            val min = p.getInt("interval", 60).toLong().coerceAtLeast(15)
            val req = PeriodicWorkRequestBuilder<SyncWorker>(min, TimeUnit.MINUTES)
                .setConstraints(constraints(ctx, true)).build()
            wm.enqueueUniquePeriodicWork("auto", ExistingPeriodicWorkPolicy.UPDATE, req)
        } else wm.cancelUniqueWork("auto")
    }
}
