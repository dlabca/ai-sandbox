package app.r2backup

import android.Manifest
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.ViewGroup
import android.widget.*
import androidx.work.*
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val fields = LinkedHashMap<String, EditText>()
    private lateinit var wifi: CheckBox
    private lateinit var auto: CheckBox

    private fun field(root: LinearLayout, key: String, hint: String, secret: Boolean = false) {
        val e = EditText(this)
        e.hint = hint
        e.setSingleLine()
        if (secret) e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        e.setText(Store.prefs(this).getString(key, ""))
        root.addView(e, ViewGroup.LayoutParams(-1, -2))
        fields[key] = e
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = Store.prefs(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        field(root, "endpoint", "Endpoint (https://<account-id>.r2.cloudflarestorage.com)")
        field(root, "bucket", "Bucket")
        field(root, "access", "Access Key ID")
        field(root, "secret", "Secret Access Key", true)
        wifi = CheckBox(this).apply { text = "Jen přes Wi-Fi"; isChecked = p.getBoolean("wifi", true) }
        auto = CheckBox(this).apply { text = "Automatická záloha (každou hodinu)"; isChecked = p.getBoolean("auto", false) }
        root.addView(wifi); root.addView(auto)

        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }.also { root.addView(it) }
        btn("Uložit + oprávnění") { save(); askPermissions() }
        btn("Zálohovat teď") { save(); runNow() }
        btn("Test připojení") { save(); test() }
        btn("Zapomenout stav (nahrát vše znovu)") {
            p.edit().remove("done").apply(); toast("Stav vymazán")
        }
        status = TextView(this).apply { setPadding(0, 30, 0, 0); textSize = 15f }
        root.addView(status)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        handler.post(object : Runnable {
            override fun run() {
                status.text = Store.prefs(this@MainActivity).getString("status", "Připraveno")
                handler.postDelayed(this, 1000)
            }
        })
    }

    override fun onPause() { super.onPause(); handler.removeCallbacksAndMessages(null) }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun save() {
        val e = Store.prefs(this).edit()
        fields.forEach { (k, v) -> e.putString(k, v.text.toString().trim()) }
        e.putBoolean("wifi", wifi.isChecked).putBoolean("auto", auto.isChecked).apply()
        val wm = WorkManager.getInstance(this)
        if (auto.isChecked) {
            val req = PeriodicWorkRequestBuilder<SyncWorker>(1, TimeUnit.HOURS)
                .setConstraints(constraints()).build()
            wm.enqueueUniquePeriodicWork("auto", ExistingPeriodicWorkPolicy.UPDATE, req)
        } else wm.cancelUniqueWork("auto")
    }

    private fun constraints() = Constraints.Builder()
        .setRequiredNetworkType(if (wifi.isChecked) NetworkType.UNMETERED else NetworkType.CONNECTED)
        .setRequiresBatteryNotLow(true)
        .build()

    private fun runNow() {
        val req = OneTimeWorkRequestBuilder<SyncWorker>()
            .setConstraints(constraints())
            .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
            .build()
        WorkManager.getInstance(this).enqueueUniqueWork("now", ExistingWorkPolicy.KEEP, req)
        Store.setStatus(this, "Ve frontě…")
    }

    private fun test() {
        val cfg = Store.load(this) ?: return toast("Vyplň všechna pole")
        Store.setStatus(this, "Testuji…")
        Thread {
            val r = try { R2Client(cfg).check(); "Připojení OK" } catch (e: Exception) { "Chyba: ${e.message}" }
            Store.setStatus(this, r)
        }.start()
    }

    private fun askPermissions() {
        val l = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            l += Manifest.permission.READ_MEDIA_IMAGES
            l += Manifest.permission.READ_MEDIA_VIDEO
            l += Manifest.permission.POST_NOTIFICATIONS
        } else l += Manifest.permission.READ_EXTERNAL_STORAGE
        if (Build.VERSION.SDK_INT >= 29) l += Manifest.permission.ACCESS_MEDIA_LOCATION
        requestPermissions(l.toTypedArray(), 1)
    }
}
