package app.r2backup

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.provider.MediaStore
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.ZoneId

class SyncWorker(private val ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    private class Item(val id: Long, val name: String, val mime: String, val size: Long, val type: Int, val takenMs: Long)

    private fun info(text: String): ForegroundInfo {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("sync", "Záloha", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(ctx, "sync")
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("R2 záloha")
            .setContentText(text)
            .setOngoing(true)
            .build()
        return if (Build.VERSION.SDK_INT >= 29)
            ForegroundInfo(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo(1, n)
    }

    override suspend fun getForegroundInfo() = info("Zálohuji…")

    private fun query(): List<Item> {
        val out = ArrayList<Item>()
        val proj = arrayOf(
            MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.MIME_TYPE, MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.MEDIA_TYPE, MediaStore.MediaColumns.DATE_TAKEN,
            MediaStore.Files.FileColumns.DATE_ADDED,
        )
        val sel = "${MediaStore.Files.FileColumns.MEDIA_TYPE} IN (1,3)"
        ctx.contentResolver.query(
            MediaStore.Files.getContentUri("external"), proj, sel, null,
            "${MediaStore.Files.FileColumns.DATE_ADDED} ASC",
        )?.use { c ->
            while (c.moveToNext()) {
                val taken = c.getLong(5).takeIf { it > 0 } ?: (c.getLong(6) * 1000)
                out.add(Item(c.getLong(0), c.getString(1) ?: "file", c.getString(2) ?: "application/octet-stream", c.getLong(3), c.getInt(4), taken))
            }
        }
        return out
    }

    private fun upload(client: R2Client, item: Item) {
        val base = if (item.type == 1) MediaStore.Images.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val uri = ContentUris.withAppendedId(base, item.id)
        val d = Instant.ofEpochMilli(item.takenMs).atZone(ZoneId.systemDefault())
        val key = "%04d/%02d/%d_%s".format(d.year, d.monthValue, item.id, item.name)
        val canLoc = Build.VERSION.SDK_INT >= 29 && item.type == 1 &&
            ctx.checkSelfPermission(Manifest.permission.ACCESS_MEDIA_LOCATION) == PackageManager.PERMISSION_GRANTED
        val afd = try {
            ctx.contentResolver.openAssetFileDescriptor(if (canLoc) MediaStore.setRequireOriginal(uri) else uri, "r")
        } catch (e: Exception) {
            ctx.contentResolver.openAssetFileDescriptor(uri, "r")
        } ?: throw java.io.IOException("Nelze otevřít soubor")
        afd.use {
            val size = if (it.length >= 0) it.length else 0L
            client.put(key, item.mime, size, it.createInputStream())
        }
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val cfg = Store.load(ctx) ?: run { Store.setStatus(ctx, "Chybí nastavení"); return@withContext Result.failure() }
        if (!lock.tryLock()) return@withContext Result.success()
        try {
            try { setForeground(info("Příprava…")) } catch (ignored: Exception) {}
            val prefs = Store.prefs(ctx)
            val done = prefs.getStringSet("done", emptySet())!!.toMutableSet()
            val pending = query().filter { it.id.toString() !in done && it.size > 0 }
            val client = R2Client(cfg)
            var ok = 0
            var consecutiveFails = 0
            var lastErr = ""
            for ((i, it) in pending.withIndex()) {
                ensureActive()
                val msg = "Nahrávám ${i + 1}/${pending.size}: ${it.name}"
                Store.setStatus(ctx, msg)
                try { setForeground(info(msg)) } catch (ignored: Exception) {}
                try {
                    upload(client, it)
                    done.add(it.id.toString())
                    prefs.edit().putStringSet("done", HashSet(done)).apply()
                    ok++; consecutiveFails = 0
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    lastErr = e.message ?: e.javaClass.simpleName
                    if (++consecutiveFails >= 3) break
                }
            }
            if (consecutiveFails >= 3) {
                Store.setStatus(ctx, "Chyba: $lastErr (nahráno $ok)")
                Result.retry()
            } else {
                Store.setStatus(ctx, "Hotovo – nahráno $ok, celkem zálohováno ${done.size}")
                Result.success()
            }
        } finally {
            lock.unlock()
        }
    }

    companion object { private val lock = Mutex() }
}
