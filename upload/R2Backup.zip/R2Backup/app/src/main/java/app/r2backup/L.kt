package app.r2backup

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Jednoduchý souborový log (zobrazuje se v appce). */
object L {
    private var file: File? = null
    private val fmt = SimpleDateFormat("dd.MM. HH:mm:ss", Locale.US)

    fun init(c: Context) {
        if (file == null) file = File(c.applicationContext.filesDir, "log.txt")
    }

    @Synchronized
    fun log(msg: String) {
        android.util.Log.d("R2Backup", msg)
        val f = file ?: return
        try {
            f.appendText("${fmt.format(Date())}  $msg\n")
            if (f.length() > 300_000) {
                val t = f.readText().takeLast(150_000)
                f.writeText(t.substringAfter('\n'))
            }
        } catch (_: Exception) {
        }
    }

    @Synchronized
    fun tail(max: Int = 30000): String {
        val f = file ?: return ""
        return try { if (f.exists()) f.readText().takeLast(max) else "" } catch (_: Exception) { "" }
    }

    @Synchronized
    fun clear() {
        try { file?.writeText("") } catch (_: Exception) {}
    }

    @Synchronized
    fun version(): Long = file?.let { it.length() + it.lastModified() } ?: 0L
}
