package app.r2backup

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.MediaStore
import java.time.Instant
import java.time.ZoneId

object Media {
    class Item(
        val id: Long, val name: String, val mime: String, val size: Long,
        val type: Int, val takenMs: Long, val folder: String,
    )

    fun granted(c: Context, p: String) = c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    /** 2 = plný přístup, 1 = částečný (Android 14), 0 = žádný */
    fun access(c: Context): Int {
        return if (Build.VERSION.SDK_INT >= 33) {
            if (granted(c, Manifest.permission.READ_MEDIA_IMAGES) || granted(c, Manifest.permission.READ_MEDIA_VIDEO)) 2
            else if (Build.VERSION.SDK_INT >= 34 && granted(c, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)) 1
            else 0
        } else if (granted(c, Manifest.permission.READ_EXTERNAL_STORAGE)) 2 else 0
    }

    /** Klíč objektu v R2: rrrr/mm/ID_název */
    fun keyFor(i: Item): String {
        val d = Instant.ofEpochMilli(i.takenMs).atZone(ZoneId.systemDefault())
        return "%04d/%02d/%d_%s".format(d.year, d.monthValue, i.id, i.name)
    }

    /** Vrací predikát "je složka vyloučena ze zálohy". Bez uložené volby se vylučuje Download/. */
    fun excluded(c: Context): (String) -> Boolean {
        val ex = Store.prefs(c).getStringSet("excluded", null)
        return if (ex == null) { f -> f.startsWith("Download/") } else { f -> f in ex }
    }

    private fun folderOf(raw: String?): String {
        if (raw == null) return ""
        if (Build.VERSION.SDK_INT >= 29) return raw
        val rel = raw.substringBeforeLast('/', "").removePrefix("/storage/emulated/0").trim('/')
        return if (rel.isEmpty()) "" else "$rel/"
    }

    fun query(c: Context): List<Item> {
        val out = ArrayList<Item>()
        val folderCol = if (Build.VERSION.SDK_INT >= 29) MediaStore.MediaColumns.RELATIVE_PATH
        else MediaStore.Files.FileColumns.DATA
        val proj = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.MIME_TYPE,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.MEDIA_TYPE,
            MediaStore.MediaColumns.DATE_TAKEN,
            MediaStore.Files.FileColumns.DATE_ADDED,
            folderCol,
        )
        val sel = "${MediaStore.Files.FileColumns.MEDIA_TYPE} IN (1,3)"
        c.contentResolver.query(
            MediaStore.Files.getContentUri("external"), proj, sel, null,
            "${MediaStore.Files.FileColumns.DATE_ADDED} ASC",
        )?.use { cur ->
            while (cur.moveToNext()) {
                val taken = cur.getLong(5).takeIf { it > 0 } ?: (cur.getLong(6) * 1000)
                out.add(
                    Item(
                        cur.getLong(0), cur.getString(1) ?: "file",
                        cur.getString(2) ?: "application/octet-stream",
                        cur.getLong(3), cur.getInt(4), taken, folderOf(cur.getString(7)),
                    )
                )
            }
        }
        return out
    }
}
