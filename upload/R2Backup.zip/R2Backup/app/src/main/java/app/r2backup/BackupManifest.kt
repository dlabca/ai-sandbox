package app.r2backup

import android.content.Context
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File

/** path = logický klíč (zařízení/složka/název), obj = skutečný objekt v R2, sha = SHA-256 obsahu */
class Entry(val path: String, val obj: String, val size: Long, val mod: Long, val sha: String)

/** Lokální index zálohovaných souborů (JSON lines); kopie se ukládá i do R2 jako <zařízení>/_manifest.jsonl */
object BackupManifest {
    private val map = LinkedHashMap<String, Entry>()
    private val hashes = HashMap<String, Entry>()
    private var loaded = false
    @Volatile var changed = false

    private fun file(c: Context) = File(c.applicationContext.filesDir, "manifest.jsonl")

    private fun parse(line: String): Entry? {
        if (line.isBlank()) return null
        return try {
            val j = JSONObject(line)
            Entry(j.getString("p"), j.getString("o"), j.getLong("s"), j.getLong("m"), j.optString("h", ""))
        } catch (_: Exception) { null }
    }

    private fun toLine(e: Entry) =
        JSONObject().put("p", e.path).put("o", e.obj).put("s", e.size).put("m", e.mod).put("h", e.sha).toString()

    private fun index(e: Entry) {
        map[e.path] = e
        if (e.sha.isNotEmpty()) hashes[e.sha] = e
    }

    @Synchronized fun load(c: Context) {
        if (loaded) return
        loaded = true
        val f = file(c)
        if (!f.exists()) return
        f.forEachLine { l -> parse(l)?.let { index(it) } }
    }

    @Synchronized fun get(path: String): Entry? = map[path]

    /** Záznam se stejným obsahem; jen pokud je stále aktuální (neprošel změnou). */
    @Synchronized fun byHash(sha: String): Entry? {
        val e = hashes[sha] ?: return null
        return if (map[e.path] === e) e else null
    }

    @Synchronized fun put(e: Entry) { index(e); changed = true }
    @Synchronized fun remove(path: String) { map.remove(path); changed = true }
    @Synchronized fun refs(obj: String): Int = map.values.count { it.obj == obj }
    @Synchronized fun size(): Int = map.size
    @Synchronized fun all(): List<Entry> = ArrayList(map.values)

    @Synchronized fun clear(c: Context) {
        map.clear(); hashes.clear(); loaded = true; changed = false
        file(c).delete()
    }

    @Synchronized fun text(): String = map.values.joinToString("\n") { toLine(it) }

    @Synchronized fun mergeFrom(t: String): Int {
        var n = 0
        for (l in t.lineSequence()) {
            val e = parse(l) ?: continue
            if (!map.containsKey(e.path)) { index(e); n++ }
        }
        if (n > 0) changed = true
        return n
    }

    @Synchronized fun save(c: Context) {
        val f = file(c)
        val tmp = File(f.path + ".tmp")
        tmp.writeText(text() + "\n")
        tmp.renameTo(f)
    }

    /** Je soubor už zálohovaný (v manifestu beze změny, nebo jen ve starém seznamu ID)? */
    fun isBacked(device: String, i: Media.Item, legacy: Set<String>): Boolean {
        val e = get(Media.pathKey(device, i))
        return if (e != null) e.size == i.size && e.mod == i.modSec else i.id.toString() in legacy
    }
}

object Restore {
    /** Obnoví historii po čisté instalaci: manifest z R2 + staré objekty (rrrr/mm/ID_název). */
    fun fromR2(ctx: Context, client: R2Client, device: String): String {
        BackupManifest.load(ctx)
        var m = 0
        try {
            m = BackupManifest.mergeFrom(client.getText("$device/_manifest.jsonl"))
            BackupManifest.save(ctx)
        } catch (e: Exception) {
            L.log("Manifest v R2 nenalezen: ${e.message}")
        }
        val ids = client.listIds()
        val legacy = Store.doneSet(ctx)
        val before = legacy.size
        legacy.addAll(ids)
        Store.saveDone(ctx, legacy)
        return "Obnoveno: manifest $m záznamů, starých objektů ${legacy.size - before}"
    }

    fun push(client: R2Client, device: String) {
        val bytes = (BackupManifest.text() + "\n").toByteArray(Charsets.UTF_8)
        client.upload("$device/_manifest.jsonl", "application/x-ndjson", bytes.size.toLong(),
            { ByteArrayInputStream(bytes) }, { }, { false })
    }
}
