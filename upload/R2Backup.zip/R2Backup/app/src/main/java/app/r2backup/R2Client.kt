package app.r2backup

import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okio.BufferedSink
import okio.source
import java.io.IOException
import java.io.InputStream
import java.security.MessageDigest
import java.time.ZoneOffset
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/** Minimální S3 klient (SigV4, PUT, UNSIGNED-PAYLOAD) pro Cloudflare R2. */
class R2Client(private val cfg: Config) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .callTimeout(0, TimeUnit.SECONDS)
        .build()

    private val host = cfg.endpoint.trim().removePrefix("https://").removePrefix("http://").trimEnd('/')

    private fun enc(s: String): String {
        val sb = StringBuilder()
        for (b in s.toByteArray(Charsets.UTF_8)) {
            val c = b.toInt() and 0xff
            val ch = c.toChar()
            if ((ch in 'A'..'Z') || (ch in 'a'..'z') || (ch in '0'..'9') || ch == '-' || ch == '_' || ch == '.' || ch == '~') sb.append(ch)
            else sb.append("%%%02X".format(c))
        }
        return sb.toString()
    }

    private fun hmac(key: ByteArray, data: String): ByteArray {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(key, "HmacSHA256"))
        return m.doFinal(data.toByteArray(Charsets.UTF_8))
    }

    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
    private fun sha256(s: String) = hex(MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)))

    private fun sign(method: String, path: String): Map<String, String> {
        val now = ZonedDateTime.now(ZoneOffset.UTC)
        val amzDate = now.format(DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss'Z'"))
        val date = amzDate.substring(0, 8)
        val payload = "UNSIGNED-PAYLOAD"
        val signed = "host;x-amz-content-sha256;x-amz-date"
        val canonical = "$method\n$path\n\nhost:$host\nx-amz-content-sha256:$payload\nx-amz-date:$amzDate\n\n$signed\n$payload"
        val scope = "$date/auto/s3/aws4_request"
        val sts = "AWS4-HMAC-SHA256\n$amzDate\n$scope\n${sha256(canonical)}"
        var k = hmac(("AWS4" + cfg.secret).toByteArray(), date)
        k = hmac(k, "auto"); k = hmac(k, "s3"); k = hmac(k, "aws4_request")
        val sig = hex(hmac(k, sts))
        return mapOf(
            "x-amz-date" to amzDate,
            "x-amz-content-sha256" to payload,
            "Authorization" to "AWS4-HMAC-SHA256 Credential=${cfg.accessKey}/$scope, SignedHeaders=$signed, Signature=$sig",
        )
    }

    private fun objectPath(key: String) =
        "/" + enc(cfg.bucket) + "/" + key.split('/').joinToString("/") { enc(it) }

    fun put(key: String, mime: String, size: Long, stream: InputStream) {
        val path = objectPath(key)
        val body = object : RequestBody() {
            override fun contentType() = mime.toMediaTypeOrNull()
            override fun contentLength() = size
            override fun writeTo(sink: BufferedSink) { stream.source().use { sink.writeAll(it) } }
        }
        val rb = Request.Builder().url("https://$host$path").put(body)
        sign("PUT", path).forEach { (k, v) -> rb.header(k, v) }
        http.newCall(rb.build()).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}: ${r.body?.string()?.take(200)}")
        }
    }

    /** Ověření přístupu: HEAD na bucket. */
    fun check() {
        val path = "/" + enc(cfg.bucket)
        val rb = Request.Builder().url("https://$host$path").head()
        sign("HEAD", path).forEach { (k, v) -> rb.header(k, v) }
        http.newCall(rb.build()).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
        }
    }
}
