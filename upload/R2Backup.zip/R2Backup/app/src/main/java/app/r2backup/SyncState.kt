package app.r2backup

import java.util.concurrent.atomic.AtomicLong

/** Živý stav běžící zálohy (stejný proces jako UI). */
object SyncState {
    @Volatile var running = false
    @Volatile var stop = false
    @Volatile var total = 0
    @Volatile var done = 0
    @Volatile var failed = 0
    @Volatile var current = ""
    @Volatile var curSize = 0L
    @Volatile var curBytes = 0L
    val sent = AtomicLong(0)

    fun reset() {
        stop = false; total = 0; done = 0; failed = 0
        current = ""; curSize = 0; curBytes = 0; sent.set(0)
    }
}
