package app.r2backup

import android.content.Context
import android.content.SharedPreferences

data class Config(
    val endpoint: String,
    val bucket: String,
    val accessKey: String,
    val secret: String,
    val wifiOnly: Boolean,
)

object Store {
    fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("r2", Context.MODE_PRIVATE)

    fun load(c: Context): Config? {
        val p = prefs(c)
        val e = p.getString("endpoint", "")!!.trim()
        val b = p.getString("bucket", "")!!.trim()
        val a = p.getString("access", "")!!.trim()
        val s = p.getString("secret", "")!!.trim()
        if (e.isEmpty() || b.isEmpty() || a.isEmpty() || s.isEmpty()) return null
        return Config(e, b, a, s, p.getBoolean("wifi", true))
    }

    fun setStatus(c: Context, text: String) = prefs(c).edit().putString("status", text).apply()
}
