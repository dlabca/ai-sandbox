package app.r2backup

import android.content.Context
import android.content.SharedPreferences
import android.os.Build

data class Config(
    val endpoint: String,
    val bucket: String,
    val accessKey: String,
    val secret: String,
    val wifiOnly: Boolean,
)

object Store {
    fun prefs(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("r2", Context.MODE_PRIVATE)

    fun load(c: Context): Config? {
        val p = prefs(c)
        val e = p.getString("endpoint", "")!!.trim()
        val b = p.getString("bucket", "")!!.trim()
        val a = p.getString("access", "")!!.trim()
        val s = p.getString("secret", "")!!.trim()
        if (e.isEmpty() || b.isEmpty() || a.isEmpty() || s.isEmpty()) return null
        return Config(e, b, a, s, p.getBoolean("wifi", true))
    }

    private fun sanitize(s: String) =
        s.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifEmpty { "phone" }

    fun defaultDevice(): String = sanitize(Build.MODEL ?: "phone")

    /** Název zařízení = předpona klíčů v R2 */
    fun device(c: Context): String {
        val d = prefs(c).getString("device", "")!!.trim()
        return if (d.isEmpty()) defaultDevice() else sanitize(d)
    }

    fun setStatus(c: Context, text: String) = prefs(c).edit().putString("status", text).apply()

    fun doneSet(c: Context): MutableSet<String> =
        HashSet(prefs(c).getStringSet("done", emptySet()) ?: emptySet())

    fun saveDone(c: Context, s: Set<String>) = prefs(c).edit().putStringSet("done", HashSet(s)).apply()
}
