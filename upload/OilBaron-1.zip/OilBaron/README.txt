OIL BARON - ropna hra (vlastni, inspirovana zanrem Turmoil). Bez assetu, bez content pipeline.

Ovladani: mys / dotyk. Space = pauza, 1/2/3 = rychlost, F5 = ulozit, F9 = nacist, R = nova hra po konci.
Cil: jmeni $30000 do 200 dnu. Dluh nad $8000 = prohra.

Desktop:  cd OilBaron.Desktop && dotnet run
Android:  zip celou slozku OilBaron a hod ji do upload/ (workflow postavi APK)
