using var game = new OilBaron.Game1();
game.Run();
