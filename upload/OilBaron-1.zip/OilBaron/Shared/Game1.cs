using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Input.Touch;

namespace OilBaron
{
    public class Plot { public int Owner; public float Oil, Max; public bool Scanned; public int Rig, Price; }

    public class State
    {
        public const int W = 10, H = 6;
        public double Time;
        public int Day() { return (int)Time; }
        public float Cash = 1500, Debt, Stored;
        public int Tank, TDrill, TScan, TMkt;
        public float Base = 20, EventMul = 1, EventLeft;
        public string EventName = "";
        public Plot[] Plots = new Plot[W * H];
        public float[] RCash = { 1500, 1500 };
        public float[] Demand = new float[3];
        public float[] Sat = { 1, 1, 1 };
        public List<float> Hist = new List<float>();
        public bool Auto, Won, Lost;
        public string LostWhy = "";
    }

    public class Game1 : Game
    {
        GraphicsDeviceManager gfx; SpriteBatch sb; Texture2D px;
        State st; Random rnd = new Random();
        MouseState prevMs; KeyboardState prevKb;
        Vector2 mouse, off; float sc = 1; Matrix view = Matrix.Identity;
        bool click; int speed = 1, sel = -1; float anim;
        List<string> log = new List<string>();

        const float DaySecs = 3f;
        const int Goal = 30000, MaxDays = 200;
        static readonly string[] BName = { "Železnice", "Rafinerie", "Pašeráci" };
        static readonly float[] BMul = { 0.9f, 1.0f, 1.3f };
        static readonly float[] BCap = { 160, 110, 45 };
        static readonly string[] Owners = { "", "TY", "SMITH OIL", "TEXAS JACK" };
        static readonly Color[] OwnCol = { Color.Gray, new Color(80, 220, 100), new Color(230, 70, 70), new Color(80, 140, 250) };

        public Game1()
        {
            gfx = new GraphicsDeviceManager(this) { PreferredBackBufferWidth = 1280, PreferredBackBufferHeight = 720 };
#if ANDROID
            gfx.IsFullScreen = true;
            gfx.SupportedOrientations = DisplayOrientation.LandscapeLeft | DisplayOrientation.LandscapeRight;
#endif
            IsMouseVisible = true;
            Window.AllowUserResizing = true;
        }

        protected override void Initialize()
        {
            TouchPanel.EnableMouseTouchPoint = true;
            base.Initialize();
        }

        protected override void LoadContent()
        {
            sb = new SpriteBatch(GraphicsDevice);
            px = new Texture2D(GraphicsDevice, 1, 1);
            px.SetData(new[] { Color.White });
            NewGame();
        }

        // ---------------------------------------------------------------- hra
        int N { get { return State.W * State.H; } }
        float Cap() { return 200 + 250 * st.Tank; }
        float Price(int i) { return st.Base * st.EventMul * BMul[i] * st.Sat[i] * (1 + 0.1f * st.TMkt); }

        float Worth()
        {
            float w = st.Cash - st.Debt + st.Stored * st.Base;
            foreach (var p in st.Plots) if (p.Owner == 1) w += p.Price * 0.7f + p.Rig * 250;
            return w;
        }

        void Msg(string m) { log.Add(m); if (log.Count > 5) log.RemoveAt(0); }

        void NewGame()
        {
            st = new State(); sel = -1; log.Clear(); speed = 1;
            float[] bx = new float[5], by = new float[5], bs = new float[5], ba = new float[5];
            for (int k = 0; k < 5; k++)
            {
                bx[k] = rnd.Next(State.W); by[k] = rnd.Next(State.H);
                bs[k] = 1.0f + (float)rnd.NextDouble() * 1.2f; ba[k] = 800 + rnd.Next(1500);
            }
            for (int i = 0; i < N; i++)
            {
                int x = i % State.W, y = i / State.W; float v = 0;
                for (int k = 0; k < 5; k++)
                {
                    float dx = x - bx[k], dy = y - by[k];
                    v += ba[k] * MathF.Exp(-(dx * dx + dy * dy) / (2 * bs[k] * bs[k]));
                }
                v *= 0.6f + 0.8f * (float)rnd.NextDouble();
                if (v < 80) v = 0;
                v = MathF.Min(v, 2500);
                st.Plots[i] = new Plot { Oil = v, Max = v, Price = (int)(120 + v * 0.08f + rnd.Next(60)) };
            }
            var cand = Enumerable.Range(0, N).Where(i => st.Plots[i].Oil >= 250 && st.Plots[i].Oil <= 900).ToList();
            int s = cand.Count > 0 ? cand[rnd.Next(cand.Count)] : Enumerable.Range(0, N).OrderByDescending(i => st.Plots[i].Oil).First();
            st.Plots[s].Owner = 1; st.Plots[s].Scanned = true;
            for (int r = 0; r < 2; r++)
            {
                int i; do { i = rnd.Next(N); } while (st.Plots[i].Owner != 0);
                st.Plots[i].Owner = 2 + r;
            }
            for (int i = 0; i < 3; i++) st.Demand[i] = BCap[i];
            st.Hist.Add(st.Base);
            Msg("Klikni na pozemek: skenuj, kup, vrtej, prodavej.");
            Msg("Cil: jmeni $" + Goal + " do " + MaxDays + " dnu.");
        }

        void Tick(float d)
        {
            int before = st.Day();
            st.Time += d;
            float mult = 1 + 0.25f * st.TDrill, cap = Cap();
            foreach (var p in st.Plots)
            {
                if (p.Owner == 0 || p.Rig == 0 || p.Oil <= 0) continue;
                float rich = MathF.Min(1.5f, p.Oil / 1500f);
                float amt = MathF.Min(p.Oil, 4 * p.Rig * (0.4f + rich) * mult * d);
                if (p.Owner == 1)
                {
                    amt = MathF.Min(amt, cap - st.Stored);
                    if (amt <= 0) continue;
                    st.Stored += amt;
                }
                else st.RCash[p.Owner - 2] += amt * st.Base * st.EventMul * 0.9f;
                p.Oil -= amt;
            }
            st.Base += (20 - st.Base) * 0.03f * d + ((float)rnd.NextDouble() - 0.5f) * 2.2f * MathF.Sqrt(d);
            st.Base = MathHelper.Clamp(st.Base, 8, 45);
            for (int i = 0; i < 3; i++)
            {
                st.Demand[i] = MathF.Min(BCap[i], st.Demand[i] + BCap[i] * 0.6f * d);
                st.Sat[i] += (1 - st.Sat[i]) * 0.25f * d;
            }
            for (int k = before + 1; k <= st.Day(); k++) Daily();
        }

        void Daily()
        {
            st.Hist.Add(st.Base * st.EventMul);
            if (st.Hist.Count > 60) st.Hist.RemoveAt(0);
            st.Debt *= 1.01f;
            int rigs = st.Plots.Count(p => p.Owner == 1 && p.Rig > 0);
            st.Cash -= rigs * 6;
            if (st.Cash < 0) { st.Debt -= st.Cash; st.Cash = 0; }
            if (st.Auto) SellBest();
            Rivals(); Events();
            if (Worth() >= Goal) st.Won = true;
            else if (st.Debt > 8000) { st.Lost = true; st.LostWhy = "Dluh presahl $8000"; }
            else if (st.Day() >= MaxDays) { st.Lost = true; st.LostWhy = "Dosel cas"; }
        }

        void Rivals()
        {
            for (int r = 0; r < 2; r++)
            {
                int o = 2 + r;
                var own = Enumerable.Range(0, N).Where(i => st.Plots[i].Owner == o).ToList();
                st.RCash[r] -= own.Count(i => st.Plots[i].Rig > 0) * 6;
                if (st.RCash[r] < 0) st.RCash[r] = 0;
                if (rnd.NextDouble() > 0.6) continue;
                var noRig = own.Where(i => st.Plots[i].Rig == 0 && st.Plots[i].Oil > 80).ToList();
                if (noRig.Count > 0 && st.RCash[r] >= 500) { st.Plots[noRig[0]].Rig = 1; st.RCash[r] -= 500; continue; }
                int best = -1; float bo = 0;
                for (int k = 0; k < 6; k++)
                {
                    int i = rnd.Next(N); var p = st.Plots[i];
                    if (p.Owner == 0 && st.RCash[r] >= p.Price + 500 && p.Oil > bo) { best = i; bo = p.Oil; }
                }
                if (best >= 0 && bo > 150) { st.Plots[best].Owner = o; st.RCash[r] -= st.Plots[best].Price; continue; }
                var up = own.Where(i => st.Plots[i].Rig > 0 && st.Plots[i].Rig < 3 && st.Plots[i].Oil > 200).ToList();
                if (up.Count > 0 && st.RCash[r] > 1200) { var p = st.Plots[up[0]]; st.RCash[r] -= 400 * p.Rig; p.Rig++; }
            }
        }

        void Events()
        {
            if (st.EventLeft > 0)
            {
                st.EventLeft--;
                if (st.EventLeft <= 0) { st.EventMul = 1; st.EventName = ""; Msg("Trh se uklidnil."); }
            }
            if (rnd.NextDouble() > 0.14) return;
            var mine = Enumerable.Range(0, N).Where(i => st.Plots[i].Owner == 1 && st.Plots[i].Rig > 0).ToList();
            switch (rnd.Next(7))
            {
                case 0: if (st.EventLeft <= 0) { st.EventMul = 1.5f; st.EventLeft = 7; st.EventName = "BOOM"; Msg("BOOM! Ceny ropy rostou (+50%)"); } break;
                case 1: if (st.EventLeft <= 0) { st.EventMul = 0.65f; st.EventLeft = 8; st.EventName = "PREBYTEK"; Msg("Prebytek ropy! Ceny padaji."); } break;
                case 2: if (st.EventLeft <= 0) { st.EventMul = 1.8f; st.EventLeft = 5; st.EventName = "VALKA"; Msg("Valka! Cena ropy raketove roste."); } break;
                case 3: if (mine.Count > 0) { var p = st.Plots[mine[rnd.Next(mine.Count)]]; p.Rig = 0; Msg("POZAR! Jedna vez shorela."); } break;
                case 4: if (mine.Count > 0) { var p = st.Plots[mine[rnd.Next(mine.Count)]]; p.Oil += 600; p.Max += 600; Msg("GEJZIR! +600 bbl na jedne vezi."); } break;
                case 5: { float f = 100 + mine.Count * 40; st.Cash -= f; if (st.Cash < 0) { st.Debt -= st.Cash; st.Cash = 0; } Msg("Inspekce! Pokuta $" + (int)f); } break;
                case 6: st.Cash += 400; Msg("Statni dotace +$400"); break;
            }
        }

        void Sell(int i, bool quiet)
        {
            float amt = MathF.Min(st.Stored, st.Demand[i]);
            if (amt < 1) { if (!quiet) Msg(st.Stored < 1 ? "Nemas co prodat." : "Kupec nema zajem."); return; }
            float rev = amt * Price(i);
            st.Cash += rev; st.Stored -= amt; st.Demand[i] -= amt;
            st.Sat[i] = MathF.Max(0.5f, st.Sat[i] - amt / 400f);
            Msg("Prodano " + (int)amt + " bbl za $" + (int)rev);
            if (i == 2 && rnd.NextDouble() < 0.2)
            {
                st.Cash -= 250; Msg("Policie! Pokuta $250");
                if (st.Cash < 0) { st.Debt -= st.Cash; st.Cash = 0; }
            }
        }

        void SellBest()
        {
            foreach (int i in Enumerable.Range(0, 3).OrderByDescending(k => Price(k))) Sell(i, true);
        }

        bool Pay(float c)
        {
            if (st.Cash < c) { Msg("Nedostatek penez!"); return false; }
            st.Cash -= c; return true;
        }

        string SavePath { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "oilbaron.json"); } }
        void Save()
        {
            try { File.WriteAllText(SavePath, JsonSerializer.Serialize(st, new JsonSerializerOptions { IncludeFields = true })); Msg("Hra ulozena."); }
            catch { Msg("Ulozeni selhalo."); }
        }
        void Load()
        {
            try
            {
                var s = JsonSerializer.Deserialize<State>(File.ReadAllText(SavePath), new JsonSerializerOptions { IncludeFields = true });
                if (s == null || s.Plots == null || s.Plots.Length != N) throw new Exception();
                st = s; Msg("Hra nactena.");
            }
            catch { Msg("Nacteni selhalo."); }
        }

        // ------------------------------------------------------------- update
        void CalcView()
        {
            int w = GraphicsDevice.PresentationParameters.BackBufferWidth, h = GraphicsDevice.PresentationParameters.BackBufferHeight;
            sc = MathF.Min(w / 1280f, h / 720f);
            off = new Vector2((w - 1280 * sc) / 2, (h - 720 * sc) / 2);
            view = Matrix.CreateScale(sc) * Matrix.CreateTranslation(off.X, off.Y, 0);
        }

        bool Pressed(KeyboardState k, Keys key) { return k.IsKeyDown(key) && prevKb.IsKeyUp(key); }

        protected override void Update(GameTime gt)
        {
            var ms = Mouse.GetState(); var kb = Keyboard.GetState();
            click = ms.LeftButton == ButtonState.Pressed && prevMs.LeftButton == ButtonState.Released;
            prevMs = ms;
            CalcView();
            mouse = (new Vector2(ms.X, ms.Y) - off) / sc;
            float real = (float)gt.ElapsedGameTime.TotalSeconds;
            anim += real;
            if (Pressed(kb, Keys.Space)) speed = speed == 0 ? 1 : 0;
            if (Pressed(kb, Keys.D1)) speed = 1;
            if (Pressed(kb, Keys.D2)) speed = 2;
            if (Pressed(kb, Keys.D3)) speed = 4;
            if (Pressed(kb, Keys.F5)) Save();
            if (Pressed(kb, Keys.F9)) Load();
            if (Pressed(kb, Keys.R) && (st.Won || st.Lost)) NewGame();
#if !ANDROID
            if (Pressed(kb, Keys.Escape)) Exit();
#endif
            prevKb = kb;
            if (!st.Won && !st.Lost && speed > 0) Tick(MathF.Min(0.5f, real * speed / DaySecs));
            base.Update(gt);
        }

        // --------------------------------------------------------------- draw
        protected override void Draw(GameTime gt)
        {
            GraphicsDevice.Clear(new Color(38, 28, 22));
            sb.Begin(samplerState: SamplerState.PointClamp, transformMatrix: view);
            bool over = st.Won || st.Lost; bool endClick = click;
            if (over) click = false;
            DrawTop(); DrawMap(); DrawMarket(); DrawPlotPanel(); DrawBottom();
            if (over) { click = endClick; DrawEnd(); }
            sb.End();
            base.Draw(gt);
        }

        void Fill(Rectangle r, Color c) { sb.Draw(px, r, c); }
        void Border(Rectangle r, Color c, int t)
        {
            Fill(new Rectangle(r.X, r.Y, r.Width, t), c); Fill(new Rectangle(r.X, r.Bottom - t, r.Width, t), c);
            Fill(new Rectangle(r.X, r.Y, t, r.Height), c); Fill(new Rectangle(r.Right - t, r.Y, t, r.Height), c);
        }
        void Line(Vector2 a, Vector2 b, float th, Color c)
        {
            Vector2 d = b - a;
            sb.Draw(px, a, null, c, MathF.Atan2(d.Y, d.X), new Vector2(0, 0.5f), new Vector2(d.Length(), th), SpriteEffects.None, 0);
        }

        const string From = "ÁČĎÉĚÍŇÓŘŠŤÚŮÝŽ", To = "ACDEEINORSTUUYZ";
        static string Fix(string s)
        {
            var a = new char[s.Length];
            for (int i = 0; i < a.Length; i++)
            {
                char ch = char.ToUpperInvariant(s[i]); int k = From.IndexOf(ch);
                a[i] = k >= 0 ? To[k] : ch;
            }
            return new string(a);
        }
        static int TextW(string s, int scale) { return s.Length * 6 * scale - scale; }

        void Text(string s, float x, float y, int scale, Color c)
        {
            s = Fix(s); int cx = (int)x;
            foreach (char ch in s)
            {
                byte[] g;
                if (Font.TryGetValue(ch, out g))
                    for (int r = 0; r < 7; r++)
                        for (int b = 0; b < 5; b++)
                            if (((g[r] >> (4 - b)) & 1) != 0)
                                sb.Draw(px, new Rectangle(cx + b * scale, (int)y + r * scale, scale, scale), c);
                cx += 6 * scale;
            }
        }

        bool Btn(Rectangle r, string t, bool en = true, bool active = false)
        {
            bool hot = en && r.Contains(mouse);
            Color bg = !en ? new Color(60, 55, 50) : active ? new Color(220, 170, 50) : hot ? new Color(205, 140, 60) : new Color(140, 90, 40);
            Fill(r, bg); Border(r, Color.Black, 2);
            string f = Fix(t); int s = TextW(f, 2) <= r.Width - 6 ? 2 : 1;
            Text(t, r.X + (r.Width - TextW(f, s)) / 2, r.Y + (r.Height - 7 * s) / 2, s, en ? (active ? Color.Black : Color.White) : Color.Gray);
            if (hot && click) { click = false; return true; }
            return false;
        }

        Rectangle PlotRect(int i) { return new Rectangle(20 + (i % State.W) * 90, 70 + (i / State.W) * 90, 88, 88); }

        void DrawTop()
        {
            Fill(new Rectangle(0, 0, 1280, 56), new Color(20, 14, 10));
            Text("Den " + st.Day() + "/" + MaxDays + "   Hotovost $" + (int)st.Cash + "   Dluh $" + (int)st.Debt, 20, 8, 2, Color.White);
            Text("Ropa " + (int)st.Stored + "/" + (int)Cap() + "   Jmeni $" + (int)Worth() + " / Cil $" + Goal, 20, 32, 2, new Color(255, 210, 120));
            if (Btn(new Rectangle(900, 10, 80, 36), "Ulozit")) Save();
            if (Btn(new Rectangle(988, 10, 80, 36), "Nacist")) Load();
            if (Btn(new Rectangle(1080, 10, 42, 36), "||", true, speed == 0)) speed = 0;
            if (Btn(new Rectangle(1126, 10, 42, 36), "1x", true, speed == 1)) speed = 1;
            if (Btn(new Rectangle(1172, 10, 42, 36), "2x", true, speed == 2)) speed = 2;
            if (Btn(new Rectangle(1218, 10, 42, 36), "4x", true, speed == 4)) speed = 4;
        }

        void Derrick(Rectangle r, int lvl, Color c, bool working)
        {
            Vector2 b = new Vector2(r.Center.X, r.Bottom - 16); float h = 22 + lvl * 8;
            Line(new Vector2(b.X - 12, b.Y), new Vector2(b.X, b.Y - h), 2, c);
            Line(new Vector2(b.X + 12, b.Y), new Vector2(b.X, b.Y - h), 2, c);
            Line(new Vector2(b.X - 8, b.Y - h * 0.4f), new Vector2(b.X + 8, b.Y - h * 0.4f), 2, c);
            float k = working ? MathF.Sin(anim * 4) * 6 : 0;
            Line(new Vector2(b.X - 16, b.Y - h + k), new Vector2(b.X + 16, b.Y - h - k), 3, c);
        }

        void DrawMap()
        {
            for (int i = 0; i < st.Plots.Length; i++)
            {
                var p = st.Plots[i]; var r = PlotRect(i); Color g;
                if (p.Scanned)
                {
                    if (p.Oil < 1) g = new Color(100, 90, 80);
                    else g = Color.Lerp(new Color(120, 95, 60), new Color(20, 18, 16), MathHelper.Clamp(p.Oil / 1500f, 0, 1));
                }
                else { int n = (i * 37) % 5 * 4; g = new Color(176 - n, 138 - n, 86 - n); }
                Fill(r, g);
                if (p.Owner > 0) Border(r, OwnCol[p.Owner], 3);
                if (i == sel) Border(new Rectangle(r.X - 2, r.Y - 2, r.Width + 4, r.Height + 4), Color.White, 2);
                if (p.Scanned)
                {
                    string l = p.Oil < 1 ? "Sucho" : st.TScan >= 1 ? ((int)p.Oil).ToString()
                        : p.Oil < 100 ? "Prazdne" : p.Oil < 500 ? "Chude" : p.Oil < 1100 ? "Stredni" : "Bohate";
                    Text(l, r.X + 5, r.Y + 6, 2, Color.White);
                }
                if (p.Owner == 0) Text("$" + p.Price, r.X + 5, r.Bottom - 20, 2, Color.Yellow);
                else if (p.Rig > 0)
                {
                    Derrick(r, p.Rig, OwnCol[p.Owner], p.Oil > 0 && (p.Owner != 1 || st.Stored < Cap()));
                    Text("L" + p.Rig, r.X + 5, r.Bottom - 20, 2, Color.White);
                }
                if (click && r.Contains(mouse)) { sel = i; click = false; }
            }
        }

        void DrawMarket()
        {
            int X = 940;
            Text("Trh", X, 66, 2, Color.White);
            Text("Cena ropy $" + (st.Base * st.EventMul).ToString("0.0"), X, 86, 2, Color.Yellow);
            if (st.EventName != "") Text("Udalost: " + st.EventName + " " + (int)st.EventLeft + "d", X, 104, 2, Color.OrangeRed);
            var cr = new Rectangle(X, 124, 320, 50); Fill(cr, new Color(20, 14, 10));
            if (st.Hist.Count > 1)
            {
                float mn = st.Hist.Min() - 1, mx = st.Hist.Max() + 1;
                for (int i = 1; i < st.Hist.Count; i++)
                {
                    Vector2 a = new Vector2(cr.X + (i - 1) * 320f / 59, cr.Bottom - 3 - (st.Hist[i - 1] - mn) / (mx - mn) * 44);
                    Vector2 b = new Vector2(cr.X + i * 320f / 59, cr.Bottom - 3 - (st.Hist[i] - mn) / (mx - mn) * 44);
                    Line(a, b, 2, new Color(255, 210, 80));
                }
            }
            for (int i = 0; i < 3; i++)
            {
                int y = 184 + i * 58; var card = new Rectangle(X, y, 320, 52); Fill(card, new Color(60, 44, 32));
                Text(BName[i], X + 8, y + 6, 2, Color.White);
                Text("$" + Price(i).ToString("0.0") + "  Popt " + (int)st.Demand[i], X + 8, y + 30, 2, new Color(255, 210, 120));
                if (Btn(new Rectangle(X + 216, y + 6, 98, 40), "Prodat")) Sell(i, false);
            }
        }

        void DrawPlotPanel()
        {
            int X = 940; Fill(new Rectangle(X, 362, 320, 248), new Color(60, 44, 32));
            if (sel < 0) { Text("Vyber pozemek", X + 8, 372, 2, Color.Gray); return; }
            var p = st.Plots[sel];
            Text(p.Owner == 0 ? "Volny pozemek" : "Majitel: " + Owners[p.Owner], X + 8, 370, 2, p.Owner == 0 ? Color.White : OwnCol[p.Owner]);
            Text("Zasoby: " + (p.Scanned ? (p.Oil < 1 ? "vycerpano" : ((int)p.Oil).ToString()) : "???"), X + 8, 392, 2, Color.White);
            Text(p.Rig > 0 ? "Vrtna vez L" + p.Rig : "Bez veze", X + 8, 414, 2, Color.White);
            int y = 436;
            if ((p.Owner == 0 || p.Owner == 1) && !p.Scanned)
            {
                if (Btn(new Rectangle(X, y, 320, 40), "Skenovat $60")) { if (Pay(60)) { p.Scanned = true; Msg(p.Oil < 80 ? "Skener: nic tu neni." : "Skener: nalezena ropa!"); } }
                y += 48;
            }
            if (p.Owner == 0)
            {
                if (Btn(new Rectangle(X, y, 320, 40), "Koupit $" + p.Price)) { if (Pay(p.Price)) { p.Owner = 1; Msg("Pozemek koupen."); } }
            }
            else if (p.Owner == 1)
            {
                if (p.Rig == 0)
                {
                    if (Btn(new Rectangle(X, y, 320, 40), "Vrtat $500")) { if (Pay(500)) { p.Rig = 1; Msg(p.Oil > 80 ? "Vrt hotov. Ropa tece!" : "Vrt hotov... a je suchy."); } }
                }
                else if (p.Rig < 3)
                {
                    int c = 400 * p.Rig;
                    if (Btn(new Rectangle(X, y, 320, 40), "Vylepsit vez $" + c)) { if (Pay(c)) { p.Rig++; Msg("Vez vylepsena."); } }
                }
                else Text("Vez na maximu", X + 8, y + 12, 2, Color.Gray);
                y += 48;
                int sellv = (int)(p.Price * 0.6f + p.Rig * 200);
                if (Btn(new Rectangle(X, y, 320, 40), "Prodat pozemek $" + sellv)) { st.Cash += sellv; p.Owner = 0; p.Rig = 0; Msg("Pozemek prodan."); }
            }
            else
            {
                int c = (int)(p.Price * 2 + p.Rig * 500);
                if (Btn(new Rectangle(X, y, 320, 40), "Odkoupit $" + c)) { if (Pay(c)) { st.RCash[p.Owner - 2] += c; p.Owner = 1; Msg("Nepratelske pole prevzato!"); } }
            }
        }

        void DrawBottom()
        {
            for (int i = 0; i < log.Count; i++)
            {
                int a = 120 + 135 * (i + 1) / log.Count;
                Text(log[i], 20, 622 + i * 18, 2, new Color(a, a, a));
            }
            int X = 520, w = 176, gap = 12;
            Rectangle R(int col, int row) { return new Rectangle(X + col * (w + gap), 622 + row * 48, w, 40); }
            if (Btn(R(0, 0), "Pujcka +1000", st.Debt < 7000)) { st.Cash += 1000; st.Debt += 1000; Msg("Pujcka $1000 (urok 1%/den)"); }
            if (Btn(R(1, 0), "Splatit 1000", st.Debt > 0 && st.Cash > 0)) { float a = MathF.Min(1000, MathF.Min(st.Debt, st.Cash)); st.Cash -= a; st.Debt -= a; }
            int tc = 500 * (st.Tank + 1);
            if (Btn(R(2, 0), st.Tank < 5 ? "Sklad $" + tc : "Sklad max", st.Tank < 5)) { if (Pay(tc)) { st.Tank++; Msg("Kapacita skladu " + (int)Cap()); } }
            int dc = 800 * (st.TDrill + 1);
            if (Btn(R(3, 0), st.TDrill < 3 ? "Vrtak $" + dc : "Vrtak max", st.TDrill < 3)) { if (Pay(dc)) { st.TDrill++; Msg("Vrtna produkce +25%"); } }
            if (Btn(R(0, 1), st.TScan < 1 ? "Skener $400" : "Skener max", st.TScan < 1)) { if (Pay(400)) { st.TScan++; Msg("Skener ukazuje presne zasoby."); } }
            int mc = 600 * (st.TMkt + 1);
            if (Btn(R(1, 1), st.TMkt < 3 ? "Market. $" + mc : "Market. max", st.TMkt < 3)) { if (Pay(mc)) { st.TMkt++; Msg("Prodejni ceny +10%"); } }
            if (Btn(R(2, 1), st.Auto ? "Auto: ZAP" : "Auto: VYP", true, st.Auto)) st.Auto = !st.Auto;
            if (Btn(R(3, 1), "Prodat vse")) SellBest();
        }

        void DrawEnd()
        {
            Fill(new Rectangle(0, 0, 1280, 720), new Color(0, 0, 0, 200));
            string t = st.Won ? "Vyhral jsi!" : "Konec hry";
            Text(t, 640 - TextW(Fix(t), 6) / 2, 200, 6, st.Won ? new Color(255, 215, 0) : Color.OrangeRed);
            string s = "Den " + st.Day() + "   Jmeni $" + (int)Worth();
            Text(s, 640 - TextW(Fix(s), 3) / 2, 300, 3, Color.White);
            if (st.Lost) Text(st.LostWhy, 640 - TextW(Fix(st.LostWhy), 3) / 2, 340, 3, Color.Gray);
            if (Btn(new Rectangle(540, 420, 200, 50), "Nova hra")) NewGame();
        }

        // -------------------------------------------------------- bitmap font
        static readonly Dictionary<char, byte[]> Font = BuildFont();
        static Dictionary<char, byte[]> BuildFont()
        {
            string[] d = {
                "A:0E,11,11,1F,11,11,11", "B:1E,11,11,1E,11,11,1E", "C:0E,11,10,10,10,11,0E", "D:1E,11,11,11,11,11,1E",
                "E:1F,10,10,1E,10,10,1F", "F:1F,10,10,1E,10,10,10", "G:0E,11,10,17,11,11,0F", "H:11,11,11,1F,11,11,11",
                "I:0E,04,04,04,04,04,0E", "J:07,02,02,02,02,12,0C", "K:11,12,14,18,14,12,11", "L:10,10,10,10,10,10,1F",
                "M:11,1B,15,15,11,11,11", "N:11,19,15,13,11,11,11", "O:0E,11,11,11,11,11,0E", "P:1E,11,11,1E,10,10,10",
                "Q:0E,11,11,11,15,12,0D", "R:1E,11,11,1E,14,12,11", "S:0F,10,10,0E,01,01,1E", "T:1F,04,04,04,04,04,04",
                "U:11,11,11,11,11,11,0E", "V:11,11,11,11,11,0A,04", "W:11,11,11,15,15,15,0A", "X:11,11,0A,04,0A,11,11",
                "Y:11,11,0A,04,04,04,04", "Z:1F,01,02,04,08,10,1F",
                "0:0E,11,13,15,19,11,0E", "1:04,0C,04,04,04,04,0E", "2:0E,11,01,02,04,08,1F", "3:1F,02,04,02,01,11,0E",
                "4:02,06,0A,12,1F,02,02", "5:1F,10,1E,01,01,11,0E", "6:06,08,10,1E,11,11,0E", "7:1F,01,02,04,08,08,08",
                "8:0E,11,11,0E,11,11,0E", "9:0E,11,11,0F,01,02,0C",
                ".:00,00,00,00,00,0C,0C", ",:00,00,00,00,0C,04,08", "::00,0C,0C,00,0C,0C,00", "-:00,00,00,1F,00,00,00",
                "+:00,04,04,1F,04,04,00", "/:01,02,02,04,08,08,10", "%:18,19,02,04,08,13,03", "!:04,04,04,04,04,00,04",
                "?:0E,11,01,02,04,00,04", "$:04,0F,14,0E,05,1E,04", "(:02,04,08,08,08,04,02", "):08,04,02,02,02,04,08",
                "|:04,04,04,04,04,04,04", "=:00,1F,00,1F,00,00,00", "*:00,0A,04,1F,04,0A,00"
            };
            var m = new Dictionary<char, byte[]>();
            m[' '] = new byte[7];
            foreach (var e in d)
            {
                var parts = e.Substring(2).Split(',');
                var b = new byte[7];
                for (int i = 0; i < 7; i++) b[i] = Convert.ToByte(parts[i], 16);
                m[e[0]] = b;
            }
            return m;
        }
    }
}
