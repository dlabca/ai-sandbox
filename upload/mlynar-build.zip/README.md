# Mlynář

Příběhová hra ze středověké vsi (1347, Čechy). Jsi mlynář Jan, otec zemřel a nechal ti mlýn a dluh u pána z Dubu.
Máš sedm dní, než přijede správce Hynek pro 48 grošů. Co uděláš?

## Jak se hraje
- Chodíš po 3D low-poly vesnici (levý palec = joystick, pravý palec = rozhlížení).
- **MLUVIT** (tlačítko vpravo dole) u postav a míst: mlýnský kámen, dům, sousedé. **DENÍK** nahoře vpravo ukazuje cíl.
- **Čas** má čtyři části dne (ráno, poledne, odpoledne, večer). Mletí a oprava kola zaberou část dne. V domě jdeš spát a nastane další den.
- **Mlýn:** přijmi zakázky, mel, vydej mouku. Kolo se opotřebovává a časem ho musíš opravit.
- **Volby mají následky:** poctivá míra, chamtivost, falešná závaží od obchodníka Oty, almužna, zpověď, pomoc sousedům při bouři.
- Pět konců podle toho, co jsi udělal: poctivý mlynář, tichý zbohatlík, odhalený šidič, mlýn vsi, bez mlýna.

## PC test
WASD pohyb, šipky rozhlížení, F mluvit, J deník, 1-5 nebo mezerník = volby v dialogu.
