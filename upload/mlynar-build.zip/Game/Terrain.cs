using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;

namespace Mlynar
{
    /// <summary>Udoli s potokem: hladky low-poly teren, cesty a pole se barvi podle souradnic.</summary>
    public sealed class Terrain
    {
        public const int Cells = 100;
        public const float CellSize = 2f;
        public const float Size = Cells * CellSize;
        public const int ChunkCells = 20;
        public const int ChunkCount = Cells / ChunkCells;

        public const float RiverHalf = 4.5f;
        public const float WaterY = 6.6f;
        public const float BedY = 6.0f;
        public const float FlatY = 8.0f;

        private readonly float[,] h = new float[Cells + 1, Cells + 1];

        public readonly List<float[]> Roads = new List<float[]>();
        public readonly List<float[]> Fields = new List<float[]>();

        public static float RiverX(float z)
        {
            return 120f + 10f * MathF.Sin(z / 28f);
        }

        private static float Smooth(float t)
        {
            t = MathHelper.Clamp(t, 0f, 1f);
            return t * t * (3f - 2f * t);
        }

        private static float Dist(float ax, float az, float bx, float bz)
        {
            float dx = ax - bx, dz = az - bz;
            return MathF.Sqrt(dx * dx + dz * dz);
        }

        public void Generate(int seed, float millX, float millZ)
        {
            for (int i = 0; i <= Cells; i++)
                for (int j = 0; j <= Cells; j++)
                {
                    float x = i * CellSize;
                    float z = j * CellSize;
                    float n = 0.6f * Noise.ValueNoise(x / 45f, z / 45f, seed) + 0.4f * Noise.ValueNoise(x / 16f, z / 16f, seed + 1);
                    float hh = FlatY + (n - 0.5f) * 4f;

                    float dc = Dist(x, z, 100f, 100f);
                    float outer = MathF.Max(0f, dc - 62f);
                    hh += outer * 0.28f + outer * outer * 0.004f + (n - 0.5f) * outer * 0.25f;

                    float dm = Dist(x, z, 26f, 32f);
                    hh += 14f * MathF.Exp(-(dm * dm) / (2f * 16f * 16f));

                    float w1 = Smooth(1f - Dist(x, z, 76f, 100f) / 42f);
                    float w2 = Smooth(1f - Dist(x, z, millX, millZ) / 16f);
                    float w = MathF.Max(w1, w2);
                    hh = MathHelper.Lerp(hh, FlatY, w);

                    float d = MathF.Abs(x - RiverX(z));
                    if (d < RiverHalf + 5f)
                    {
                        float t = Smooth((d - RiverHalf) / 5f);
                        hh = MathHelper.Lerp(BedY, hh, t);
                    }

                    int edge = Math.Min(Math.Min(i, j), Math.Min(Cells - i, Cells - j));
                    if (edge < 4) hh += (4 - edge) * 5f;

                    h[i, j] = hh;
                }
        }

        public float HeightAt(float x, float z)
        {
            if (x < 0f) x = 0f;
            if (z < 0f) z = 0f;
            if (x > Size - 0.001f) x = Size - 0.001f;
            if (z > Size - 0.001f) z = Size - 0.001f;
            float gx = x / CellSize;
            float gz = z / CellSize;
            int i = (int)gx;
            int j = (int)gz;
            float fx = gx - i;
            float fz = gz - j;
            float h00 = h[i, j];
            float h10 = h[i + 1, j];
            float h01 = h[i, j + 1];
            float h11 = h[i + 1, j + 1];
            if (fx >= fz) return h00 + (h10 - h00) * fx + (h11 - h10) * fz;
            return h00 + (h11 - h01) * fx + (h01 - h00) * fz;
        }

        private static float SegDist(float px, float pz, float ax, float az, float bx, float bz)
        {
            float vx = bx - ax, vz = bz - az;
            float wx = px - ax, wz = pz - az;
            float l2 = vx * vx + vz * vz;
            float t = l2 < 1e-6f ? 0f : MathHelper.Clamp((wx * vx + wz * vz) / l2, 0f, 1f);
            float cx = ax + vx * t, cz = az + vz * t;
            return Dist(px, pz, cx, cz);
        }

        public float RoadDist(float x, float z)
        {
            float best = 999f;
            for (int i = 0; i < Roads.Count; i++)
            {
                float[] r = Roads[i];
                float d = SegDist(x, z, r[0], r[1], r[2], r[3]);
                if (d < best) best = d;
            }
            return best;
        }

        public bool InField(float x, float z)
        {
            for (int i = 0; i < Fields.Count; i++)
            {
                float[] f = Fields[i];
                if (x >= f[0] && x <= f[2] && z >= f[1] && z <= f[3]) return true;
            }
            return false;
        }

        private Color ColorFor(Vector3 a, Vector3 b, Vector3 c, int i, int j, int tri)
        {
            Vector3 n = Vector3.Cross(b - a, c - a);
            float len = n.Length();
            float ny = len > 1e-6f ? MathF.Abs(n.Y) / len : 1f;
            float cx = (a.X + b.X + c.X) / 3f;
            float cz = (a.Z + b.Z + c.Z) / 3f;
            float avg = (a.Y + b.Y + c.Y) / 3f;
            Color col;
            if (avg < WaterY + 0.15f) col = new Color(150, 138, 108);
            else if (ny < 0.78f) col = new Color(124, 118, 110);
            else if (RoadDist(cx, cz) < 1.5f) col = new Color(162, 132, 92);
            else if (InField(cx, cz)) col = new Color(128, 98, 60);
            else if (avg > 20f) col = new Color(112, 128, 92);
            else col = Noise.Lerp(new Color(104, 160, 70), new Color(78, 132, 60), (avg - 7f) / 12f);
            return Noise.Vary(col, 0.07f, i * 2 + tri, j, 77);
        }

        public void BuildChunk(MeshBuilder mb, int cx, int cz)
        {
            mb.Clear();
            for (int ci = 0; ci < ChunkCells; ci++)
                for (int cj = 0; cj < ChunkCells; cj++)
                {
                    int i = cx * ChunkCells + ci;
                    int j = cz * ChunkCells + cj;
                    float x0 = i * CellSize;
                    float x1 = x0 + CellSize;
                    float z0 = j * CellSize;
                    float z1 = z0 + CellSize;
                    Vector3 p00 = new Vector3(x0, h[i, j], z0);
                    Vector3 p10 = new Vector3(x1, h[i + 1, j], z0);
                    Vector3 p11 = new Vector3(x1, h[i + 1, j + 1], z1);
                    Vector3 p01 = new Vector3(x0, h[i, j + 1], z1);

                    Vector3 cenA = (p00 + p10 + p11) / 3f;
                    mb.Tri(p00, p10, p11, ColorFor(p00, p10, p11, i, j, 0), cenA - new Vector3(0f, 5f, 0f));
                    Vector3 cenB = (p00 + p11 + p01) / 3f;
                    mb.Tri(p00, p11, p01, ColorFor(p00, p11, p01, i, j, 1), cenB - new Vector3(0f, 5f, 0f));
                }
        }
    }
}
