using System;
using System.Collections.Generic;

namespace Mlynar
{
    public sealed class Choice
    {
        public string Label;
        public Func<GameState, string> LabelFn;
        public string Next;
        public Func<GameState, string> NextFn;
        public Func<GameState, bool> Cond;
        public Action<GameState> Fx;

        public string GetLabel(GameState s)
        {
            return LabelFn != null ? LabelFn(s) : Label;
        }

        public string GetNext(GameState s)
        {
            return NextFn != null ? NextFn(s) : Next;
        }
    }

    public sealed class Node
    {
        public string Id;
        public string Speaker;
        public Func<GameState, string> Text;
        public Action<GameState> OnEnter;
        public readonly List<Choice> Choices = new List<Choice>();
    }

    /// <summary>Cely pribeh: uzly dialogu s volbami, podminkami a efekty na stav hry.</summary>
    public static class Story
    {
        public static readonly Dictionary<string, Node> Nodes = new Dictionary<string, Node>();

        private static Node N(string id, string speaker, string text, Action<GameState> onEnter = null)
        {
            return N(id, speaker, s => text, onEnter);
        }

        private static Node N(string id, string speaker, Func<GameState, string> text, Action<GameState> onEnter = null)
        {
            Node n = new Node();
            n.Id = id;
            n.Speaker = speaker;
            n.Text = text;
            n.OnEnter = onEnter;
            Nodes[id] = n;
            return n;
        }

        private static Node C(this Node n, string label, string next, Func<GameState, bool> cond = null, Action<GameState> fx = null)
        {
            Choice c = new Choice();
            c.Label = label;
            c.Next = next;
            c.Cond = cond;
            c.Fx = fx;
            n.Choices.Add(c);
            return n;
        }

        private static Node CL(this Node n, Func<GameState, string> label, string next, Func<GameState, bool> cond = null, Action<GameState> fx = null)
        {
            Choice c = new Choice();
            c.LabelFn = label;
            c.Next = next;
            c.Cond = cond;
            c.Fx = fx;
            n.Choices.Add(c);
            return n;
        }

        private static Node CF(this Node n, string label, Func<GameState, string> nextFn, Func<GameState, bool> cond = null, Action<GameState> fx = null)
        {
            Choice c = new Choice();
            c.Label = label;
            c.NextFn = nextFn;
            c.Cond = cond;
            c.Fx = fx;
            n.Choices.Add(c);
            return n;
        }

        private static string Rep(int r)
        {
            if (r <= -3) return "ŠPATNÁ";
            if (r <= 1) return "OBYČEJNÁ";
            if (r <= 4) return "DOBRÁ";
            return "VÝBORNÁ";
        }

        static Story()
        {
            // ------------------------------------------------------------ uvod
            N("intro1", "VYPRAVĚČ", "Léta Páně 1347. Mlýn u Černého potoka. Loni v zimě ti zemřel otec a nechal ti dvě věci: starý mlýn a dluh u pána z Dubu.")
                .C("Dál", "intro2");
            N("intro2", "VYPRAVĚČ", "Správce Hynek přijede sedmého dne. Chce čtyřicet osm grošů, jinak mlýn propadne pánovi. Máš týden, mlýnské kolo a sousedy, kteří potřebují mouku.")
                .C("Začít", null, null, s => s.Message = "PROMLUV SE ŽENOU DOROTOU U DOMU");

            // ------------------------------------------------------------ Dorota
            N("dorota_d1", "DOROTA", "Dobré ráno, Jane. Matěj už čeká u mlýna se čtyřmi pytli žita. Pomel mu je a vezmi si svůj podíl. A pamatuj, sedmého dne přijede Hynek.", s => s.SetFlag("dorota1"))
                .C("Co když dluh nezaplatím?", "dorota_d1b")
                .C("Jdu na to.", null);
            N("dorota_d1b", "DOROTA", "Pak přijdeme o mlýn i o střechu nad hlavou. Tvůj otec to věděl. Proto dřel od svítání do tmy... a občas trochu přidal na míru, aby vyšli.")
                .C("Otec šidil?", "dorota_d1c")
                .C("Dost. Jdu mlít.", null);
            N("dorota_d1c", "DOROTA", "Každý mlynář prý trochu šidí, říkají lidé. Ale ty víš, co je správné. Rozhodnout se musíš sám. Já budu s tebou, ať zvolíš cokoliv.")
                .C("Rozumím.", null);
            N("dorota_idle", "DOROTA", DorotaIdle)
                .C("Jdu dál.", null);

            // ------------------------------------------------------------ rana
            N("day2_morning", "VYPRAVĚČ", "Druhý den. Kolo se v noci poškodilo a mele jen napůl. Oprava stojí šest grošů a půl dne práce. Dnes se ve vsi objevil cizí obchodník s vozem.", s => s.Wheel = Math.Min(s.Wheel, 40))
                .C("Dál", null);
            N("day3_morning", "VYPRAVĚČ", "Třetí den. Ve vsi se šeptá, že správce Hynek jede dřív a nese špatné zprávy.")
                .C("Dál", null);
            N("day4_morning", "VYPRAVĚČ", "Čtvrtý den. Pekař Bořivoj chystá posvícení a potřebuje hodně mouky. Dobře zaplatí, ale chce ji poctivou.")
                .C("Dál", null);
            N("day5_morning", "VYPRAVĚČ", "Pátý den. Richtář Vavřinec obchází řemeslníky a přeměřuje míry a závaží. Dnes přijde i k tobě.")
                .C("Dál", null);
            N("day6_morning", "VYPRAVĚČ", "Šestý den. Obloha je rudá a vítr sílí. Bude bouřka.")
                .C("Dál", null);
            N("day7_morning", "VYPRAVĚČ", "Sedmý den. Dnes přijede Hynek. Čas běží do večera, rozhodni, jak ho přivítáš.")
                .C("Dál", null);

            // ------------------------------------------------------------ mlyn
            N("mill", "MLÝN", s => "KOLO: " + s.Wheel + "/100 (ZVLÁDNE " + s.Capacity + " PYTLŮ)\nČEKÁ NA MLETÍ: " + s.PendingSacks + " PYTLŮ, HOTOVO: " + s.ReadySacks + "\nČAS: " + s.SegmentName + (s.Segment >= 3 ? " - MLÝN JE ZAVŘENÝ" : ""))
                .CL(s => "Přijmout zakázky ze vsi (" + GameState.GeneralSacks[s.Day] + " pytlů)", "mill",
                    s => !s.GeneralToday && s.Segment < 3 && GameState.GeneralSacks[s.Day] > 0,
                    s => { s.AddOrder("village", GameState.GeneralSacks[s.Day], 2, false); s.GeneralToday = true; })
                .CL(s => "Přijmout zakázky a použít falešné závaží", "mill",
                    s => !s.GeneralToday && s.Segment < 3 && s.HasFW && GameState.GeneralSacks[s.Day] > 0,
                    s => { s.AddOrder("village", GameState.GeneralSacks[s.Day], 2, true); s.GeneralToday = true; })
                .C("Mlít obilí (zabere část dne)", "mill_result", s => s.PendingSacks > 0 && s.Segment < 3, s => s.Message = s.Grind())
                .C("Vydat hotovou mouku sousedům", "mill_pay", s => s.HasReady("village"), s => s.Deliver("village"))
                .C("Opravit kolo (6 grošů, půl dne)", "mill", s => s.Wheel < 100 && s.Money >= 6 && s.Segment < 3,
                    s => { s.Money -= 6; s.Wheel = 100; s.Advance(1); })
                .C("Odejít", null);
            N("mill_result", "MLÝN", s => s.Message).C("Dál", "mill");
            N("mill_pay", "MLÝN", s => "Sousedé si odnesli mouku a zaplatili ti " + s.LastPay + " grošů.").C("Dál", "mill");

            // ------------------------------------------------------------ domov
            N("home", "DOMOV", s => "Dům u mlýna. Den " + s.Day + ", " + s.SegmentName + ". " + (s.Day >= 7 ? "Dnes spát nemůžeš, dluh se musí vyřešit." : "Dorota čeká venku před domem."))
                .C("Odpočinout si (přeskočit část dne)", "home", s => s.Segment < 3, s => s.Advance(1))
                .C("Jít spát (konec dne)", null, s => s.Day < 7, s => s.PendingSleep = true)
                .C("Odejít", null);

            // ------------------------------------------------------------ denik
            N("journal", "DENÍK", s => "DEN " + s.Day + " - " + s.SegmentName + "\n" + s.Objective() + "\nDLUH: " + s.Debt + "   GROŠE: " + s.Money + "   MOUKA NA PRODEJ: " + s.Flour + "\nPOVĚST VE VSI: " + Rep(s.RepVillage) + "   U PÁNA: " + Rep(s.RepLord))
                .C("Zavřít", null);

            // ------------------------------------------------------------ Matej
            N("matej_d1", "MATĚJ", "Pozdrav pánbůh, mlynáři! Přivezl jsem čtyři pytle žita. Kolik z toho si vezmeš na mlecí podíl?", s => s.SetFlag("matej1"))
                .C("Obvyklou desetinu, poctivě.", "matej_ok", null, s => s.AddOrder("matej", 4, 2, false))
                .C("Dvě desetiny. Mám dluhy.", "matej_greedy", null, s => { s.AddOrder("matej", 4, 3, false); s.RepVillage -= 1; })
                .C("Použít falešné závaží.", "matej_ok", s => s.HasFW, s => s.AddOrder("matej", 4, 2, true));
            N("matej_ok", "MATĚJ", "Dobrá. Přijdu si pro mouku, až bude hotová.").C("Namelu to co nejdřív.", null);
            N("matej_greedy", "MATĚJ", "Dvě desetiny? To je dost, ale co naděláme. Dobrá.").C("Děkuji.", null);
            N("matej_wait", "MATĚJ", "Mouka ještě není hotová, mlynáři. Zajdi k mlýnskému kameni.").C("Dobře.", null);
            N("matej_deliver", "MATĚJ", s => "Moje mouka! Díky, Jane. Tady je zaplacení: " + s.LastPay + " grošů.", s => s.Deliver("matej"))
                .C("Šťastnou cestu.", null);
            N("matej_d4", "MATĚJ", "Mlynáři, sklizeň dopadla dobře! Mám tři pytle navíc. Zase za desetinu?", s => s.SetFlag("matej4"))
                .C("Za desetinu, poctivě.", "matej_ok", null, s => s.AddOrder("matej", 3, 2, false))
                .C("Použít falešné závaží.", "matej_ok", s => s.HasFW, s => s.AddOrder("matej", 3, 2, true))
                .C("Teď nemám čas.", null, null, s => s.Flags.Remove("matej4"));
            N("matej_idle", "MATĚJ", "Sklizeň letos... Bůh dá, příští rok bude lépe.").C("Hodně štěstí.", null);

            // ------------------------------------------------------------ Katerina
            N("kat_d2", "KATEŘINA", "Dobrý den, Janku. Mám jen dva pytle žita a nemám čím zaplatit. Tvůj otec mi vždycky pomohl, když zemřel můj muž.", s => s.SetFlag("kat1"))
                .C("Namelu ti to zadarmo.", "kat_thanks", null, s => { s.AddOrder("kat", 2, 0, false); s.RepVillage += 2; s.SetFlag("katFree"); })
                .C("Zaplatíš po sklizni, groš za pytel.", "kat_thanks2", null, s => s.AddOrder("kat", 2, 1, false))
                .C("Nemohu, dluh mě tlačí.", "kat_sad", null, s => s.RepVillage -= 1);
            N("kat_thanks", "KATEŘINA", "Pánbůh ti to oplatí, Jane. To nikdy nezapomenu.").C("Rádo se stalo.", null);
            N("kat_thanks2", "KATEŘINA", "Děkuji. Zaplatím, jak to půjde.").C("Dobře.", null);
            N("kat_sad", "KATEŘINA", "Rozumím. Každý máme svůj kříž.").C("Promiň.", null);
            N("kat_wait", "KATEŘINA", "Moje mouka ještě není hotová? Nespěchám, Janku.").C("Brzy.", null);
            N("kat_deliver", "KATEŘINA", s => s.LastPay > 0 ? "Děkuji, Janku. Tady je " + s.LastPay + " grošů, víc nemám." : "Pánbůh ti to oplatí. Nemám čím zaplatit, ale nezapomenu na to.", s => s.Deliver("kat"))
                .C("Pozdravuj děti.", null);
            N("kat_idle", "KATEŘINA", "Do zimy musím ještě upříst len. Doufám, že bude dost dřeva na topení.").C("Nashledanou.", null);

            // ------------------------------------------------------------ pekar
            N("baker_shop", "BOŘIVOJ", s => "Dobrý den, mlynáři. Mouka je vždycky vítaná. Na prodej máš " + s.Flour + " pytlů. Platím tři groše za pytel.")
                .C("Prodat jeden pytel (3 groše)", "baker_shop", s => s.Flour >= 1, s => { s.Flour -= 1; s.Money += 3; })
                .C("Prodat všechny pytle", "baker_shop", s => s.Flour >= 2, s => { s.Money += 3 * s.Flour; s.Flour = 0; })
                .C("Jen se dívám.", null);
            N("baker_d4", "BOŘIVOJ", "Mlynáři! Posvícení se blíží a já potřebuji šest pytlů mouky. Dám po třech grošů za pytel, ale mouka musí být čistá a poctivá.", s => s.SetFlag("baker4"))
                .C("Přijímám zakázku.", "baker_ok", null, s => s.AddOrder("baker", 6, 3, false))
                .C("Použít falešné závaží.", "baker_ok", s => s.HasFW, s => { s.AddOrder("baker", 6, 3, true); s.Suspicion += 1; })
                .C("Teď ne.", null, null, s => s.Flags.Remove("baker4"));
            N("baker_ok", "BOŘIVOJ", "Výborně. Mouku mi přines, až bude hotová. Šest pytlů naráz, ať upeču dost chleba.").C("Dohodnuto.", null);
            N("baker_wait", "BOŘIVOJ", "Mouka ještě není hotová? Posvícení nepočká!").C("Pracuji na tom.", null);
            N("baker_deliver", "BOŘIVOJ", s => "Skvělé! Tady je " + s.LastPay + " grošů. Posvícení bude veselé!", s => s.Deliver("baker"))
                .C("Přeji dobrou chuť.", null);

            // ------------------------------------------------------------ farar
            N("priest_main", "OTEC TOMÁŠ", "Pokoj s tebou, synu. Tvůj otec byl čestný muž. Pán Bůh hledí na míru ve vahách i na míru v srdci.")
                .C("Dát almužnu (2 groše)", "priest_alms", s => s.Money >= 2 && !s.Flag("alms" + s.Day), s => { s.Money -= 2; s.RepVillage += 1; s.SetFlag("alms" + s.Day); })
                .C("Vyzpovídat se z podvodu", "priest_confess", s => s.Cheats > 0 && !s.Confessed, s => { s.Confessed = true; s.Suspicion = Math.Max(0, s.Suspicion - 2); s.RepVillage += 1; })
                .C("Požádat o radu", "priest_advice")
                .C("Odejít", null);
            N("priest_alms", "OTEC TOMÁŠ", "Bůh ti žehnej, Jane. Dobré skutky se vracejí.").C("Amen.", null);
            N("priest_confess", "OTEC TOMÁŠ", "Je dobře, že to přiznáváš. Odpusť ti Pán. A zkus to napravit, dokud je čas.").C("Děkuji, otče.", null);
            N("priest_advice", "OTEC TOMÁŠ", "Dluh se dá splatit i bez hříchu. Sousedé pomáhají tomu, kdo pomáhal jim. Nezapomeň na ty nejchudší.").C("Zamyslím se.", null);

            // ------------------------------------------------------------ richtar
            N("richtar_idle", "RICHTÁŘ VAVŘINEC", s => s.Day >= 6 ? "Bouře nikoho nešetří, mlynáři. V nouzi se pozná, kdo je sousedem." : "Dobrý den, mlynáři. Kdo pomáhá vsi, tomu ves pomůže, to si pamatuj.")
                .C("Nashledanou.", null);
            N("inspect", "RICHTÁŘ VAVŘINEC", "Jane, dnes přeměřuji míry a závaží u všech řemeslníků. Otevři truhlu se závažími.", s => s.SetFlag("inspected"))
                .CF("Otevřít truhlu", InspectNext);
            N("inspect_caught", "RICHTÁŘ VAVŘINEC", "Falešná závaží! Tohle je podvod na celé vsi. Pokuta deset grošů a tvoje čest je pryč.",
                s => { s.Money -= Math.Min(10, s.Money); s.RepVillage -= 4; s.Caught = true; s.HasFW = false; })
                .C("To je můj konec...", null);
            N("inspect_warn", "RICHTÁŘ VAVŘINEC", "Něco se mi nezdá, ale nemám důkaz. Dávej pozor, mlynáři, lidé mluví.", s => s.RepVillage -= 1)
                .C("Jsem v právu.", null);
            N("inspect_clean", "RICHTÁŘ VAVŘINEC", "Míry sedí. Poctivé řemeslo, takové má být. Tady je pochvala a dva groše od obce.", s => { s.RepVillage += 1; s.Money += 2; })
                .C("Děkuji, richtáři.", null);

            // ------------------------------------------------------------ Hynek
            N("hynek_d3", "SPRÁVCE HYNEK", "Mlynáři Jane. Pán z Dubu zvýšil úrok: místo čtyřiceti osmi grošů žádá padesát osm. Válečné časy, víš.", s => s.SetFlag("hynek3"))
                .C("Zaplatím osm grošů hned, jako důkaz dobré vůle.", "hynek_d3_a", s => s.Money >= 8, s => { s.Money -= 8; s.Debt -= 8; s.RepLord += 1; })
                .C("Dám ti pytel mouky pro tvého pána.", "hynek_d3_b", s => s.Flour >= 1, s => { s.Flour -= 1; s.RepLord += 1; })
                .C("To je nespravedlivé!", "hynek_d3_c", null, s => { s.Debt += 10; s.RepLord -= 2; });
            N("hynek_d3_a", "SPRÁVCE HYNEK", "Rozumný muž. Pán se to dozví. Úrok zůstane na čtyřiceti osmi, osm grošů ti odečtu.").C("Děkuji.", null);
            N("hynek_d3_b", "SPRÁVCE HYNEK", "Pytel mouky... Pán má rád chleba. Dobrá, úrok zůstane na čtyřiceti osmi.").C("Děkuji.", null);
            N("hynek_d3_c", "SPRÁVCE HYNEK", "Pán nespravedlnost nezná, mlynáři. Padesát osm grošů. A pomysli, jak budeš mluvit sedmého dne.").C("Uvidíme.", null);
            N("hynek_idle", "SPRÁVCE HYNEK", "Mlýn se sám nezaplatí. Uvidíme se sedmého dne.").C("Nashledanou.", null);
            N("hynek_final", "SPRÁVCE HYNEK", s => "Je to tady, mlynáři. Dluh činí " + s.Debt + " grošů. " + (s.Caught ? "Slyšel jsem, jak jsi šidil míru. To se připočítá. " : "") + "Máš ty peníze? Máš " + s.Money + ".",
                s => { if (!s.Flag("finalcalc")) { s.SetFlag("finalcalc"); if (s.Caught) s.Debt += 10; if (s.RepLord <= -3) s.Debt += 5; } })
                .CF("Zaplatit celý dluh", s => s.Caught ? "end_caught" : (s.Cheats > 0 ? "end_cheat" : "end_honest"), s => s.Money >= s.Debt, s => { s.Money -= s.Debt; s.Debt = 0; })
                .C("Zaplatit, co mám, a prosit o čas", "hynek_plead", s => s.Money > 0 && s.Money < s.Debt, s => { s.Debt -= s.Money; s.Money = 0; })
                .C("Požádat sousedy o pomoc", "village_help", s => s.RepVillage >= 3)
                .C("Odmítnout zaplatit", "end_lost")
                .C("Ještě chvíli počkat", null);
            N("hynek_plead", "SPRÁVCE HYNEK", "Částečná platba? Pán potřebuje všechno. Ale pokud ti pomohou sousedé, nechám je promluvit.")
                .CF("Zavolat sousedy", s => s.RepVillage >= 3 ? "village_help" : "end_lost");
            N("village_help", "VYPRAVĚČ", s => "Ves se sešla na návsi. Kateřina, Matěj, pekař i farář. Dohromady složili " + (s.RepVillage * 3 + (s.Flag("katFree") ? 3 : 0)) + " grošů.",
                s => { if (!s.Flag("helped")) { s.SetFlag("helped"); s.Money += s.RepVillage * 3 + (s.Flag("katFree") ? 3 : 0); } })
                .CF("Předat peníze Hynkovi", s => s.Money >= s.Debt ? "end_community" : "end_lost", null, s => { if (s.Money >= s.Debt) { s.Money -= s.Debt; s.Debt = 0; } });

            // ------------------------------------------------------------ Ota (podvodnik)
            N("ota_offer", "OBCHODNÍK OTA", "Hej, mlynáři! Slyšel jsem o tvém dluhu. Mám pro tebe zázrak: závaží, která váží o pětinu méně, než ukazují. Za pět grošů je máš.")
                .C("Koupit závaží (5 grošů)", "ota_bought", s => s.Money >= 5 && !s.HasFW, s => { s.Money -= 5; s.HasFW = true; })
                .C("To je podvod. Vypadni.", "ota_refused", null, s => { s.RefusedOta = true; s.RepVillage += 1; })
                .C("Rozmyslím si to.", null);
            N("ota_bought", "OBCHODNÍK OTA", "Rozumný obchod. Jen ať tě nikdo nenachytá. Kdo šidí, musí mít štěstí.").C("Mlčet jako hrob.", null);
            N("ota_refused", "OBCHODNÍK OTA", "Jak chceš. Poctivost je krásná věc, dokud se z ní dá najíst.").C("Nashledanou.", null);
            N("ota_idle", "OBCHODNÍK OTA", "Hezký den! Koupíš něco z vozu? Dnes už nic pro tebe nemám.").C("Nashledanou.", null);

            // ------------------------------------------------------------ bourka
            N("storm", "VYPRAVĚČ", "Šestý den. V noci se zvedl vítr a přišla bouřka. Potok se vylil z břehů. U mlýna praská hráz a zároveň voda ohrožuje obilné sklady ve vsi.")
                .C("Zachránit mlýn.", "storm_a", null, s => { s.NextDay(); s.RepVillage -= 1; })
                .C("Pomoci sousedům s obilím.", "storm_b", null, s => { s.NextDay(); s.Wheel = Math.Max(0, s.Wheel - 50); s.RepVillage += 3; });
            N("storm_a", "VYPRAVĚČ", "Mlýn jsi zachránil, ale ráno ves hořce vzpomíná, kdo nepřišel pomoci.").C("Dál", "day7_morning");
            N("storm_b", "VYPRAVĚČ", "Obilí ve vsi je zachráněno a lidé ti děkují. Kolo je ale poškozené a hráz budeš muset spravit.").C("Dál", "day7_morning");

            // ------------------------------------------------------------ konce
            Ending("end_honest", "KONEC - POCTIVÝ MLYNÁŘ\nDluh je splacen a Hynek odjíždí s prázdnou. Říká se, že mlynář Jan nikdy nešidil. Lidé nosí obilí ze tří vsí a mlýn u Černého potoka mele ještě za tvých vnuků.");
            Ending("end_cheat", "KONEC - TICHÝ ZBOHATLÍK\nDluh je splacen a nikdo nic nezjistil. Falešná závaží leží v truhle a Dorota o nich ví. Mlýn jde dobře, ale ty víš, z čeho je postavený.");
            Ending("end_caught", "KONEC - ODHALENÝ ŠIDIČ\nDluh jsi splatil, ale ves ví, jak jsi šidil míru. Lidé nosí obilí do vzdáleného mlýna a tvoje kolo se sotva točí.");
            Ending("end_community", "KONEC - MLÝN VSI\nSousedé složili poslední groše. Hynek odjel a mlýn zůstal tvůj. Od toho dne už není jen tvůj, ale i jejich.");
            Ending("end_lost", "KONEC - BEZ MLÝNA\nHynek vzal klíče. S Dorotou odcházíte hledat nový domov. Možná jiný mlýn, jiný potok, jiný začátek.");
        }

        private static void Ending(string id, string text)
        {
            N(id, "KONEC", text).C("Hrát znovu", "intro1", null, s => s.Reset());
        }

        private static string InspectNext(GameState s)
        {
            if (s.HasFW && (s.Suspicion >= 3 || (s.Suspicion >= 2 && !s.Confessed))) return "inspect_caught";
            if (s.HasFW && s.Suspicion >= 1) return "inspect_warn";
            return "inspect_clean";
        }

        private static string DorotaIdle(GameState s)
        {
            switch (s.Day)
            {
                case 1: return "Matěj čeká u mlýna. Jdi, ať nám neutečou peníze.";
                case 2: return "Kolo včera nějak divně vrzalo. Podívej se na ně u mlýna.";
                case 3: return "Dnes má vesnicí projít Hynek. Buď slušný, Jane.";
                case 4: return "Pekař chystá posvícení a bude potřebovat hodně mouky.";
                case 5: return "Richtář dnes přeměřuje míry a závaží. Hlavu vzhůru.";
                case 6: return "Venku se zvedá vítr. Nelíbí se mi ta obloha.";
                default: return "Dnes je to tady. Ať to dopadne jakkoliv, jsem s tebou.";
            }
        }

        // ------------------------------------------------------------ vstupni uzly postav

        public static string Entry(string npc, GameState s)
        {
            switch (npc)
            {
                case "dorota":
                    return !s.Flag("dorota1") ? "dorota_d1" : "dorota_idle";
                case "matej":
                    if (s.HasReady("matej")) return "matej_deliver";
                    if (s.HasPending("matej")) return "matej_wait";
                    if (s.Day == 1 && !s.Flag("matej1")) return "matej_d1";
                    if (s.Day == 4 && !s.Flag("matej4")) return "matej_d4";
                    return "matej_idle";
                case "kat":
                    if (s.HasReady("kat")) return "kat_deliver";
                    if (s.HasPending("kat")) return "kat_wait";
                    if (s.Day >= 2 && !s.Flag("kat1")) return "kat_d2";
                    return "kat_idle";
                case "baker":
                    if (s.HasReady("baker")) return "baker_deliver";
                    if (s.HasPending("baker")) return "baker_wait";
                    if (s.Day >= 4 && !s.Flag("baker4")) return "baker_d4";
                    return "baker_shop";
                case "priest":
                    return "priest_main";
                case "richtar":
                    if (s.Day == 5 && !s.Flag("inspected")) return "inspect";
                    return "richtar_idle";
                case "hynek":
                    if (s.Day == 3 && !s.Flag("hynek3")) return "hynek_d3";
                    if (s.Day >= 7) return "hynek_final";
                    return "hynek_idle";
                case "ota":
                    if (!s.HasFW && !s.RefusedOta) return "ota_offer";
                    return "ota_idle";
                case "mill": return "mill";
                case "home": return "home";
                default: return "journal";
            }
        }

        public static string MorningNode(int day)
        {
            string id = "day" + day + "_morning";
            return Nodes.ContainsKey(id) ? id : null;
        }
    }
}
