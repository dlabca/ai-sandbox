using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Input.Touch;

namespace Mlynar
{
    /// <summary>Dotyk: joystick vlevo, rozhlizeni tahem vpravo, tlacitko USE a DENIK. V dialogu jen klepnuti.</summary>
    public sealed class Controls
    {
        private sealed class TouchInfo
        {
            public int Role;       // 0 = jine, 1 = joystick, 2 = rozhlizeni
            public Vector2 Last;
        }

        private readonly Dictionary<int, TouchInfo> touches = new Dictionary<int, TouchInfo>();
        private readonly HashSet<int> present = new HashSet<int>();
        private readonly List<int> stale = new List<int>();
        private KeyboardState prevKeys;

        public Vector2 Move;
        public Vector2 Look;
        public bool UsePressed;
        public bool JournalPressed;
        public int KeyChoice = -1;
        public readonly List<Point> Taps = new List<Point>();

        public bool JoyActive;
        public Vector2 JoyOrigin;
        public Vector2 JoyPos;
        public Vector2 JoyHint;
        public float JoyRadius;

        public Rectangle UseRect;
        public Rectangle JournalRect;

        private int lw = -1, lh = -1;
        private int screenW, screenH;

        private void Layout(int w, int h)
        {
            if (w == lw && h == lh) return;
            lw = w; lh = h; screenW = w; screenH = h;
            int s = (int)(0.24f * h);
            UseRect = new Rectangle(w - s - (int)(0.04f * h), h - s - (int)(0.05f * h), s, s);
            JournalRect = new Rectangle((int)(w - 0.30f * h), (int)(0.03f * h), (int)(0.27f * h), (int)(0.11f * h));
            JoyRadius = 0.13f * h;
            JoyHint = new Vector2(0.24f * h, h - 0.30f * h);
        }

        public void Update(int w, int h, bool modal)
        {
            Layout(w, h);

            Look = Vector2.Zero;
            Move = Vector2.Zero;
            UsePressed = false;
            JournalPressed = false;
            KeyChoice = -1;
            Taps.Clear();

            TouchCollection tc = TouchPanel.GetState();
            present.Clear();

            foreach (TouchLocation t in tc)
            {
                present.Add(t.Id);
                Vector2 p = t.Position;

                if (t.State == TouchLocationState.Pressed)
                {
                    TouchInfo ti = new TouchInfo();
                    ti.Last = p;
                    AssignRole(ti, p, modal);
                    touches[t.Id] = ti;
                }
                else if (t.State == TouchLocationState.Moved)
                {
                    TouchInfo ti;
                    if (touches.TryGetValue(t.Id, out ti))
                    {
                        if (ti.Role == 2)
                        {
                            Look += p - ti.Last;
                            ti.Last = p;
                        }
                        else if (ti.Role == 1)
                        {
                            JoyPos = p;
                        }
                    }
                }
                else
                {
                    touches.Remove(t.Id);
                }
            }

            stale.Clear();
            foreach (KeyValuePair<int, TouchInfo> kv in touches)
                if (!present.Contains(kv.Key)) stale.Add(kv.Key);
            for (int i = 0; i < stale.Count; i++) touches.Remove(stale[i]);

            bool joy = false;
            foreach (KeyValuePair<int, TouchInfo> kv in touches)
                if (kv.Value.Role == 1) joy = true;
            JoyActive = joy;

            if (joy && !modal)
            {
                Vector2 d = JoyPos - JoyOrigin;
                float len = d.Length();
                if (len > JoyRadius)
                {
                    d *= JoyRadius / len;
                    len = JoyRadius;
                }
                if (len > JoyRadius * 0.15f)
                    Move = new Vector2(d.X / JoyRadius, -d.Y / JoyRadius);
            }

            // klavesnice (test na PC)
            KeyboardState ks = Keyboard.GetState();
            float kx = 0f, ky = 0f;
            if (ks.IsKeyDown(Keys.A)) kx -= 1f;
            if (ks.IsKeyDown(Keys.D)) kx += 1f;
            if (ks.IsKeyDown(Keys.W)) ky += 1f;
            if (ks.IsKeyDown(Keys.S)) ky -= 1f;
            if (!modal) Move += new Vector2(kx, ky);
            if (ks.IsKeyDown(Keys.Left)) Look.X -= 8f;
            if (ks.IsKeyDown(Keys.Right)) Look.X += 8f;
            if (ks.IsKeyDown(Keys.Up)) Look.Y -= 8f;
            if (ks.IsKeyDown(Keys.Down)) Look.Y += 8f;
            if (KeyPressed(ks, Keys.F)) UsePressed = true;
            if (KeyPressed(ks, Keys.J)) JournalPressed = true;
            if (KeyPressed(ks, Keys.D1)) KeyChoice = 0;
            if (KeyPressed(ks, Keys.D2)) KeyChoice = 1;
            if (KeyPressed(ks, Keys.D3)) KeyChoice = 2;
            if (KeyPressed(ks, Keys.D4)) KeyChoice = 3;
            if (KeyPressed(ks, Keys.D5)) KeyChoice = 4;
            if (KeyPressed(ks, Keys.Space)) KeyChoice = 0;
            prevKeys = ks;

            float ml = Move.Length();
            if (ml > 1f) Move /= ml;
        }

        private bool KeyPressed(KeyboardState ks, Keys k)
        {
            return ks.IsKeyDown(k) && !prevKeys.IsKeyDown(k);
        }

        private void AssignRole(TouchInfo ti, Vector2 p, bool modal)
        {
            Point pt = new Point((int)p.X, (int)p.Y);
            ti.Role = 0;

            if (modal)
            {
                Taps.Add(pt);
                return;
            }
            if (JournalRect.Contains(pt))
            {
                JournalPressed = true;
                return;
            }
            if (UseRect.Contains(pt))
            {
                UsePressed = true;
                return;
            }

            bool joyTaken = false;
            foreach (KeyValuePair<int, TouchInfo> kv in touches)
                if (kv.Value.Role == 1) joyTaken = true;

            if (!joyTaken && p.X < screenW * 0.42f && p.Y > screenH * 0.2f)
            {
                JoyOrigin = p;
                JoyPos = p;
                ti.Role = 1;
                return;
            }
            ti.Role = 2;
        }
    }
}
