using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Mlynar
{
    public sealed class ChunkMesh
    {
        public VertexPositionColor[] Verts = new VertexPositionColor[0];
        public int Count;
        public Vector3 Center;
    }

    public sealed class Look
    {
        public Color Robe, Skin, Hair, HatColor;
        public int Hat;        // 0 nic, 1 slamak, 2 satek, 3 helma, 4 siroky klobouk, 5 cepice
        public float Scale = 1f;
    }

    public sealed class Npc
    {
        public string Id;
        public string Name;
        public Look Look;
        public Func<GameState, Vector3?> Where;
        public bool Present;
        public Vector3 Pos;
        public float Yaw;
        public float Phase;
    }

    public sealed class Spot
    {
        public string Id;
        public string Name;
        public Vector3 Pos;
    }

    public sealed class Circle
    {
        public float X, Z, R;
    }

    public sealed class RectObs
    {
        public float X0, X1, Z0, Z1;
    }

    /// <summary>Vesnice: teren, budovy, stromy, postavy, potok a mlynske kolo.</summary>
    public sealed class Level
    {
        public readonly Terrain Terrain = new Terrain();
        public readonly ChunkMesh[,] Chunks = new ChunkMesh[Terrain.ChunkCount, Terrain.ChunkCount];
        public readonly List<Npc> Npcs = new List<Npc>();
        public readonly List<Spot> Spots = new List<Spot>();
        public readonly List<Circle> Circles = new List<Circle>();
        public readonly List<RectObs> Rects = new List<RectObs>();

        public VertexPositionColor[] Scene = new VertexPositionColor[0];
        public int SceneCount;

        public Vector3 Spawn;
        public Vector3 MillPos;
        public Vector3 WheelCenter;
        public float WheelAngle;

        private readonly MeshBuilder mb = new MeshBuilder();
        private readonly Random rnd = new Random(7);

        private static readonly Color Stone = new Color(138, 134, 126);
        private static readonly Color Timber = new Color(92, 66, 42);
        private static readonly Color Plaster = new Color(226, 212, 176);
        private static readonly Color Thatch = new Color(188, 158, 84);
        private static readonly Color Tile = new Color(150, 70, 52);
        private static readonly Color Shingle = new Color(112, 82, 56);
        private static readonly Color Slate = new Color(82, 88, 104);
        private static readonly Color Door = new Color(76, 52, 34);
        private static readonly Color Glass = new Color(150, 190, 220);

        // ============================================================ stavba sveta

        public Level()
        {
            float cs = Terrain.ChunkCells * Terrain.CellSize;
            for (int cx = 0; cx < Terrain.ChunkCount; cx++)
                for (int cz = 0; cz < Terrain.ChunkCount; cz++)
                {
                    ChunkMesh c = new ChunkMesh();
                    c.Center = new Vector3((cx + 0.5f) * cs, 10f, (cz + 0.5f) * cs);
                    Chunks[cx, cz] = c;
                }
        }

        public void Build(int seed)
        {
            float millX = Terrain.RiverX(100f) - 7f;
            MillPos = new Vector3(millX, 0f, 100f);

            // cesty a pole (musi byt pred stavbou meshe terenu)
            float[][] roads =
            {
                new[] { 92f, 114.2f, 86f, 108f }, new[] { 86f, 108f, 76f, 102f },
                new[] { 103f, 100f, 88f, 100f }, new[] { 88f, 100f, 74f, 100f },
                new[] { 76f, 102f, 62.3f, 95.5f }, new[] { 76f, 102f, 82f, 92f },
                new[] { 74f, 100f, 68f, 112f }, new[] { 74f, 100f, 52f, 86f }, new[] { 52f, 86f, 51f, 83.5f },
                new[] { 68f, 112f, 47f, 114f }, new[] { 103f, 100f, 97f, 108f }, new[] { 97f, 108f, 92f, 114f }
            };
            for (int i = 0; i < roads.Length; i++) Terrain.Roads.Add(roads[i]);
            Terrain.Fields.Add(new[] { 28f, 98f, 52f, 110f });
            Terrain.Fields.Add(new[] { 86f, 120f, 100f, 132f });
            Terrain.Fields.Add(new[] { 98f, 66f, 108f, 80f });

            Terrain.Generate(seed, millX, 100f);
            MillPos.Y = Terrain.HeightAt(millX, 100f);

            for (int cx = 0; cx < Terrain.ChunkCount; cx++)
                for (int cz = 0; cz < Terrain.ChunkCount; cz++)
                {
                    Terrain.BuildChunk(mb, cx, cz);
                    Chunks[cx, cz].Verts = mb.ToArray();
                    Chunks[cx, cz].Count = mb.Count;
                }

            BuildScene();
            DefineNpcs();

            Spawn = new Vector3(94f, Terrain.HeightAt(94f, 114.5f) + 0.05f, 116f);
        }

        private float GroundMax(float cx, float cz, float hx, float hz)
        {
            float m = Terrain.HeightAt(cx, cz);
            m = MathF.Max(m, Terrain.HeightAt(cx - hx, cz - hz));
            m = MathF.Max(m, Terrain.HeightAt(cx + hx, cz - hz));
            m = MathF.Max(m, Terrain.HeightAt(cx - hx, cz + hz));
            m = MathF.Max(m, Terrain.HeightAt(cx + hx, cz + hz));
            return m;
        }

        private float GroundMin(float cx, float cz, float hx, float hz)
        {
            float m = Terrain.HeightAt(cx, cz);
            m = MathF.Min(m, Terrain.HeightAt(cx - hx, cz - hz));
            m = MathF.Min(m, Terrain.HeightAt(cx + hx, cz - hz));
            m = MathF.Min(m, Terrain.HeightAt(cx - hx, cz + hz));
            m = MathF.Min(m, Terrain.HeightAt(cx + hx, cz + hz));
            return m;
        }

        private static Vector3 LP(Vector3 c, float yaw, float lx, float ly, float lz)
        {
            float s = MathF.Sin(yaw), co = MathF.Cos(yaw);
            return new Vector3(c.X + lx * co + lz * s, c.Y + ly, c.Z - lx * s + lz * co);
        }

        private void AddRect(float cx, float cz, float hx, float hz)
        {
            RectObs r = new RectObs();
            r.X0 = cx - hx; r.X1 = cx + hx; r.Z0 = cz - hz; r.Z1 = cz + hz;
            Rects.Add(r);
        }

        private void AddCircle(float x, float z, float r)
        {
            Circle c = new Circle();
            c.X = x; c.Z = z; c.R = r;
            Circles.Add(c);
        }

        /// <summary>Dum s foundaci, trami, sedlovou strechou, dverma (na mistni +Z strane) a okny.</summary>
        private float AddHouse(float cx, float cz, float w, float d, float wallH, int quarter, Color wall, Color roof, float roofH, bool chimney)
        {
            float yaw = quarter * MathHelper.Pi / 2f;
            float hx = (quarter % 2 == 0) ? w / 2f : d / 2f;
            float hz = (quarter % 2 == 0) ? d / 2f : w / 2f;
            float floorY = GroundMax(cx, cz, hx, hz) + 0.15f;
            float low = GroundMin(cx, cz, hx, hz) - 0.7f;
            Vector3 c = new Vector3(cx, floorY, cz);

            mb.BoxYaw(new Vector3(cx, (low + floorY) / 2f, cz), yaw, new Vector3(w / 2f + 0.12f, (floorY - low) / 2f, d / 2f + 0.12f), Stone);
            mb.BoxYaw(LP(c, yaw, 0f, wallH / 2f, 0f), yaw, new Vector3(w / 2f, wallH / 2f, d / 2f), wall);
            for (int i = 0; i < 4; i++)
            {
                float sx = (i & 1) == 0 ? -w / 2f : w / 2f;
                float sz = (i & 2) == 0 ? -d / 2f : d / 2f;
                mb.BoxYaw(LP(c, yaw, sx, wallH / 2f, sz), yaw, new Vector3(0.13f, wallH / 2f, 0.13f), Timber);
            }
            mb.BoxYaw(LP(c, yaw, 0f, wallH - 0.1f, 0f), yaw, new Vector3(w / 2f + 0.04f, 0.1f, d / 2f + 0.04f), Timber);

            float ex = w / 2f + 0.4f, ez = d / 2f + 0.4f;
            Vector3 inside = LP(c, yaw, 0f, wallH * 0.5f, 0f);
            mb.Quad(LP(c, yaw, -ex, wallH, -ez), LP(c, yaw, ex, wallH, -ez), LP(c, yaw, ex, wallH + roofH, 0f), LP(c, yaw, -ex, wallH + roofH, 0f), roof, inside);
            mb.Quad(LP(c, yaw, -ex, wallH, ez), LP(c, yaw, ex, wallH, ez), LP(c, yaw, ex, wallH + roofH, 0f), LP(c, yaw, -ex, wallH + roofH, 0f), roof, inside);
            mb.Tri(LP(c, yaw, -w / 2f, wallH, -d / 2f), LP(c, yaw, -w / 2f, wallH, d / 2f), LP(c, yaw, -w / 2f, wallH + roofH * 0.98f, 0f), wall, inside);
            mb.Tri(LP(c, yaw, w / 2f, wallH, -d / 2f), LP(c, yaw, w / 2f, wallH, d / 2f), LP(c, yaw, w / 2f, wallH + roofH * 0.98f, 0f), wall, inside);

            mb.BoxYaw(LP(c, yaw, 0f, 1.0f, d / 2f + 0.03f), yaw, new Vector3(0.45f, 1.0f, 0.05f), Door);
            mb.BoxYaw(LP(c, yaw, -w / 4f - 0.4f, wallH * 0.62f, d / 2f + 0.03f), yaw, new Vector3(0.28f, 0.28f, 0.05f), Glass);
            mb.BoxYaw(LP(c, yaw, w / 4f + 0.4f, wallH * 0.62f, d / 2f + 0.03f), yaw, new Vector3(0.28f, 0.28f, 0.05f), Glass);
            if (chimney)
                mb.BoxYaw(LP(c, yaw, w / 4f, wallH + roofH * 0.55f, -d / 4f), yaw, new Vector3(0.35f, roofH * 0.55f + 0.3f, 0.35f), Stone);

            AddRect(cx, cz, hx + 0.35f, hz + 0.35f);
            return floorY;
        }

        private void AddTree(float x, float z, float height, int variant, int seed)
        {
            float y = Terrain.HeightAt(x, z);
            Vector3 b = new Vector3(x, y, z);
            float th = height * 0.6f;
            Color bark = Noise.Vary(new Color(98, 72, 46), 0.08f, seed, 1, 5);
            mb.Cylinder(b - new Vector3(0f, 0.2f, 0f), b + new Vector3(0f, th, 0f), 0.34f, 0.2f, 6, bark, bark, false, true);
            Color g1 = Noise.Vary(new Color(52, 118, 62), 0.12f, seed, 2, 6);
            Color g2 = Noise.Vary(new Color(70, 138, 66), 0.12f, seed, 3, 6);
            if (variant == 0)
            {
                mb.Cylinder(b + new Vector3(0f, 0.28f * height, 0f), b + new Vector3(0f, 0.60f * height, 0f), 2.0f, 0f, 7, g1, g1, false, false);
                mb.Cylinder(b + new Vector3(0f, 0.46f * height, 0f), b + new Vector3(0f, 0.80f * height, 0f), 1.6f, 0f, 7, g2, g2, false, false);
                mb.Cylinder(b + new Vector3(0f, 0.64f * height, 0f), b + new Vector3(0f, 1.00f * height, 0f), 1.1f, 0f, 7, g1, g1, false, false);
            }
            else
            {
                mb.Rock(b + new Vector3(0f, th + 1.0f, 0f), 2.1f, 1.7f, 2.1f, seed, g2, 0.18f);
                mb.Rock(b + new Vector3(0.9f, th + 0.2f, 0.4f), 1.2f, 1.0f, 1.2f, seed + 7, g1, 0.18f);
            }
            AddCircle(x, z, 0.45f);
        }

        private void BuildScene()
        {
            mb.Clear();

            // ---- potok
            Color water = new Color(70, 126, 188);
            for (float z = 0f; z < Terrain.Size; z += 4f)
            {
                float x0 = Terrain.RiverX(z) - Terrain.RiverHalf - 1.2f, x1 = Terrain.RiverX(z) + Terrain.RiverHalf + 1.2f;
                float x0b = Terrain.RiverX(z + 4f) - Terrain.RiverHalf - 1.2f, x1b = Terrain.RiverX(z + 4f) + Terrain.RiverHalf + 1.2f;
                Vector3 below = new Vector3(0f, -5f, 0f);
                mb.Quad(new Vector3(x0, Terrain.WaterY, z), new Vector3(x1, Terrain.WaterY, z),
                        new Vector3(x1b, Terrain.WaterY, z + 4f), new Vector3(x0b, Terrain.WaterY, z + 4f), water, new Vector3(x0, Terrain.WaterY - 5f, z));
            }

            // ---- mlyn
            float mx = MillPos.X, mz = MillPos.Z;
            float mfloor = AddHouse(mx, mz, 6f, 6f, 5.2f, 3, Plaster, Shingle, 3.0f, true);
            MillPos.Y = mfloor;
            WheelCenter = new Vector3(mx + 4f, Terrain.WaterY + 2.1f, mz);
            // mlynsky stul (zasoba) pred dvermi
            mb.Cylinder(new Vector3(mx - 6.2f, Terrain.HeightAt(mx - 6.2f, mz) + 0.1f, mz), new Vector3(mx - 6.2f, Terrain.HeightAt(mx - 6.2f, mz) + 0.45f, mz), 0.95f, 0.95f, 10, new Color(150, 148, 144), new Color(170, 168, 164), true, true);
            for (int i = 0; i < 4; i++)
            {
                float sz = mz + 2.0f + (i % 2) * 0.7f, sx = mx - 4.8f - (i / 2) * 0.8f;
                mb.BoxYaw(new Vector3(sx, Terrain.HeightAt(sx, sz) + 0.35f, sz), 0.2f * i, new Vector3(0.38f, 0.35f, 0.28f), new Color(214, 192, 142));
            }
            AddCircle(mx - 6.2f, mz, 0.95f);

            // ---- dum mlynare
            AddHouse(92f, 110f, 7f, 5f, 3.0f, 0, Plaster, Thatch, 2.4f, true);
            // ---- vesnice
            AddHouse(84f, 88f, 8f, 6f, 3.3f, 0, Plaster, Tile, 2.6f, true);        // richtar
            AddHouse(60f, 90f, 8f, 6f, 3.2f, 0, Plaster, Tile, 2.5f, true);        // pekar
            AddHouse(66f, 116f, 5f, 4f, 2.6f, 2, Plaster, Thatch, 2.0f, true);     // Katerina
            AddHouse(40f, 124f, 10f, 7f, 3.6f, 0, Timber, Thatch, 3.0f, false);    // stodola

            // ---- kostel
            AddHouse(48f, 76f, 7f, 12f, 5.0f, 0, Plaster, Slate, 3.0f, false);
            float tfloor = GroundMax(48f, 66f, 2f, 2f) + 0.15f;
            mb.Box(new Vector3(48f, (tfloor - 1f + tfloor + 10f) / 2f, 66f), new Vector3(2.2f, (11f) / 2f, 0f), new Vector3(0f, 5.5f, 0f), new Vector3(0f, 0f, 2.2f), Stone);
            mb.Cylinder(new Vector3(48f, tfloor + 10f, 66f), new Vector3(48f, tfloor + 14f, 66f), 3.1f, 0f, 4, Slate, Slate, false, false, MathHelper.Pi / 4f);
            mb.Box(new Vector3(48f, tfloor + 14.8f, 66f), new Vector3(0.1f, 0f, 0f), new Vector3(0f, 0.8f, 0f), new Vector3(0f, 0f, 0.1f), new Color(210, 190, 90));
            mb.Box(new Vector3(48f, tfloor + 15.1f, 66f), new Vector3(0.4f, 0f, 0f), new Vector3(0f, 0.1f, 0f), new Vector3(0f, 0f, 0.1f), new Color(210, 190, 90));
            AddRect(48f, 66f, 2.6f, 2.6f);

            // ---- panske sidlo na kopci
            float kf = Terrain.HeightAt(26f, 32f);
            mb.Box(new Vector3(26f, kf + 5f, 32f), new Vector3(4.5f, 0f, 0f), new Vector3(0f, 8f, 0f), new Vector3(0f, 0f, 4.5f), new Color(150, 146, 140));
            for (int i = 0; i < 8; i++)
            {
                float t = -4f + i * (8f / 7f);
                mb.Box(new Vector3(26f + t, kf + 13.5f, 27.5f), new Vector3(0.45f, 0f, 0f), new Vector3(0f, 0.5f, 0f), new Vector3(0f, 0f, 0.45f), new Color(150, 146, 140));
                mb.Box(new Vector3(26f + t, kf + 13.5f, 36.5f), new Vector3(0.45f, 0f, 0f), new Vector3(0f, 0.5f, 0f), new Vector3(0f, 0f, 0.45f), new Color(150, 146, 140));
            }
            mb.Cylinder(new Vector3(26f, kf + 13f, 32f), new Vector3(26f, kf + 20f, 32f), 0.1f, 0.1f, 4, Timber, Timber, false, true);
            mb.Box(new Vector3(26.9f, kf + 19f, 32f), new Vector3(0.9f, 0f, 0f), new Vector3(0f, 0.6f, 0f), new Vector3(0f, 0f, 0.05f), new Color(176, 40, 40));

            // ---- studna na navsi
            float wy = Terrain.HeightAt(72f, 100f);
            mb.Cylinder(new Vector3(72f, wy - 0.3f, 100f), new Vector3(72f, wy + 0.95f, 100f), 1.0f, 0.9f, 9, Stone, new Color(30, 40, 60), false, true);
            mb.Cylinder(new Vector3(70.9f, wy, 100f), new Vector3(70.9f, wy + 2.4f, 100f), 0.1f, 0.1f, 4, Timber, Timber, false, true);
            mb.Cylinder(new Vector3(73.1f, wy, 100f), new Vector3(73.1f, wy + 2.4f, 100f), 0.1f, 0.1f, 4, Timber, Timber, false, true);
            mb.Quad(new Vector3(70.6f, wy + 2.3f, 99.4f), new Vector3(73.4f, wy + 2.3f, 99.4f), new Vector3(73.4f, wy + 2.9f, 100f), new Vector3(70.6f, wy + 2.9f, 100f), Shingle, new Vector3(72f, wy + 1f, 100f));
            mb.Quad(new Vector3(70.6f, wy + 2.3f, 100.6f), new Vector3(73.4f, wy + 2.3f, 100.6f), new Vector3(73.4f, wy + 2.9f, 100f), new Vector3(70.6f, wy + 2.9f, 100f), Shingle, new Vector3(72f, wy + 1f, 100f));
            AddCircle(72f, 100f, 1.05f);

            // ---- vuz obchodnika
            float cy = Terrain.HeightAt(77.5f, 108.5f);
            mb.BoxYaw(new Vector3(77.5f, cy + 0.75f, 108.5f), 0.4f, new Vector3(1.0f, 0.25f, 0.6f), Timber);
            mb.BoxYaw(new Vector3(77.5f, cy + 1.45f, 108.5f), 0.4f, new Vector3(0.9f, 0.45f, 0.55f), new Color(200, 70, 60));
            mb.Cylinder(new Vector3(77.2f, cy + 0.45f, 107.8f), new Vector3(77.2f, cy + 0.45f, 109.2f), 0.45f, 0.45f, 8, Timber, Timber, true, true);
            AddCircle(77.5f, 108.5f, 1.3f);

            // ---- seno u stodoly
            for (int i = 0; i < 2; i++)
            {
                float hxp = 32f + i * 1.5f, hzp = 116f + i * 3.5f;
                float hy = Terrain.HeightAt(hxp, hzp);
                mb.Cylinder(new Vector3(hxp, hy, hzp), new Vector3(hxp, hy + 2.2f, hzp), 1.5f, 0f, 7, new Color(212, 186, 96), new Color(212, 186, 96), false, false);
                AddCircle(hxp, hzp, 1.4f);
            }

            // ---- pole (klasy)
            for (int f = 0; f < Terrain.Fields.Count; f++)
            {
                float[] fl = Terrain.Fields[f];
                for (float x = fl[0] + 0.8f; x < fl[2]; x += 1.1f)
                {
                    float zc = (fl[1] + fl[3]) / 2f;
                    float hy = Terrain.HeightAt(x, zc);
                    Color wc = Noise.Vary(new Color(206, 174, 76), 0.1f, (int)(x * 10), f, 3);
                    mb.Box(new Vector3(x, hy + 0.35f, zc), new Vector3(0.14f, 0f, 0f), new Vector3(0f, 0.35f, 0f), new Vector3(0f, 0f, (fl[3] - fl[1]) / 2f - 0.5f), wc);
                }
            }

            // ---- stromy
            int planted = 0;
            for (int attempt = 0; attempt < 2500 && planted < 150; attempt++)
            {
                float x = 6f + (float)rnd.NextDouble() * (Terrain.Size - 12f);
                float z = 6f + (float)rnd.NextDouble() * (Terrain.Size - 12f);
                float y = Terrain.HeightAt(x, z);
                if (y < Terrain.WaterY + 0.8f) continue;
                if (MathF.Abs(x - Terrain.RiverX(z)) < 8f) continue;
                if (Terrain.RoadDist(x, z) < 3.5f || Terrain.InField(x, z)) continue;
                if (TooClose(x, z, 6.5f)) continue;
                AddTree(x, z, 7f + (float)rnd.NextDouble() * 4.5f, rnd.Next(2), rnd.Next(100000));
                planted++;
            }
            // lipa na navsi
            AddTree(79f, 96f, 10.5f, 1, 4242);

            Scene = mb.ToArray();
            SceneCount = mb.Count;
        }

        private bool TooClose(float x, float z, float d)
        {
            for (int i = 0; i < Rects.Count; i++)
            {
                RectObs r = Rects[i];
                if (x > r.X0 - d && x < r.X1 + d && z > r.Z0 - d && z < r.Z1 + d) return true;
            }
            for (int i = 0; i < Circles.Count; i++)
            {
                float dx = x - Circles[i].X, dz = z - Circles[i].Z;
                if (dx * dx + dz * dz < (d * 0.8f + Circles[i].R) * (d * 0.8f + Circles[i].R)) return true;
            }
            return false;
        }

        // ============================================================ postavy

        private static Look MkLook(Color robe, Color skin, Color hair, int hat, Color hatColor, float scale = 1f)
        {
            Look l = new Look();
            l.Robe = robe; l.Skin = skin; l.Hair = hair; l.Hat = hat; l.HatColor = hatColor; l.Scale = scale;
            return l;
        }

        private void AddNpc(string id, string name, Look look, Func<GameState, Vector3?> where)
        {
            Npc n = new Npc();
            n.Id = id;
            n.Name = name;
            n.Look = look;
            n.Where = where;
            n.Phase = Noise.Hash01(id.Length, id[0], 5) * 6f;
            Npcs.Add(n);
        }

        private static Vector3? P(float x, float z)
        {
            return new Vector3(x, 0f, z);
        }

        private void DefineNpcs()
        {
            Color skin = new Color(226, 184, 150);
            AddNpc("dorota", "DOROTA", MkLook(new Color(70, 100, 160), skin, new Color(90, 60, 40), 2, new Color(240, 236, 226)), s => P(95.5f, 114.2f));
            AddNpc("matej", "MATĚJ", MkLook(new Color(120, 88, 56), skin, new Color(110, 80, 40), 1, new Color(210, 180, 90)),
                s => (s.Day == 1 || s.Day == 2 || s.Day == 4) ? P(101.4f, 103.4f) : P(46.5f, 114.5f));
            AddNpc("kat", "KATEŘINA", MkLook(new Color(110, 110, 116), skin, new Color(60, 50, 44), 2, new Color(36, 32, 36)), s => P(68.4f, 112.4f));
            AddNpc("baker", "PEKAŘ BOŘIVOJ", MkLook(new Color(236, 232, 222), skin, new Color(130, 90, 60), 5, new Color(244, 240, 232), 1.05f), s => P(62.3f, 94.8f));
            AddNpc("priest", "OTEC TOMÁŠ", MkLook(new Color(36, 34, 40), skin, new Color(120, 110, 100), 0, new Color(0, 0, 0)), s => P(51.2f, 84.2f));
            AddNpc("richtar", "RICHTÁŘ VAVŘINEC", MkLook(new Color(120, 40, 48), skin, new Color(150, 150, 150), 5, new Color(90, 70, 50), 1.05f),
                s => s.Day == 5 ? P(102.6f, 96.6f) : P(80.5f, 96.2f));
            AddNpc("hynek", "SPRÁVCE HYNEK", MkLook(new Color(52, 100, 70), skin, new Color(60, 50, 40), 3, new Color(180, 184, 192), 1.1f),
                s => s.Day == 3 ? P(68.8f, 101.8f) : (s.Day >= 7 ? P(101.4f, 99.2f) : null));
            AddNpc("ota", "OBCHODNÍK OTA", MkLook(new Color(190, 110, 50), skin, new Color(40, 30, 30), 4, new Color(150, 60, 140)),
                s => (s.Day >= 2 && s.Day <= 4) ? P(80.2f, 106.4f) : null);

            Spot m = new Spot();
            m.Id = "mill"; m.Name = "MLÝNSKÝ KÁMEN";
            m.Pos = new Vector3(MillPos.X - 6.2f, 0f, MillPos.Z);
            Spots.Add(m);
            Spot h = new Spot();
            h.Id = "home"; h.Name = "TVŮJ DŮM";
            h.Pos = new Vector3(92f, 0f, 114.4f);
            Spots.Add(h);
        }

        public void Update(float dt, GameState s, Vector3 playerPos)
        {
            WheelAngle += dt * (s.Wheel > 0 ? 0.7f : 0.15f);
            for (int i = 0; i < Npcs.Count; i++)
            {
                Npc n = Npcs[i];
                Vector3? w = n.Where(s);
                n.Present = w.HasValue;
                if (!w.HasValue) continue;
                Vector3 p = w.Value;
                p.Y = Terrain.HeightAt(p.X, p.Z);
                n.Pos = p;
                n.Phase += dt;

                float dx = playerPos.X - p.X, dz = playerPos.Z - p.Z;
                if (dx * dx + dz * dz < 12f * 12f)
                {
                    float target = MathF.Atan2(dx, dz);
                    float diff = target - n.Yaw;
                    while (diff > MathHelper.Pi) diff -= MathHelper.TwoPi;
                    while (diff < -MathHelper.Pi) diff += MathHelper.TwoPi;
                    n.Yaw += diff * MathHelper.Clamp(dt * 4f, 0f, 1f);
                }
            }
        }

        /// <summary>Nejblizsi postava / misto k interakci pred hracem.</summary>
        public bool FindUse(Vector3 pos, Vector3 fwd, GameState s, out string id, out string name, out Vector3 at)
        {
            id = null; name = null; at = pos;
            float best = 3.4f;
            for (int i = 0; i < Npcs.Count; i++)
            {
                Npc n = Npcs[i];
                if (!n.Present) continue;
                if (Consider(pos, fwd, n.Pos, ref best))
                {
                    id = n.Id; name = n.Name; at = n.Pos;
                }
            }
            for (int i = 0; i < Spots.Count; i++)
            {
                Spot sp = Spots[i];
                if (Consider(pos, fwd, sp.Pos, ref best))
                {
                    id = sp.Id; name = sp.Name; at = sp.Pos;
                }
            }
            return id != null;
        }

        private static bool Consider(Vector3 pos, Vector3 fwd, Vector3 target, ref float best)
        {
            float dx = target.X - pos.X, dz = target.Z - pos.Z;
            float d = MathF.Sqrt(dx * dx + dz * dz);
            if (d > best) return false;
            if (d > 0.7f)
            {
                float dot = (dx * fwd.X + dz * fwd.Z) / d;
                if (dot < 0.3f) return false;
            }
            best = d;
            return true;
        }

        // ============================================================ fyzika

        public float GroundY(float x, float z)
        {
            return Terrain.HeightAt(x, z);
        }

        public void ResolveHorizontal(ref float x, ref float z, float r)
        {
            for (int i = 0; i < Circles.Count; i++) PushCircle(ref x, ref z, r, Circles[i].X, Circles[i].Z, Circles[i].R);
            for (int i = 0; i < Npcs.Count; i++)
                if (Npcs[i].Present) PushCircle(ref x, ref z, r, Npcs[i].Pos.X, Npcs[i].Pos.Z, 0.45f);
            for (int i = 0; i < Rects.Count; i++) PushRect(ref x, ref z, r, Rects[i]);
            x = MathHelper.Clamp(x, 4f, Terrain.Size - 4f);
            z = MathHelper.Clamp(z, 4f, Terrain.Size - 4f);
        }

        private static void PushCircle(ref float x, ref float z, float r, float cx, float cz, float cr)
        {
            float dx = x - cx, dz = z - cz;
            float min = r + cr;
            float d2 = dx * dx + dz * dz;
            if (d2 >= min * min) return;
            if (d2 < 1e-8f)
            {
                x = cx + min;
                return;
            }
            float d = MathF.Sqrt(d2);
            float k = min / d;
            x = cx + dx * k;
            z = cz + dz * k;
        }

        private static void PushRect(ref float x, ref float z, float r, RectObs o)
        {
            float cx = MathHelper.Clamp(x, o.X0, o.X1);
            float cz = MathHelper.Clamp(z, o.Z0, o.Z1);
            float dx = x - cx, dz = z - cz;
            float d2 = dx * dx + dz * dz;
            if (d2 >= r * r) return;
            if (d2 > 1e-8f)
            {
                float d = MathF.Sqrt(d2);
                float k = (r - d) / d;
                x += dx * k;
                z += dz * k;
            }
            else
            {
                float l = x - o.X0, rr = o.X1 - x, n = z - o.Z0, f = o.Z1 - z;
                float m = MathF.Min(MathF.Min(l, rr), MathF.Min(n, f));
                if (m == l) x = o.X0 - r;
                else if (m == rr) x = o.X1 + r;
                else if (m == n) z = o.Z0 - r;
                else z = o.Z1 + r;
            }
        }

        // ============================================================ dynamicke meshe (kolo, postavy, znacky)

        public void BuildDynamic(MeshBuilder b, GameState s)
        {
            AddWheel(b);
            for (int i = 0; i < Npcs.Count; i++)
            {
                Npc n = Npcs[i];
                if (!n.Present) continue;
                AddPerson(b, n);
                if (!Story.Entry(n.Id, s).EndsWith("idle") && !Story.Entry(n.Id, s).EndsWith("shop") && !Story.Entry(n.Id, s).EndsWith("main"))
                {
                    float bob = MathF.Sin(n.Phase * 3f) * 0.08f;
                    b.Rock(n.Pos + new Vector3(0f, 2.35f * n.Look.Scale + bob, 0f), 0.14f, 0.2f, 0.14f, 3, new Color(255, 214, 70), 0f);
                }
            }
        }

        private void AddWheel(MeshBuilder b)
        {
            const float R = 2.3f;
            Vector3 c = WheelCenter;
            Color wood = new Color(112, 82, 52);
            Color dark = new Color(84, 60, 38);
            b.Cylinder(c + new Vector3(0f, 0f, -1.6f), c + new Vector3(0f, 0f, 1.6f), 0.16f, 0.16f, 6, dark, dark, true, true);
            int n = 12;
            for (int k = 0; k < n; k++)
            {
                float a = WheelAngle + k * MathHelper.TwoPi / n;
                float a2 = WheelAngle + (k + 1) * MathHelper.TwoPi / n;
                Vector3 r0 = new Vector3(MathF.Cos(a), MathF.Sin(a), 0f);
                Vector3 t0 = new Vector3(-MathF.Sin(a), MathF.Cos(a), 0f);
                Vector3 r1 = new Vector3(MathF.Cos(a2), MathF.Sin(a2), 0f);
                for (int side = -1; side <= 1; side += 2)
                {
                    Vector3 off = new Vector3(0f, 0f, side * 0.95f);
                    b.Cylinder(c + off, c + off + r0 * R, 0.07f, 0.07f, 4, wood, wood, false, false);
                    b.Cylinder(c + off + r0 * R, c + off + r1 * R, 0.08f, 0.08f, 4, wood, wood, false, false);
                }
                b.Box(c + r0 * (R + 0.05f), t0 * 0.5f, r0 * 0.07f, new Vector3(0f, 0f, 0.95f), wood);
            }
        }

        private static void AddPerson(MeshBuilder b, Npc n)
        {
            Look l = n.Look;
            float sc = l.Scale;
            float yaw = n.Yaw;
            Vector3 pos = n.Pos;
            Vector3 up = Vector3.Up;
            Vector3 fwd = new Vector3(MathF.Sin(yaw), 0f, MathF.Cos(yaw));
            Vector3 right = new Vector3(MathF.Cos(yaw), 0f, -MathF.Sin(yaw));
            float breathe = MathF.Sin(n.Phase * 2.2f) * 0.012f;

            b.Cylinder(pos, pos + up * (1.15f * sc), 0.38f * sc, 0.26f * sc, 7, l.Robe, l.Robe, false, true);
            Vector3 headC = pos + up * (1.4f * sc + breathe);
            b.Rock(headC, 0.17f * sc, 0.19f * sc, 0.17f * sc, n.Id.Length, l.Skin, 0.04f);
            b.Box(headC + fwd * (0.17f * sc), right * 0.03f, up * 0.04f, fwd * 0.05f, Noise.Scale(l.Skin, 0.85f));

            float sway = MathF.Sin(n.Phase * 1.7f) * 0.06f;
            for (int side = -1; side <= 1; side += 2)
            {
                Vector3 sh = pos + up * (1.05f * sc) + right * (0.3f * sc * side);
                Vector3 hand = pos + up * (0.68f * sc) + right * (0.33f * sc * side) + fwd * (0.1f + sway * side);
                b.Cylinder(sh, hand, 0.075f * sc, 0.06f * sc, 5, l.Robe, l.Robe, false, true);
                b.Rock(hand, 0.06f, 0.06f, 0.06f, side + 5, l.Skin, 0.05f);
            }

            switch (l.Hat)
            {
                case 0:
                    b.Rock(headC + up * (0.06f * sc), 0.18f * sc, 0.17f * sc, 0.18f * sc, 11, l.Hair, 0.05f);
                    break;
                case 1:
                    b.Cylinder(headC + up * (0.14f * sc), headC + up * (0.16f * sc), 0.4f * sc, 0.4f * sc, 8, l.HatColor, l.HatColor, true, true);
                    b.Cylinder(headC + up * (0.14f * sc), headC + up * (0.34f * sc), 0.2f * sc, 0.14f * sc, 7, l.HatColor, l.HatColor, false, true);
                    break;
                case 2:
                    b.Rock(headC + up * (0.04f * sc), 0.2f * sc, 0.2f * sc, 0.2f * sc, 12, l.HatColor, 0.04f);
                    break;
                case 3:
                    b.Cylinder(headC + up * (0.05f * sc), headC + up * (0.3f * sc), 0.2f * sc, 0.06f * sc, 7, l.HatColor, l.HatColor, true, true);
                    break;
                case 4:
                    b.Cylinder(headC + up * (0.13f * sc), headC + up * (0.15f * sc), 0.46f * sc, 0.46f * sc, 8, l.HatColor, l.HatColor, true, true);
                    b.Cylinder(headC + up * (0.13f * sc), headC + up * (0.38f * sc), 0.2f * sc, 0.16f * sc, 7, l.HatColor, l.HatColor, false, true);
                    break;
                default:
                    b.Cylinder(headC + up * (0.08f * sc), headC + up * (0.3f * sc), 0.2f * sc, 0.17f * sc, 7, l.HatColor, l.HatColor, false, true);
                    break;
            }
        }
    }
}
