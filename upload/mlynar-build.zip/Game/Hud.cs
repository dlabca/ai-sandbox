using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Mlynar
{
    public sealed class Hud
    {
        private readonly SpriteBatch sb;
        private readonly Texture2D px;

        public Hud(SpriteBatch spriteBatch, Texture2D pixel)
        {
            sb = spriteBatch;
            px = pixel;
        }

        public static int DialogueScale(int h)
        {
            return Math.Max(2, h / 270);
        }

        /// <summary>Rozlozeni dialogoveho panelu - pouziva HUD i hra pro klepnuti na volby.</summary>
        public static void DialogueLayout(int w, int h, int choiceCount, out Rectangle panel, out Rectangle textRect, Rectangle[] choices)
        {
            int sc = DialogueScale(h);
            int margin = (int)(0.025f * h);
            int choiceH = (int)(0.10f * h);
            int gap = (int)(0.012f * h);
            int nameH = PixelFont.LineHeight(sc) + gap;
            int textH = (int)(0.27f * h);
            int total = margin + nameH + textH + choiceCount * (choiceH + gap) + margin;
            int pw = w - 2 * (int)(0.03f * h);
            int px0 = (w - pw) / 2;
            int py0 = h - total - (int)(0.02f * h);
            panel = new Rectangle(px0, py0, pw, total);
            textRect = new Rectangle(px0 + margin, py0 + margin + nameH, pw - 2 * margin, textH);
            int cy = textRect.Bottom;
            for (int i = 0; i < choiceCount && i < choices.Length; i++)
            {
                choices[i] = new Rectangle(px0 + margin, cy + i * (choiceH + gap), pw - 2 * margin, choiceH);
            }
        }

        private void Fill(Rectangle r, Color c)
        {
            sb.Draw(px, r, c);
        }

        private void Border(Rectangle r, int th, Color c)
        {
            Fill(new Rectangle(r.X, r.Y, r.Width, th), c);
            Fill(new Rectangle(r.X, r.Bottom - th, r.Width, th), c);
            Fill(new Rectangle(r.X, r.Y, th, r.Height), c);
            Fill(new Rectangle(r.Right - th, r.Y, th, r.Height), c);
        }

        private void Text(string s, int x, int y, int sc, Color c)
        {
            int o = Math.Max(1, sc / 2);
            PixelFont.Draw(sb, px, s, x + o, y + o, sc, Color.Black * 0.7f);
            PixelFont.Draw(sb, px, s, x, y, sc, c);
        }

        private void TextCentered(string s, Rectangle r, int sc, Color c)
        {
            int x = r.X + (r.Width - PixelFont.Width(s, sc)) / 2;
            int y = r.Y + (r.Height - PixelFont.Height(sc)) / 2;
            Text(s, x, y, sc, c);
        }

        private void Button(Rectangle r, string label, int sc, int bt)
        {
            Fill(r, Color.Black * 0.45f);
            Border(r, bt, Color.White * 0.65f);
            TextCentered(label, r, sc, Color.White);
        }

        public void DrawWorld(int w, int h, Controls c, GameState s, string prompt, string objective, string message, float messageAlpha, bool canTalk)
        {
            int sc = Math.Max(2, h / 300);
            int bt = Math.Max(2, h / 300);
            int lineH = PixelFont.LineHeight(sc);
            Color gold = new Color(255, 230, 90);

            int cx = w / 2, cy = h / 2;
            Fill(new Rectangle(cx - bt, cy - bt, bt * 2, bt * 2), Color.White * 0.8f);

            int tx = (int)(0.02f * h);
            int ty = (int)(0.035f * h);
            Text("DEN " + s.Day + " - " + s.SegmentName, tx, ty, sc, Color.White); ty += lineH;
            Text("GROŠE: " + s.Money + "   DLUH: " + s.Debt, tx, ty, sc, Color.White); ty += lineH;
            Text("MOUKA: " + s.Flour + "   ZAKÁZKY: " + s.PendingSacks + "/" + s.ReadySacks, tx, ty, sc, Color.White); ty += lineH;
            Text(objective, tx, ty, sc, gold);

            if (!string.IsNullOrEmpty(prompt))
                TextCentered(prompt, new Rectangle(0, (int)(0.62f * h), w, lineH), sc, gold);

            Button(c.JournalRect, "DENÍK", sc, bt);
            Fill(c.UseRect, canTalk ? new Color(255, 230, 90) * 0.55f : Color.Black * 0.45f);
            Border(c.UseRect, bt, Color.White * 0.65f);
            TextCentered(canTalk ? "MLUVIT" : "USE", c.UseRect, sc, Color.White);

            int jr = (int)c.JoyRadius;
            Vector2 origin = c.JoyActive ? c.JoyOrigin : c.JoyHint;
            Rectangle baseRect = new Rectangle((int)origin.X - jr, (int)origin.Y - jr, jr * 2, jr * 2);
            Fill(baseRect, Color.White * (c.JoyActive ? 0.15f : 0.08f));
            Border(baseRect, bt, Color.White * 0.35f);
            Vector2 knob = origin;
            if (c.JoyActive)
            {
                Vector2 d = c.JoyPos - c.JoyOrigin;
                float len = d.Length();
                if (len > jr) d *= jr / len;
                knob = origin + d;
            }
            int kr = jr / 3;
            Fill(new Rectangle((int)knob.X - kr, (int)knob.Y - kr, kr * 2, kr * 2), Color.White * 0.5f);

            if (!string.IsNullOrEmpty(message) && messageAlpha > 0f)
            {
                Color mc = new Color(255, 240, 160) * Math.Min(1f, messageAlpha * 2f);
                TextCentered(message, new Rectangle(0, (int)(0.70f * h), w, lineH), sc, mc);
            }
        }

        public void DrawDialogue(int w, int h, string speaker, string text, List<string> labels, Rectangle[] choiceRects, Rectangle panel, Rectangle textRect)
        {
            int sc = DialogueScale(h);
            int bt = Math.Max(2, h / 300);
            Color gold = new Color(255, 230, 90);

            Fill(panel, new Color(18, 14, 10) * 0.88f);
            Border(panel, bt, new Color(210, 180, 120) * 0.9f);

            int margin = (int)(0.025f * h);
            Text(speaker, panel.X + margin, panel.Y + margin, sc, gold);

            List<string> lines = PixelFont.Wrap(text, textRect.Width, sc);
            int ly = textRect.Y;
            int lh = PixelFont.LineHeight(sc);
            for (int i = 0; i < lines.Count; i++)
            {
                if (ly + PixelFont.Height(sc) > textRect.Bottom + lh) break;
                Text(lines[i], textRect.X, ly + 2 * sc, sc, Color.White);
                ly += lh;
            }

            for (int i = 0; i < labels.Count && i < choiceRects.Length; i++)
            {
                Rectangle r = choiceRects[i];
                Fill(r, new Color(70, 52, 30) * 0.9f);
                Border(r, bt, new Color(210, 180, 120) * 0.8f);
                Text((i + 1) + ". " + labels[i], r.X + margin / 2, r.Y + (r.Height - PixelFont.Height(sc)) / 2, sc, Color.White);
            }
        }
    }
}
