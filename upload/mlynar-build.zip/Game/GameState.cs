using System;
using System.Collections.Generic;

namespace Mlynar
{
    public sealed class Order
    {
        public string Who;
        public int Sacks;
        public int Fee;        // grose za pytel
        public bool Ready;
        public bool Cheated;
    }

    /// <summary>Stav pribehu: den, cas, penize, dluh, povest a zakazky.</summary>
    public sealed class GameState
    {
        public const int Segments = 4;
        public static readonly string[] SegmentNames = { "RÁNO", "POLEDNE", "ODPOLEDNE", "VEČER" };
        public static readonly int[] GeneralSacks = { 0, 3, 4, 3, 4, 3, 2, 2 };

        public int Day = 1;
        public int Segment;
        public int Money = 4;
        public int Debt = 48;
        public int Flour;
        public int Wheel = 100;
        public int RepVillage;
        public int RepLord;
        public int Cheats;
        public int Suspicion;
        public bool HasFW;
        public bool Caught;
        public bool Confessed;
        public bool RefusedOta;
        public bool GeneralToday;
        public bool PendingSleep;
        public int LastPay;
        public string Message = "";
        public readonly HashSet<string> Flags = new HashSet<string>();
        public readonly List<Order> Orders = new List<Order>();

        public void Reset()
        {
            Day = 1; Segment = 0; Money = 4; Debt = 48; Flour = 0; Wheel = 100;
            RepVillage = 0; RepLord = 0; Cheats = 0; Suspicion = 0;
            HasFW = false; Caught = false; Confessed = false; RefusedOta = false;
            GeneralToday = false; PendingSleep = false; LastPay = 0; Message = "";
            Flags.Clear();
            Orders.Clear();
        }

        public string SegmentName
        {
            get { return SegmentNames[Math.Min(Segment, Segments - 1)]; }
        }

        public bool Flag(string f)
        {
            return Flags.Contains(f);
        }

        public void SetFlag(string f)
        {
            Flags.Add(f);
        }

        public void Advance(int n)
        {
            Segment = Math.Min(Segments - 1, Segment + n);
        }

        public void NextDay()
        {
            Day++;
            Segment = 0;
            GeneralToday = false;
        }

        public void AddOrder(string who, int sacks, int fee, bool cheated)
        {
            Order o = new Order();
            o.Who = who;
            o.Sacks = sacks;
            o.Fee = fee;
            o.Cheated = cheated;
            Orders.Add(o);
            if (cheated)
            {
                Cheats++;
                Suspicion++;
            }
        }

        public int Capacity
        {
            get
            {
                if (Wheel >= 70) return 6;
                if (Wheel >= 40) return 4;
                if (Wheel > 0) return 2;
                return 0;
            }
        }

        public int PendingSacks
        {
            get
            {
                int n = 0;
                for (int i = 0; i < Orders.Count; i++) if (!Orders[i].Ready) n += Orders[i].Sacks;
                return n;
            }
        }

        public int ReadySacks
        {
            get
            {
                int n = 0;
                for (int i = 0; i < Orders.Count; i++) if (Orders[i].Ready) n += Orders[i].Sacks;
                return n;
            }
        }

        public bool HasPending(string who)
        {
            for (int i = 0; i < Orders.Count; i++) if (Orders[i].Who == who && !Orders[i].Ready) return true;
            return false;
        }

        public bool HasReady(string who)
        {
            for (int i = 0; i < Orders.Count; i++) if (Orders[i].Who == who && Orders[i].Ready) return true;
            return false;
        }

        /// <summary>Mele zakazky v poradi; kolik se stihne, urcuje stav kola. Zabere jednu cast dne.</summary>
        public string Grind()
        {
            if (Segment >= Segments - 1) return "JE VEČER, MLÝN STOJÍ";
            int cap = Capacity;
            if (cap == 0) return "KOLO JE ROZBITÉ";
            if (PendingSacks == 0) return "NENÍ CO MLÍT";

            int done = 0;
            for (int i = 0; i < Orders.Count; i++)
            {
                Order o = Orders[i];
                if (o.Ready) continue;
                if (done + o.Sacks <= cap)
                {
                    o.Ready = true;
                    done += o.Sacks;
                }
            }
            if (done == 0) return "ZAKÁZKA JE PŘÍLIŠ VELKÁ, KOLO ZVLÁDNE JEN " + cap + " PYTLŮ";

            Wheel = Math.Max(0, Wheel - 10);
            Advance(1);
            return "NAMELETO " + done + " PYTLŮ";
        }

        /// <summary>Vydat hotovou mouku zakaznikovi a vybrat zaplaceni.</summary>
        public int Deliver(string who)
        {
            int pay = 0;
            for (int i = Orders.Count - 1; i >= 0; i--)
            {
                Order o = Orders[i];
                if (o.Who != who || !o.Ready) continue;
                pay += o.Sacks * o.Fee;
                if (o.Cheated) Flour += (o.Sacks + 1) / 2;
                Orders.RemoveAt(i);
            }
            Money += pay;
            LastPay = pay;
            return pay;
        }

        public string Objective()
        {
            if (Day >= 7) return "DNES PŘIJEDE HYNEK. MÁŠ " + Money + " Z " + Debt + " GROŠŮ.";
            string s = "SPLAŤ " + Debt + " GROŠŮ DO 7. DNE (MÁŠ " + Money + ").";
            if (ReadySacks > 0) s += " VYDEJ HOTOVOU MOUKU.";
            else if (PendingSacks > 0) s += " NAMELI ZAKÁZKY.";
            else if (!GeneralToday && Segment < Segments - 1) s += " VEZMI ZAKÁZKY U MLÝNA.";
            return s;
        }
    }
}
