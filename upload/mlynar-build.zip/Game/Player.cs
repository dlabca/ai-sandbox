using System;
using Microsoft.Xna.Framework;

namespace Mlynar
{
    public sealed class Player
    {
        public const float EyeHeight = 1.6f;
        public const float Radius = 0.35f;

        public Vector3 Pos;
        public float Yaw;
        public float Pitch;

        public Player(Vector3 spawn)
        {
            Pos = spawn;
        }

        public Vector3 Eye
        {
            get { return Pos + new Vector3(0f, EyeHeight, 0f); }
        }

        public Vector3 ForwardFlat
        {
            get { return new Vector3(MathF.Sin(Yaw), 0f, MathF.Cos(Yaw)); }
        }

        public Vector3 Forward
        {
            get
            {
                float cp = MathF.Cos(Pitch);
                return new Vector3(MathF.Sin(Yaw) * cp, MathF.Sin(Pitch), MathF.Cos(Yaw) * cp);
            }
        }

        public void Step(Level lv, float dt, float vx, float vz)
        {
            float nx = Pos.X + vx * dt;
            float nz = Pos.Z + vz * dt;
            lv.ResolveHorizontal(ref nx, ref nz, Radius);
            Pos.X = nx;
            Pos.Z = nz;
            Pos.Y = lv.GroundY(nx, nz);
        }
    }
}
