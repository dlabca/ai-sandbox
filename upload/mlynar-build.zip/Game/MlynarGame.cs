using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Mlynar
{
    public class MlynarGame : Game
    {
        private readonly GraphicsDeviceManager graphics;
        private SpriteBatch spriteBatch;
        private Texture2D pixel;
        private BasicEffect effect;
        private Hud hud;

        private Level level;
        private Player player;
        private readonly GameState state = new GameState();
        private readonly Controls controls = new Controls();
        private readonly MeshBuilder dyn = new MeshBuilder();

        // dialog
        private Node cur;
        private readonly List<Choice> vis = new List<Choice>();
        private readonly List<string> labels = new List<string>();
        private string curText = "";
        private readonly Rectangle[] choiceRects = new Rectangle[8];

        private string message = "";
        private float messageTimer;
        private string prompt = "";
        private string promptId;
        private int screenW = 1280, screenH = 720;

        private Vector3 skyCur = new Vector3(172f, 205f, 235f);
        private Vector3 tintCur = new Vector3(1f, 0.96f, 0.9f);

        private static readonly Vector3[] SkyTargets =
        {
            new Vector3(172f, 205f, 235f), new Vector3(140f, 195f, 240f), new Vector3(236f, 200f, 150f), new Vector3(58f, 66f, 110f)
        };

        private static readonly Vector3[] TintTargets =
        {
            new Vector3(1f, 0.96f, 0.9f), new Vector3(1f, 1f, 1f), new Vector3(1f, 0.88f, 0.74f), new Vector3(0.5f, 0.55f, 0.8f)
        };

        public MlynarGame()
        {
            graphics = new GraphicsDeviceManager(this);
            graphics.IsFullScreen = true;
            graphics.SupportedOrientations = DisplayOrientation.LandscapeLeft | DisplayOrientation.LandscapeRight;
            graphics.GraphicsProfile = GraphicsProfile.Reach;
            graphics.PreferredDepthStencilFormat = DepthFormat.Depth24;
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            pixel = new Texture2D(GraphicsDevice, 1, 1);
            pixel.SetData(new[] { Color.White });

            effect = new BasicEffect(GraphicsDevice);
            effect.VertexColorEnabled = true;
            effect.LightingEnabled = false;
            effect.TextureEnabled = false;
            effect.FogEnabled = true;
            effect.FogStart = 55f;
            effect.FogEnd = 150f;
            effect.World = Matrix.Identity;

            GraphicsDevice.DeviceReset += delegate
            {
                try { pixel.SetData(new[] { Color.White }); }
                catch (Exception) { }
            };

            hud = new Hud(spriteBatch, pixel);

            level = new Level();
            level.Build(77);
            player = new Player(level.Spawn);
            player.Yaw = -2.2f;

            skyCur = SkyTargets[0];
            tintCur = TintTargets[0];
            OpenNode("intro1");
        }

        private void Say(string s)
        {
            message = s;
            messageTimer = 3f;
        }

        // ================================================================== dialog

        private void OpenNode(string id)
        {
            Node n;
            if (!Story.Nodes.TryGetValue(id, out n))
            {
                cur = null;
                return;
            }
            if (id == "intro1" && level != null)
            {
                player.Pos = level.Spawn;
                player.Yaw = -2.2f;
            }
            cur = n;
            if (n.OnEnter != null) n.OnEnter(state);
            Refresh();
        }

        private void Refresh()
        {
            vis.Clear();
            labels.Clear();
            curText = cur.Text(state);
            for (int i = 0; i < cur.Choices.Count; i++)
            {
                Choice c = cur.Choices[i];
                if (c.Cond != null && !c.Cond(state)) continue;
                vis.Add(c);
                labels.Add(c.GetLabel(state));
            }
            if (vis.Count == 0) labels.Add("Dál");
        }

        private void Choose(int i)
        {
            if (cur == null) return;
            if (vis.Count == 0)
            {
                CloseDialogue();
                return;
            }
            if (i < 0 || i >= vis.Count) return;
            Choice c = vis[i];
            if (c.Fx != null) c.Fx(state);
            string next = c.GetNext(state);
            if (string.IsNullOrEmpty(next)) CloseDialogue();
            else OpenNode(next);
        }

        private void CloseDialogue()
        {
            cur = null;
            if (!string.IsNullOrEmpty(state.Message))
            {
                Say(state.Message);
                state.Message = "";
            }
            if (state.PendingSleep)
            {
                state.PendingSleep = false;
                DoSleep();
            }
        }

        private void DoSleep()
        {
            if (state.Day == 6)
            {
                OpenNode("storm");
                return;
            }
            state.NextDay();
            player.Pos = level.Spawn;
            string id = Story.MorningNode(state.Day);
            if (id != null) OpenNode(id);
        }

        // ================================================================== update

        protected override void Update(GameTime gameTime)
        {
            float dt = (float)gameTime.ElapsedGameTime.TotalSeconds;
            if (dt > 0.05f) dt = 0.05f;

            screenW = GraphicsDevice.Viewport.Width;
            screenH = GraphicsDevice.Viewport.Height;

            bool modal = cur != null;
            controls.Update(screenW, screenH, modal);

            if (messageTimer > 0f) messageTimer -= dt;

            if (modal)
            {
                int n = Math.Max(1, vis.Count);
                Rectangle panel, textRect;
                Hud.DialogueLayout(screenW, screenH, n, out panel, out textRect, choiceRects);
                for (int t = 0; t < controls.Taps.Count && cur != null; t++)
                {
                    Point tap = controls.Taps[t];
                    for (int i = 0; i < n; i++)
                    {
                        if (choiceRects[i].Contains(tap))
                        {
                            Choose(i);
                            break;
                        }
                    }
                }
                if (controls.KeyChoice >= 0 && cur != null && controls.KeyChoice < n) Choose(controls.KeyChoice);
            }
            else
            {
                UpdateWorld(dt);
            }

            level.Update(dt, state, player.Pos);

            int seg = Math.Min(GameState.Segments - 1, state.Segment);
            float k = MathHelper.Clamp(dt * 1.5f, 0f, 1f);
            skyCur = skyCur + (SkyTargets[seg] - skyCur) * k;
            tintCur = tintCur + (TintTargets[seg] - tintCur) * k;

            base.Update(gameTime);
        }

        private void UpdateWorld(float dt)
        {
            player.Yaw -= controls.Look.X * 0.0045f;
            player.Pitch = MathHelper.Clamp(player.Pitch - controls.Look.Y * 0.0045f, -1.2f, 1.2f);

            Vector3 fwd = player.ForwardFlat;
            Vector3 right = Vector3.Cross(fwd, Vector3.Up);
            Vector3 wish = right * controls.Move.X + fwd * controls.Move.Y;
            float len = wish.Length();
            if (len > 1f) wish = wish / len;
            const float speed = 3.6f;
            player.Step(level, dt, wish.X * speed, wish.Z * speed);

            string id, name;
            Vector3 at;
            if (level.FindUse(player.Pos, fwd, state, out id, out name, out at))
            {
                promptId = id;
                prompt = name;
            }
            else
            {
                promptId = null;
                prompt = "";
            }

            if (controls.JournalPressed)
            {
                OpenNode("journal");
                return;
            }
            if (controls.UsePressed && promptId != null)
            {
                OpenNode(Story.Entry(promptId, state));
            }
        }

        // ================================================================== kresleni

        private void DrawMesh(VertexPositionColor[] arr, int count)
        {
            if (count < 3) return;
            effect.CurrentTechnique.Passes[0].Apply();
            GraphicsDevice.DrawUserPrimitives(PrimitiveType.TriangleList, arr, 0, count / 3);
        }

        protected override void Draw(GameTime gameTime)
        {
            Color sky = new Color((int)skyCur.X, (int)skyCur.Y, (int)skyCur.Z);
            GraphicsDevice.Clear(sky);

            GraphicsDevice.BlendState = BlendState.Opaque;
            GraphicsDevice.DepthStencilState = DepthStencilState.Default;
            GraphicsDevice.RasterizerState = RasterizerState.CullNone;

            Vector3 eye = player.Eye;
            Vector3 dir = player.Forward;
            effect.FogColor = sky.ToVector3();
            effect.DiffuseColor = tintCur;
            effect.View = Matrix.CreateLookAt(eye, eye + dir, Vector3.Up);
            effect.Projection = Matrix.CreatePerspectiveFieldOfView(
                MathHelper.ToRadians(70f), GraphicsDevice.Viewport.AspectRatio, 0.1f, 300f);

            for (int cx = 0; cx < Terrain.ChunkCount; cx++)
                for (int cz = 0; cz < Terrain.ChunkCount; cz++)
                {
                    ChunkMesh c = level.Chunks[cx, cz];
                    Vector3 v = c.Center - eye;
                    if (Vector3.Dot(v, dir) < -35f) continue;
                    if (v.LengthSquared() > 200f * 200f) continue;
                    DrawMesh(c.Verts, c.Count);
                }

            DrawMesh(level.Scene, level.SceneCount);

            dyn.Clear();
            level.BuildDynamic(dyn, state);
            DrawMesh(dyn.V, dyn.Count);

            GraphicsDevice.DepthStencilState = DepthStencilState.None;
            spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.PointClamp,
                DepthStencilState.None, RasterizerState.CullNone);
            if (cur == null)
            {
                float alpha = messageTimer > 0f ? messageTimer : 0f;
                hud.DrawWorld(screenW, screenH, controls, state, prompt, state.Objective(), message, alpha, promptId != null);
            }
            else
            {
                int n = Math.Max(1, vis.Count);
                Rectangle panel, textRect;
                Hud.DialogueLayout(screenW, screenH, n, out panel, out textRect, choiceRects);
                hud.DrawDialogue(screenW, screenH, cur.Speaker, curText, labels, choiceRects, panel, textRect);
            }
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
