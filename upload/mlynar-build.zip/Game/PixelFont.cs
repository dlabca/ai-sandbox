using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Mlynar
{
    /// <summary>Maly bitmapovy font 5x7 (velka pismena + ceska diakritika) kresleny obdelniky - zadny Content.</summary>
    public static class PixelFont
    {
        public static readonly Dictionary<char, string[]> Glyphs = new Dictionary<char, string[]>
        {
            [' '] = new[] { ".....", ".....", ".....", ".....", ".....", ".....", "....." },
            ['A'] = new[] { ".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#" },
            ['B'] = new[] { "####.", "#...#", "#...#", "####.", "#...#", "#...#", "####." },
            ['C'] = new[] { ".####", "#....", "#....", "#....", "#....", "#....", ".####" },
            ['D'] = new[] { "####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####." },
            ['E'] = new[] { "#####", "#....", "#....", "####.", "#....", "#....", "#####" },
            ['F'] = new[] { "#####", "#....", "#....", "####.", "#....", "#....", "#...." },
            ['G'] = new[] { ".####", "#....", "#....", "#..##", "#...#", "#...#", ".####" },
            ['H'] = new[] { "#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#" },
            ['I'] = new[] { "#####", "..#..", "..#..", "..#..", "..#..", "..#..", "#####" },
            ['J'] = new[] { "..###", "...#.", "...#.", "...#.", "...#.", "#..#.", ".##.." },
            ['K'] = new[] { "#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#" },
            ['L'] = new[] { "#....", "#....", "#....", "#....", "#....", "#....", "#####" },
            ['M'] = new[] { "#...#", "##.##", "#.#.#", "#.#.#", "#...#", "#...#", "#...#" },
            ['N'] = new[] { "#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#", "#...#" },
            ['O'] = new[] { ".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###." },
            ['P'] = new[] { "####.", "#...#", "#...#", "####.", "#....", "#....", "#...." },
            ['Q'] = new[] { ".###.", "#...#", "#...#", "#...#", "#.#.#", "#..#.", ".##.#" },
            ['R'] = new[] { "####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#" },
            ['S'] = new[] { ".####", "#....", "#....", ".###.", "....#", "....#", "####." },
            ['T'] = new[] { "#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#.." },
            ['U'] = new[] { "#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###." },
            ['V'] = new[] { "#...#", "#...#", "#...#", "#...#", "#...#", ".#.#.", "..#.." },
            ['W'] = new[] { "#...#", "#...#", "#...#", "#.#.#", "#.#.#", "##.##", "#...#" },
            ['X'] = new[] { "#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#" },
            ['Y'] = new[] { "#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#.." },
            ['Z'] = new[] { "#####", "....#", "...#.", "..#..", ".#...", "#....", "#####" },
            ['0'] = new[] { ".###.", "#...#", "#..##", "#.#.#", "##..#", "#...#", ".###." },
            ['1'] = new[] { "..#..", ".##..", "..#..", "..#..", "..#..", "..#..", ".###." },
            ['2'] = new[] { ".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####" },
            ['3'] = new[] { "####.", "....#", "....#", ".###.", "....#", "....#", "####." },
            ['4'] = new[] { "...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#." },
            ['5'] = new[] { "#####", "#....", "####.", "....#", "....#", "#...#", ".###." },
            ['6'] = new[] { ".###.", "#....", "#....", "####.", "#...#", "#...#", ".###." },
            ['7'] = new[] { "#####", "....#", "...#.", "..#..", ".#...", ".#...", ".#..." },
            ['8'] = new[] { ".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###." },
            ['9'] = new[] { ".###.", "#...#", "#...#", ".####", "....#", "....#", ".###." },
            [':'] = new[] { ".....", "..#..", "..#..", ".....", "..#..", "..#..", "....." },
            ['.'] = new[] { ".....", ".....", ".....", ".....", ".....", "..##.", "..##." },
            [','] = new[] { ".....", ".....", ".....", ".....", ".....", "..#..", ".#..." },
            [';'] = new[] { ".....", "..#..", ".....", ".....", "..#..", "..#..", ".#..." },
            ['-'] = new[] { ".....", ".....", ".....", "#####", ".....", ".....", "....." },
            ['+'] = new[] { ".....", "..#..", "..#..", "#####", "..#..", "..#..", "....." },
            ['/'] = new[] { "....#", "....#", "...#.", "..#..", ".#...", "#....", "#...." },
            ['!'] = new[] { "..#..", "..#..", "..#..", "..#..", "..#..", ".....", "..#.." },
            ['?'] = new[] { ".###.", "#...#", "....#", "...#.", "..#..", ".....", "..#.." },
            ['>'] = new[] { "#....", ".#...", "..#..", "...#.", "..#..", ".#...", "#...." },
            ['('] = new[] { "...#.", "..#..", ".#...", ".#...", ".#...", "..#..", "...#." },
            [')'] = new[] { ".#...", "..#..", "...#.", "...#.", "...#.", "..#..", ".#..." },
            ['"'] = new[] { ".#.#.", ".#.#.", ".....", ".....", ".....", ".....", "....." },
            ['\''] = new[] { "..#..", "..#..", ".....", ".....", ".....", ".....", "....." },
            ['='] = new[] { ".....", ".....", "#####", ".....", "#####", ".....", "....." }
        };

        // diakritika: (zakladni pismeno, 1 = carka, 2 = hacek, 3 = krouzek)
        private static readonly Dictionary<char, KeyValuePair<char, int>> Accents = new Dictionary<char, KeyValuePair<char, int>>
        {
            ['Á'] = new KeyValuePair<char, int>('A', 1),
            ['É'] = new KeyValuePair<char, int>('E', 1),
            ['Í'] = new KeyValuePair<char, int>('I', 1),
            ['Ó'] = new KeyValuePair<char, int>('O', 1),
            ['Ú'] = new KeyValuePair<char, int>('U', 1),
            ['Ý'] = new KeyValuePair<char, int>('Y', 1),
            ['Č'] = new KeyValuePair<char, int>('C', 2),
            ['Ď'] = new KeyValuePair<char, int>('D', 2),
            ['Ě'] = new KeyValuePair<char, int>('E', 2),
            ['Ň'] = new KeyValuePair<char, int>('N', 2),
            ['Ř'] = new KeyValuePair<char, int>('R', 2),
            ['Š'] = new KeyValuePair<char, int>('S', 2),
            ['Ť'] = new KeyValuePair<char, int>('T', 2),
            ['Ž'] = new KeyValuePair<char, int>('Z', 2),
            ['Ů'] = new KeyValuePair<char, int>('U', 3)
        };

        private static readonly string[][] AccentRows =
        {
            new string[0],
            new[] { "...#.", "..#.." },
            new[] { ".#.#.", "..#.." },
            new[] { ".##..", ".##.." }
        };

        public static bool HasGlyph(char ch)
        {
            ch = char.ToUpperInvariant(ch);
            return Glyphs.ContainsKey(ch) || Accents.ContainsKey(ch);
        }

        public static int Width(string text, int scale)
        {
            if (string.IsNullOrEmpty(text)) return 0;
            return text.Length * 6 * scale - scale;
        }

        public static int Height(int scale)
        {
            return 7 * scale;
        }

        /// <summary>Vyska radku textu vcetne mista na diakritiku.</summary>
        public static int LineHeight(int scale)
        {
            return 10 * scale;
        }

        public static List<string> Wrap(string text, int maxWidth, int scale)
        {
            List<string> lines = new List<string>();
            int maxChars = System.Math.Max(4, (maxWidth + scale) / (6 * scale));
            string[] paragraphs = text.Split('\n');
            for (int p = 0; p < paragraphs.Length; p++)
            {
                string[] words = paragraphs[p].Split(' ');
                string cur = "";
                for (int i = 0; i < words.Length; i++)
                {
                    string w = words[i];
                    if (cur.Length == 0) cur = w;
                    else if (cur.Length + 1 + w.Length <= maxChars) cur += " " + w;
                    else
                    {
                        lines.Add(cur);
                        cur = w;
                    }
                }
                lines.Add(cur);
            }
            return lines;
        }

        private static void Cells(SpriteBatch sb, Texture2D px, string[] g, int rowOffset, int cx, int y, int scale, Color color)
        {
            for (int row = 0; row < g.Length; row++)
            {
                string r = g[row];
                int col = 0;
                while (col < 5)
                {
                    if (r[col] == '#')
                    {
                        int start = col;
                        while (col < 5 && r[col] == '#') col++;
                        sb.Draw(px, new Rectangle(cx + start * scale, y + (row + rowOffset) * scale, (col - start) * scale, scale), color);
                    }
                    else
                    {
                        col++;
                    }
                }
            }
        }

        public static void Draw(SpriteBatch sb, Texture2D px, string text, int x, int y, int scale, Color color)
        {
            int cx = x;
            for (int i = 0; i < text.Length; i++)
            {
                char ch = char.ToUpperInvariant(text[i]);
                int accent = 0;
                KeyValuePair<char, int> acc;
                if (Accents.TryGetValue(ch, out acc))
                {
                    ch = acc.Key;
                    accent = acc.Value;
                }
                string[] g;
                if (Glyphs.TryGetValue(ch, out g))
                {
                    Cells(sb, px, g, 0, cx, y, scale, color);
                    if (accent > 0) Cells(sb, px, AccentRows[accent], -2, cx, y, scale, color);
                }
                cx += 6 * scale;
            }
        }
    }
}
