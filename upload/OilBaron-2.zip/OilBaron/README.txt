OIL BARON - ropna hra v duchu zanru Turmoil (vlastni kod, bez assetu).

Rok = jedno kolo (120 s): pronajmi pozemek na aukci, postav vez, vrtej a tahni potrubi,
olej jde do sila a vozy ho vozi ke kupcum LEFT / RIGHT (ceny kolisaji, plyn je zvysi).
Po roce: akciova aukce mesta. Kdo ma 50 % akcii, je starosta.

Ovladani (mys / dotyk):
- Vez / Dowser: tlacitko, pak klik na sloupec
- klik na hlavu vrtu = vyber, klik do zeme = smer vrtani, klik na potrubi = odbocka (po upgradu)
- Space = pauza, 1/2/3 = rychlost
Hra se uklada automaticky v mestecku.
