using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Input.Touch;

namespace OilBaron
{
    public class Meta
    {
        public int Year = 1;
        public float Cash = 1500;
        public int TDowse, TDrill, TRock, THeat, TPipe, TBranch, TSilo, TWagonSize, THorse, TWag, TGas;
        public int[] Shares = new int[3];
    }

    class Drill { public int HX, HY, LX, LY, Dir, Rig; public float Prog; public bool Done, Blocked; }
    class Wagon { public int State, Buyer; public float Load, T; }
    class Parcel { public int Rich, Hint, Price; public bool Taken; }

    enum Phase { Town, Parcels, Auction, Dig, Summary, Shares, Over }
    enum Tool { Steer, Rig, Dowse }

    public class Game1 : Game
    {
        const int W = 30, H = 16, CS = 32, GY = 128, PX = 960;
        const float YearLen = 120f;

        GraphicsDeviceManager gfx; SpriteBatch sb; Texture2D px;
        Random rnd = new Random();
        MouseState prevMs; KeyboardState prevKb;
        Vector2 mouse, off; float sc = 1; Matrix view = Matrix.Identity;
        bool click; float anim, clock;
        List<string> log = new List<string>();

        Meta meta = new Meta(); Phase phase = Phase.Town; Tool tool = Tool.Steer;
        float Cash { get { return meta.Cash; } set { meta.Cash = value; } }

        // dig
        byte[,] Ty = new byte[W, H]; float[,] Amt = new float[W, H];
        bool[,] Pipe = new bool[W, H], Known = new bool[W, H]; int[,] PRig = new int[W, H];
        List<Drill> drills = new List<Drill>(); List<Wagon> wagons = new List<Wagon>(); List<int> rigX = new List<int>();
        int sel = -1, speed = 1, dest = 2; bool hold;
        float t, silo, spilled, earned, costs, gasTimer, histT, spillFlash;
        float[] walk = new float[2], sat = { 1, 1 };
        List<float>[] hist = { new List<float>(), new List<float>() };
        static readonly int[] DX = { 0, -1, 1, 0 }, DY = { 1, 0, 0, -1 };
        static readonly float[] Dist = { 5f, 8f };
        static readonly string[] BNames = { "LEFT INC", "RIGHT INC" };
        static readonly string[] Owners = { "TY", "SMITH OIL", "TEXAS JACK" };

        // town / auctions
        Parcel[] parcels = new Parcel[3]; int aIdx, aLeader; float aBid, aTimer, aRivalCd; float[] rv = new float[2];
        int offer, ppp; int[] gain = new int[2];
        string overMsg = ""; bool won; float sumNet; int hoverUp = -1;

        static readonly string[] UpName = { "Dowser", "Vrtak", "Skalni hlava", "Ohrev (led)", "Sirsi potrubi", "Vetveni", "Silo", "Vetsi vozy", "Rychlejsi kone", "Vice vozu", "Plyn. sber" };
        static readonly int[] UpMax = { 3, 4, 2, 1, 4, 3, 5, 4, 4, 4, 2 };
        static readonly int[] UpCost = { 300, 400, 500, 700, 400, 500, 350, 350, 350, 450, 300 };
        static readonly string[] UpDesc = {
            "Vetsi dosah dowseru a odhalovani kolem vrtu",
            "Vrtak kope rychleji (+30% za uroven)",
            "Rychle vrtani skalou (bez nej 3x pomaleji)",
            "Umozni vrtat ledem (bez nej vrt stoji)",
            "Vetsi prutok oleje do sila",
            "Odbocky z potrubi: vice vrtu na vez",
            "Vetsi silo = min. rozlevani a lepsi casovani",
            "Vetsi vozy: vic oleje na jednu cestu",
            "Rychlejsi kone: kratsi cesty ke kupcum",
            "Dalsi vuz do flotily",
            "Plyn zvysi cenu oleje o vic a na delsi dobu"
        };

        ref int Lvl(int k)
        {
            switch (k)
            {
                case 0: return ref meta.TDowse;
                case 1: return ref meta.TDrill;
                case 2: return ref meta.TRock;
                case 3: return ref meta.THeat;
                case 4: return ref meta.TPipe;
                case 5: return ref meta.TBranch;
                case 6: return ref meta.TSilo;
                case 7: return ref meta.TWagonSize;
                case 8: return ref meta.THorse;
                case 9: return ref meta.TWag;
                default: return ref meta.TGas;
            }
        }

        public Game1()
        {
            gfx = new GraphicsDeviceManager(this) { PreferredBackBufferWidth = 1280, PreferredBackBufferHeight = 720 };
#if ANDROID
            gfx.IsFullScreen = true;
            gfx.SupportedOrientations = DisplayOrientation.LandscapeLeft | DisplayOrientation.LandscapeRight;
#endif
            IsMouseVisible = true;
            Window.AllowUserResizing = true;
        }

        protected override void LoadContent()
        {
            sb = new SpriteBatch(GraphicsDevice);
            px = new Texture2D(GraphicsDevice, 1, 1);
            px.SetData(new[] { Color.White });
            LoadMeta();
            Msg("Vitej v mestecku, podnikatel.");
        }

        // ------------------------------------------------------------ persistence
        string SavePath { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "oilbaron2.json"); } }
        void SaveMeta()
        {
            try { File.WriteAllText(SavePath, JsonSerializer.Serialize(meta, new JsonSerializerOptions { IncludeFields = true })); } catch { }
        }
        void LoadMeta()
        {
            try
            {
                var m = JsonSerializer.Deserialize<Meta>(File.ReadAllText(SavePath), new JsonSerializerOptions { IncludeFields = true });
                if (m != null && m.Shares != null && m.Shares.Length == 3) meta = m;
            }
            catch { meta = new Meta(); }
        }

        void Msg(string m) { log.Add(m); if (log.Count > 4) log.RemoveAt(0); }

        // ------------------------------------------------------------ economy
        float SiloCap() { return 60 + 120 * meta.TSilo; }
        float WagonCap() { return 40 * (1 + 0.5f * meta.TWagonSize); }
        float Price(int b)
        {
            float p = 12f + 5f * MathF.Sin(clock * 0.1f + b * 3.14159f) + walk[b];
            float gas = gasTimer > 0 ? 0.25f + 0.1f * meta.TGas : 0f;
            return MathF.Max(3f, p * (1 + gas) * sat[b]);
        }

        // ------------------------------------------------------------ world gen
        void Blob(int cx, int cy, float r, byte type)
        {
            for (int dx = -3; dx <= 3; dx++)
                for (int dy = -3; dy <= 3; dy++)
                {
                    int x = cx + dx, y = cy + dy;
                    if (x < 0 || y < 0 || x >= W || y >= H) continue;
                    if (dx * dx + dy * dy <= r * r) Ty[x, y] = type;
                }
        }

        void GenWorld(int rich)
        {
            for (int x = 0; x < W; x++)
                for (int y = 0; y < H; y++) { Ty[x, y] = 0; Amt[x, y] = 0; Pipe[x, y] = false; Known[x, y] = y < 2; PRig[x, y] = -1; }
            for (int x = 0; x < W; x++)
                for (int y = 0; y < H; y++)
                    if (rnd.NextDouble() < 0.03 + 0.018 * y) Ty[x, y] = 1;
            for (int k = 0; k < 3; k++) Blob(rnd.Next(W), 3 + rnd.Next(H - 4), 1.2f + (float)rnd.NextDouble(), 1);
            for (int k = 0; k < 3; k++) Blob(rnd.Next(W), 6 + rnd.Next(H - 7), 1.5f + (float)rnd.NextDouble() * 1.2f, 2);
            int nc = 1 + rich + rnd.Next(2);
            for (int k = 0; k < nc; k++)
            {
                int cx = 2 + rnd.Next(W - 4), cy = 5 + rnd.Next(H - 6); float cr = 1.1f + (float)rnd.NextDouble() * 1.2f;
                for (int dx = -3; dx <= 3; dx++)
                    for (int dy = -3; dy <= 3; dy++)
                    {
                        int x = cx + dx, y = cy + dy;
                        if (x < 0 || y < 0 || x >= W || y >= H) continue;
                        if (dx * dx + dy * dy <= cr * cr * (0.8f + 0.5f * (float)rnd.NextDouble())) { Ty[x, y] = 3; Amt[x, y] = 60 + rnd.Next(80); }
                    }
                if (rnd.NextDouble() < 0.6)
                {
                    int gy = Math.Max(2, cy - 3), n = 1 + rnd.Next(3);
                    for (int j = 0; j < n; j++)
                    {
                        int gx = cx + rnd.Next(-2, 3);
                        if (gx >= 0 && gx < W && Ty[gx, gy] != 3) Ty[gx, gy] = 4;
                    }
                }
            }
        }

        void StartDig(int rich)
        {
            GenWorld(rich);
            drills.Clear(); rigX.Clear(); wagons.Clear();
            for (int i = 0; i <= meta.TWag; i++) wagons.Add(new Wagon());
            t = 0; silo = 0; spilled = 0; earned = 0; costs = 0; gasTimer = 0; histT = 0; spillFlash = 0;
            sat[0] = sat[1] = 1; hist[0].Clear(); hist[1].Clear();
            sel = -1; speed = 1; tool = Tool.Steer; hold = false;
            phase = Phase.Dig;
            Msg("Postav vez (tlacitko Vez) a vrtej dolu.");
        }

        void Reveal(int cx, int cy, int r)
        {
            for (int dx = -r; dx <= r; dx++)
                for (int dy = -r; dy <= r; dy++)
                {
                    int x = cx + dx, y = cy + dy;
                    if (x < 0 || y < 0 || x >= W || y >= H) continue;
                    if (dx * dx + dy * dy <= r * r) Known[x, y] = true;
                }
        }

        // ------------------------------------------------------------ drilling
        void SetTarget(Drill h, int d)
        {
            h.Dir = d; h.HX = h.LX + DX[d]; h.HY = h.LY + DY[d]; h.Prog = 0; h.Done = false; h.Blocked = false;
        }

        void Finish(Drill h)
        {
            int x = h.HX, y = h.HY;
            if (!Pipe[x, y]) { Pipe[x, y] = true; PRig[x, y] = h.Rig; }
            if (Ty[x, y] == 4) { gasTimer += 20f; Ty[x, y] = 0; Msg("Plyn! Cena oleje roste."); }
            else if (Ty[x, y] != 3) Ty[x, y] = 0;
            Reveal(x, y, 2 + meta.TDowse);
            h.LX = x; h.LY = y; h.Prog = 0;
            int nx = x + DX[h.Dir], ny = y + DY[h.Dir];
            if (nx < 0 || nx >= W || ny < 0 || ny >= H) { h.Done = true; return; }
            h.HX = nx; h.HY = ny;
        }

        void SteerTo(Drill h, int cx, int cy)
        {
            int dx = cx - h.LX, dy = cy - h.LY;
            if (dx == 0 && dy == 0) return;
            int d = Math.Abs(dx) > Math.Abs(dy) ? (dx < 0 ? 1 : 2) : (dy > 0 ? 0 : 3);
            int nx = h.LX + DX[d], ny = h.LY + DY[d];
            if (nx < 0 || nx >= W || ny < 0 || ny >= H) return;
            if (!h.Done && d == h.Dir) return;
            SetTarget(h, d);
        }

        void Branch(int cx, int cy)
        {
            if (meta.TBranch <= 0) { Msg("Vetveni potrubi koupis v mestecku."); return; }
            if (drills.Count >= rigX.Count * (1 + meta.TBranch)) { Msg("Dosazen maximalni pocet vrtu."); return; }
            if (Cash < 100) { Msg("Odbocka stoji $100."); return; }
            for (int d = 0; d < 3; d++)
            {
                int nx = cx + DX[d], ny = cy + DY[d];
                if (nx < 0 || nx >= W || ny < 0 || ny >= H || Pipe[nx, ny]) continue;
                var h = new Drill { LX = cx, LY = cy, Rig = PRig[cx, cy] };
                SetTarget(h, d);
                drills.Add(h); sel = drills.Count - 1; Cash -= 100; costs += 100; Msg("Nova odbocka.");
                return;
            }
            Msg("Odsud se odbocit neda.");
        }

        void Deliver(Wagon w)
        {
            int b = w.Buyer; float rev = w.Load * Price(b);
            Cash += rev; earned += rev;
            sat[b] = MathF.Max(0.6f, sat[b] - w.Load / 500f);
            Msg(BNames[b] + ": +$" + (int)rev + " (" + (int)w.Load + " bbl)");
            w.Load = 0;
        }

        void DigTick(float dt)
        {
            t += dt; clock += dt;
            for (int b = 0; b < 2; b++)
            {
                walk[b] = MathHelper.Clamp(walk[b] + ((float)rnd.NextDouble() - 0.5f) * 1.5f * dt, -3f, 3f);
                sat[b] += (1 - sat[b]) * 0.15f * dt;
            }
            if (gasTimer > 0) gasTimer -= dt;
            if (spillFlash > 0) spillFlash -= dt;
            histT += dt;
            if (histT >= 1f)
            {
                histT -= 1f;
                for (int b = 0; b < 2; b++) { hist[b].Add(Price(b)); if (hist[b].Count > 40) hist[b].RemoveAt(0); }
            }

            // vrty
            float spd = 1.2f * (1 + 0.3f * meta.TDrill);
            foreach (var h in drills)
            {
                int guard = 0;
                while (!h.Done && Pipe[h.HX, h.HY] && guard++ < 60) Finish(h);
                if (h.Done) { h.Blocked = false; continue; }
                int ty = Ty[h.HX, h.HY];
                if (ty == 2 && meta.THeat == 0) { h.Blocked = true; continue; }
                if (Cash < 4) { h.Blocked = true; continue; }
                h.Blocked = false;
                float f = ty == 1 ? (3f - meta.TRock) : ty == 2 ? 2f : 1f;
                h.Prog += dt * spd / f;
                if (h.Prog >= 1f) { Cash -= 4; costs += 4; Finish(h); }
            }

            // prutok oleje
            if (rigX.Count > 0)
            {
                float cellRate = 1.5f * (1 + 0.3f * meta.TPipe), cap = 6f * (1 + 0.6f * meta.TPipe);
                float[] dem = new float[rigX.Count];
                var srcs = new List<(int x, int y, int r)>();
                for (int x = 0; x < W; x++)
                    for (int y = 0; y < H; y++)
                    {
                        if (Ty[x, y] != 3 || Amt[x, y] <= 0) continue;
                        int r = -1;
                        if (Pipe[x, y]) r = PRig[x, y];
                        else
                            for (int d = 0; d < 4; d++)
                            {
                                int nx = x + DX[d], ny = y + DY[d];
                                if (nx >= 0 && nx < W && ny >= 0 && ny < H && Pipe[nx, ny]) { r = PRig[nx, ny]; break; }
                            }
                        if (r >= 0) { srcs.Add((x, y, r)); dem[r] += cellRate; }
                    }
                float scap = SiloCap();
                foreach (var s in srcs)
                {
                    float k = dem[s.r] > cap ? cap / dem[s.r] : 1f;
                    float amt = MathF.Min(Amt[s.x, s.y], cellRate * k * dt);
                    Amt[s.x, s.y] -= amt;
                    float added = MathF.Max(0f, MathF.Min(amt, scap - silo));
                    silo += added;
                    float sp = amt - added;
                    if (sp > 0.001f) { spilled += sp; Cash -= sp * 0.8f; costs += sp * 0.8f; spillFlash = 1f; }
                }
            }

            // vozy
            float wc = WagonCap(), hs = 1 + 0.25f * meta.THorse;
            foreach (var w in wagons)
            {
                if (w.State == 0)
                {
                    if (!hold && silo >= MathF.Min(wc, 20f))
                    {
                        w.Load = MathF.Min(silo, wc); silo -= w.Load;
                        w.Buyer = dest == 2 ? (Price(0) >= Price(1) ? 0 : 1) : dest;
                        w.State = 1; w.T = 0;
                    }
                }
                else
                {
                    w.T += dt * hs;
                    if (w.T >= Dist[w.Buyer])
                    {
                        if (w.State == 1) { Deliver(w); w.State = 2; w.T = 0; }
                        else { w.State = 0; w.T = 0; }
                    }
                }
            }

            if (t >= YearLen) EndYear();
        }

        void EndYear()
        {
            foreach (var w in wagons) if (w.State == 1) Deliver(w);
            float left = silo * (Price(0) + Price(1)) / 2f * 0.5f;
            Cash += left; earned += left; silo = 0;
            sumNet = earned - costs;
            drills.Clear(); speed = 0; phase = Phase.Summary;
        }

        // ------------------------------------------------------------ town flow
        void GenParcels()
        {
            for (int i = 0; i < 3; i++)
            {
                int r = rnd.Next(4);
                parcels[i] = new Parcel { Rich = r, Hint = Math.Clamp(r + rnd.Next(-1, 2), 0, 3), Price = 100 + 130 * r + meta.Year * 25 + rnd.Next(60) };
            }
        }

        void StartAuction(int i)
        {
            aIdx = i; var p = parcels[i];
            aBid = p.Price; aLeader = 0; aTimer = 4f; aRivalCd = 1f;
            for (int r = 0; r < 2; r++) rv[r] = p.Price * (1.15f + (float)rnd.NextDouble()) * (0.8f + 0.15f * p.Rich);
            phase = Phase.Auction;
        }

        void AuctionTick(float dt)
        {
            aTimer -= dt; aRivalCd -= dt;
            if (aRivalCd <= 0)
            {
                aRivalCd = 0.5f + (float)rnd.NextDouble() * 0.9f;
                int r = rnd.Next(2); float nb = (int)(aBid * 1.1f + 5);
                if (aLeader != 2 + r && nb <= rv[r] && rnd.NextDouble() < 0.7)
                {
                    aBid = nb; aLeader = 2 + r; aTimer = 2.5f; Msg(Owners[1 + r] + " prihazuje $" + (int)nb);
                }
            }
            if (aTimer > 0) return;
            var p = parcels[aIdx];
            if (aLeader == 2 || aLeader == 3)
            {
                p.Taken = true; Msg(Owners[aLeader - 1] + " vyhral aukci."); phase = Phase.Parcels;
                if (parcels.All(q => q.Taken)) GenParcels();
                return;
            }
            if (Cash < aBid) { p.Taken = true; Msg("Nemas dost penez na pronajem."); phase = Phase.Parcels; return; }
            Cash -= aBid; Msg("Pozemek pronajat za $" + (int)aBid);
            StartDig(p.Rich);
        }

        void EnterShares()
        {
            int sum = meta.Shares[0] + meta.Shares[1] + meta.Shares[2];
            offer = Math.Min(20, 100 - sum);
            ppp = (int)(100 * (1 + 0.5f * meta.Year));
            gain[0] = Math.Min(offer, 2 + rnd.Next(5)); offer -= gain[0];
            gain[1] = Math.Min(offer, 2 + rnd.Next(5)); offer -= gain[1];
            meta.Shares[1] += gain[0]; meta.Shares[2] += gain[1];
            phase = Phase.Shares;
        }

        void FinishShares()
        {
            int sum = meta.Shares[0] + meta.Shares[1] + meta.Shares[2];
            int mx = Math.Max(meta.Shares[0], Math.Max(meta.Shares[1], meta.Shares[2]));
            if (mx >= 50 || sum >= 100)
            {
                int w = meta.Shares[0] == mx ? 0 : (meta.Shares[1] == mx ? 1 : 2);
                won = w == 0;
                overMsg = won ? "Jsi novy starosta mesta!" : Owners[w] + " se stal starostou.";
                phase = Phase.Over; return;
            }
            meta.Year++;
            if (Cash < 100) { won = false; overMsg = "Zkrachoval jsi."; phase = Phase.Over; return; }
            SaveMeta(); phase = Phase.Town;
        }

        // ------------------------------------------------------------ update
        void CalcView()
        {
            int w = GraphicsDevice.PresentationParameters.BackBufferWidth, h = GraphicsDevice.PresentationParameters.BackBufferHeight;
            sc = MathF.Min(w / 1280f, h / 720f);
            off = new Vector2((w - 1280 * sc) / 2, (h - 720 * sc) / 2);
            view = Matrix.CreateScale(sc) * Matrix.CreateTranslation(off.X, off.Y, 0);
        }

        bool Pressed(KeyboardState k, Keys key) { return k.IsKeyDown(key) && prevKb.IsKeyUp(key); }

        protected override void Update(GameTime gt)
        {
            var ms = Mouse.GetState(); var kb = Keyboard.GetState();
            bool newClick = ms.LeftButton == ButtonState.Pressed && prevMs.LeftButton == ButtonState.Released;
            prevMs = ms;
            Vector2 pos = new Vector2(ms.X, ms.Y);
            foreach (var tp in TouchPanel.GetState())
            {
                pos = tp.Position;
                if (tp.State == TouchLocationState.Pressed) newClick = true;
                break;
            }
            CalcView();
            mouse = (pos - off) / sc;
            if (newClick) click = true;
            float real = MathF.Min((float)gt.ElapsedGameTime.TotalSeconds, 0.1f);
            anim += real;
            if (phase == Phase.Dig)
            {
                if (Pressed(kb, Keys.Space)) speed = speed == 0 ? 1 : 0;
                if (Pressed(kb, Keys.D1)) speed = 1;
                if (Pressed(kb, Keys.D2)) speed = 2;
                if (Pressed(kb, Keys.D3)) speed = 3;
                if (speed > 0) DigTick(real * speed);
            }
            if (phase == Phase.Auction) AuctionTick(real);
#if !ANDROID
            if (Pressed(kb, Keys.Escape)) Exit();
#endif
            prevKb = kb;
            base.Update(gt);
        }

        // ------------------------------------------------------------ draw helpers
        void Fill(Rectangle r, Color c) { sb.Draw(px, r, c); }
        void Border(Rectangle r, Color c, int th)
        {
            Fill(new Rectangle(r.X, r.Y, r.Width, th), c); Fill(new Rectangle(r.X, r.Bottom - th, r.Width, th), c);
            Fill(new Rectangle(r.X, r.Y, th, r.Height), c); Fill(new Rectangle(r.Right - th, r.Y, th, r.Height), c);
        }
        void Line(Vector2 a, Vector2 b, float th, Color c)
        {
            Vector2 d = b - a;
            sb.Draw(px, a, null, c, MathF.Atan2(d.Y, d.X), new Vector2(0, 0.5f), new Vector2(d.Length(), th), SpriteEffects.None, 0);
        }

        const string From = "ÁČĎÉĚÍŇÓŘŠŤÚŮÝŽ", To = "ACDEEINORSTUUYZ";
        static string Fix(string s)
        {
            var a = new char[s.Length];
            for (int i = 0; i < a.Length; i++)
            {
                char ch = char.ToUpperInvariant(s[i]); int k = From.IndexOf(ch);
                a[i] = k >= 0 ? To[k] : ch;
            }
            return new string(a);
        }
        static int TextW(string s, int scale) { return s.Length * 6 * scale - scale; }

        void Text(string s, float x, float y, int scale, Color c)
        {
            s = Fix(s); int cx = (int)x;
            foreach (char ch in s)
            {
                byte[] g;
                if (Font.TryGetValue(ch, out g))
                    for (int r = 0; r < 7; r++)
                        for (int b = 0; b < 5; b++)
                            if (((g[r] >> (4 - b)) & 1) != 0)
                                sb.Draw(px, new Rectangle(cx + b * scale, (int)y + r * scale, scale, scale), c);
                cx += 6 * scale;
            }
        }
        void TextC(string s, float cx, float y, int scale, Color c) { Text(s, cx - TextW(Fix(s), scale) / 2f, y, scale, c); }

        bool Btn(Rectangle r, string t, bool en = true, bool active = false)
        {
            bool hot = en && r.Contains(mouse);
            Color bg = !en ? new Color(60, 55, 50) : active ? new Color(220, 170, 50) : hot ? new Color(205, 140, 60) : new Color(140, 90, 40);
            Fill(r, bg); Border(r, Color.Black, 2);
            string f = Fix(t); int s = TextW(f, 2) <= r.Width - 6 ? 2 : 1;
            Text(t, r.X + (r.Width - TextW(f, s)) / 2, r.Y + (r.Height - 7 * s) / 2, s, en ? (active ? Color.Black : Color.White) : Color.Gray);
            if (hot && click) { click = false; return true; }
            return false;
        }

        void DrawBg()
        {
            for (int y = 0; y < 720; y += 8) Fill(new Rectangle(0, y, 1280, 8), Color.Lerp(new Color(95, 150, 215), new Color(240, 205, 150), y / 720f));
        }

        void Derrick(float cx, float baseY, Color c, bool working)
        {
            Line(new Vector2(cx - 11, baseY), new Vector2(cx, baseY - 40), 3, c);
            Line(new Vector2(cx + 11, baseY), new Vector2(cx, baseY - 40), 3, c);
            Line(new Vector2(cx - 7, baseY - 16), new Vector2(cx + 7, baseY - 16), 2, c);
            float k = working ? MathF.Sin(anim * 5) * 3 : 0;
            Line(new Vector2(cx - 14, baseY - 40 + k), new Vector2(cx + 14, baseY - 40 - k), 3, c);
        }

        // ------------------------------------------------------------ draw
        protected override void Draw(GameTime gt)
        {
            GraphicsDevice.Clear(new Color(20, 14, 10));
            sb.Begin(samplerState: SamplerState.PointClamp, transformMatrix: view);
            switch (phase)
            {
                case Phase.Town: DrawTown(); break;
                case Phase.Parcels: DrawParcels(); break;
                case Phase.Auction: DrawAuction(); break;
                case Phase.Dig: DrawDig(); break;
                case Phase.Summary: DrawSummary(); break;
                case Phase.Shares: DrawShares(); break;
                case Phase.Over: DrawOver(); break;
            }
            sb.End();
            click = false;
            base.Draw(gt);
        }

        void DrawHouses()
        {
            Fill(new Rectangle(0, 600, 1280, 120), new Color(90, 70, 45));
            for (int i = 0; i < 10; i++)
            {
                int h = 50 + ((i * 37) % 5) * 14;
                Fill(new Rectangle(30 + i * 125, 600 - h, 90, h), new Color(140 - i * 4, 95, 70));
                Fill(new Rectangle(30 + i * 125 - 4, 600 - h - 8, 98, 8), new Color(90, 50, 40));
                Fill(new Rectangle(30 + i * 125 + 15, 600 - h + 12, 18, 18), new Color(250, 225, 140));
                Fill(new Rectangle(30 + i * 125 + 55, 600 - h + 12, 18, 18), new Color(250, 225, 140));
            }
        }

        void DrawTown()
        {
            DrawBg(); DrawHouses();
            Fill(new Rectangle(10, 10, 1260, 530), new Color(20, 14, 10, 215));
            Text("Mestecko", 30, 20, 3, new Color(255, 210, 120));
            Text("Rok " + meta.Year + "   Hotovost $" + (int)Cash, 30, 56, 2, Color.White);
            Text("Akcie mesta: TY " + meta.Shares[0] + "%  SMITH OIL " + meta.Shares[1] + "%  TEXAS JACK " + meta.Shares[2] + "%  (cil 50%)", 30, 80, 2, new Color(255, 210, 120));
            hoverUp = -1;
            for (int k = 0; k < UpName.Length; k++)
            {
                int col = k < 6 ? 0 : 1, row = k < 6 ? k : k - 6;
                var r = new Rectangle(30 + col * 440, 120 + row * 56, 420, 48);
                int lv = Lvl(k), cost = UpCost[k] * (lv + 1);
                if (r.Contains(mouse)) hoverUp = k;
                string label = lv >= UpMax[k] ? UpName[k] + " MAX" : UpName[k] + " L" + lv + "/" + UpMax[k] + " $" + cost;
                if (Btn(r, label, lv < UpMax[k]))
                {
                    if (Cash >= cost) { Cash -= cost; Lvl(k)++; SaveMeta(); Msg(UpName[k] + " vylepseno."); }
                    else Msg("Nedostatek penez!");
                }
            }
            if (hoverUp >= 0) Text(UpDesc[hoverUp], 470, 470, 2, Color.White);
            else Text("Vylepseni kupujes v mestecku. Nenech si penize na pronajem pozemku.", 30, 470, 2, Color.Gray);
            if (Btn(new Rectangle(30, 480, 420, 50), "Pronajmout pozemek >")) { GenParcels(); phase = Phase.Parcels; }
            if (Btn(new Rectangle(1090, 16, 160, 36), "Nova hra")) { meta = new Meta(); SaveMeta(); Msg("Nova hra."); }
            DrawLog(30, 548, 1220);
        }

        void DrawLog(int x, int y, int w)
        {
            for (int i = 0; i < log.Count; i++)
            {
                int a = 130 + 125 * (i + 1) / log.Count;
                Text(log[i], x, y + i * 18, 2, new Color(a, a, a));
            }
        }

        string Stars(int hint) { return new string('*', hint + 1).PadRight(4, '-'); }

        void DrawParcels()
        {
            DrawBg(); DrawHouses();
            Fill(new Rectangle(10, 10, 1260, 560), new Color(20, 14, 10, 215));
            Text("Mestska aukce pozemku", 30, 20, 3, new Color(255, 210, 120));
            Text("Vyber pozemek k pronajmu na rok " + meta.Year + ". Hotovost $" + (int)Cash, 30, 60, 2, Color.White);
            for (int i = 0; i < 3; i++)
            {
                var p = parcels[i]; var r = new Rectangle(30 + i * 410, 120, 370, 330);
                Fill(r, p.Taken ? new Color(50, 44, 40) : new Color(90, 62, 40)); Border(r, Color.Black, 2);
                Text("Pozemek " + (char)('A' + i), r.X + 16, r.Y + 16, 3, Color.White);
                if (p.Taken) { Text("Odebral rival", r.X + 16, r.Y + 80, 2, Color.Gray); continue; }
                Text("Odhad zasob:", r.X + 16, r.Y + 80, 2, Color.White);
                Text(Stars(p.Hint), r.X + 16, r.Y + 106, 3, new Color(255, 210, 60));
                Text("Odhad nemusi sedet.", r.X + 16, r.Y + 150, 1, Color.Gray);
                Text("Vychozi cena $" + p.Price, r.X + 16, r.Y + 190, 2, Color.White);
                if (Btn(new Rectangle(r.X + 16, r.Y + 250, 338, 50), "Licitovat", Cash >= p.Price)) StartAuction(i);
            }
            if (Btn(new Rectangle(30, 480, 200, 44), "< Zpet")) phase = Phase.Town;
            DrawLog(30, 540, 1220);
        }

        void DrawAuction()
        {
            DrawBg(); DrawHouses();
            Fill(new Rectangle(10, 10, 1260, 560), new Color(20, 14, 10, 215));
            var p = parcels[aIdx];
            Text("Aukce - pozemek " + (char)('A' + aIdx), 30, 20, 3, new Color(255, 210, 120));
            Text("Odhad zasob: " + Stars(p.Hint), 30, 70, 2, Color.White);
            Text("Aktualni nabidka $" + (int)aBid, 30, 110, 3, Color.White);
            Text("Vede: " + (aLeader == 0 ? "nikdo" : Owners[aLeader - 1]), 30, 150, 2, aLeader == 1 ? new Color(80, 220, 100) : Color.OrangeRed);
            Text("Souperi: SMITH OIL, TEXAS JACK", 30, 180, 2, Color.Gray);
            Fill(new Rectangle(30, 220, 600, 16), new Color(50, 40, 30));
            Fill(new Rectangle(30, 220, (int)(600 * MathHelper.Clamp(aTimer / 2.5f, 0, 1)), 16), new Color(230, 170, 40));
            Text("Kdyz nikdo neprihodi, drazba konci.", 30, 244, 1, Color.Gray);
            int nb = aLeader == 0 ? (int)aBid : (int)(aBid * 1.1f + 5);
            if (Btn(new Rectangle(30, 280, 400, 60), "Prihodit $" + nb, aLeader != 1 && Cash >= nb))
            { aBid = nb; aLeader = 1; aTimer = 2.5f; }
            Text("Hotovost $" + (int)Cash, 30, 360, 2, Color.White);
            DrawLog(30, 540, 1220);
        }

        void DrawSummary()
        {
            DrawBg(); DrawHouses();
            Fill(new Rectangle(10, 10, 1260, 560), new Color(20, 14, 10, 215));
            Text("Konec roku " + meta.Year, 30, 20, 3, new Color(255, 210, 120));
            Text("Prodej oleje      $" + (int)earned, 30, 80, 3, Color.White);
            Text("Naklady           $" + (int)costs, 30, 120, 3, Color.OrangeRed);
            Text("Cisty zisk        $" + (int)sumNet, 30, 160, 3, sumNet >= 0 ? new Color(80, 220, 100) : Color.OrangeRed);
            Text("Rozlito           " + (int)spilled + " bbl", 30, 200, 3, Color.White);
            Text("Hotovost          $" + (int)Cash, 30, 240, 3, new Color(255, 210, 120));
            if (Btn(new Rectangle(30, 320, 420, 56), "Akciova aukce >")) EnterShares();
        }

        void DrawShares()
        {
            DrawBg(); DrawHouses();
            Fill(new Rectangle(10, 10, 1260, 560), new Color(20, 14, 10, 215));
            Text("Akciova aukce mesta", 30, 20, 3, new Color(255, 210, 120));
            Text("Souperi koupili: SMITH OIL +" + gain[0] + "%  TEXAS JACK +" + gain[1] + "%", 30, 70, 2, Color.OrangeRed);
            Text("V nabidce zbyva " + offer + "%   cena 1% = $" + ppp, 30, 100, 2, Color.White);
            Text("Akcie: TY " + meta.Shares[0] + "%   SMITH OIL " + meta.Shares[1] + "%   TEXAS JACK " + meta.Shares[2] + "%", 30, 130, 2, Color.White);
            Text("Kdo ma 50%, je starosta. Hotovost $" + (int)Cash, 30, 160, 2, new Color(255, 210, 120));
            if (Btn(new Rectangle(30, 220, 300, 50), "Koupit 1% $" + ppp, offer >= 1 && Cash >= ppp)) { Cash -= ppp; meta.Shares[0]++; offer--; }
            if (Btn(new Rectangle(340, 220, 300, 50), "Koupit 5% $" + 5 * ppp, offer >= 5 && Cash >= 5 * ppp)) { Cash -= 5 * ppp; meta.Shares[0] += 5; offer -= 5; }
            if (Btn(new Rectangle(30, 300, 420, 56), "Dalsi rok >")) FinishShares();
        }

        void DrawOver()
        {
            DrawBg(); DrawHouses();
            Fill(new Rectangle(0, 0, 1280, 720), new Color(0, 0, 0, 170));
            TextC(won ? "Vitezstvi!" : "Konec hry", 640, 200, 6, won ? new Color(255, 215, 0) : Color.OrangeRed);
            TextC(overMsg, 640, 300, 3, Color.White);
            TextC("Rok " + meta.Year, 640, 350, 2, Color.Gray);
            if (Btn(new Rectangle(540, 420, 200, 50), "Nova hra")) { meta = new Meta(); SaveMeta(); phase = Phase.Town; }
        }

        // ------------------------------------------------------------ dig screen
        Color CellColor(int x, int y)
        {
            int n = ((x * 73 + y * 151) % 5) * 3;
            if (Pipe[x, y]) return new Color(58 - n / 2, 40 - n / 2, 28);
            if (!Known[x, y]) return new Color(92 - n, 64 - n, 40 - n);
            switch (Ty[x, y])
            {
                case 1: return new Color(105 - n, 105 - n, 112 - n);
                case 2: return new Color(150 - n, 205 - n, 235 - n);
                case 3:
                    {
                        if (Amt[x, y] <= 0.5f) return new Color(70, 58, 48);
                        float a = MathHelper.Clamp(Amt[x, y] / 140f, 0f, 1f);
                        return Color.Lerp(new Color(70, 60, 50), new Color(15, 15, 20), 0.4f + 0.6f * a);
                    }
                case 4: return new Color(90 - n, 150 - n, 95 - n);
                default: return new Color(124 - n, 88 - n, 54 - n);
            }
        }

        void DrawSurface()
        {
            for (int y = 0; y < GY; y += 4) Fill(new Rectangle(0, y, PX, 4), Color.Lerp(new Color(95, 150, 215), new Color(240, 205, 150), y / (float)GY));
            for (int dy = -16; dy <= 16; dy += 2)
            {
                int w = (int)(2 * MathF.Sqrt(256 - dy * dy));
                Fill(new Rectangle(790 - w / 2, 40 + dy, w, 2), new Color(255, 225, 120));
            }
            for (int x = 0; x < PX; x += 8)
            {
                int h = 18 + (int)(10 * MathF.Sin(x * 0.02f) + 8 * MathF.Sin(x * 0.05f + 1));
                Fill(new Rectangle(x, GY - h, 8, h), new Color(70, 110, 60));
            }
            Fill(new Rectangle(0, GY - 6, PX, 6), new Color(110, 80, 50));
            // kupci
            Fill(new Rectangle(8, GY - 46, 84, 46), new Color(150, 60, 50)); Fill(new Rectangle(4, GY - 54, 92, 8), new Color(90, 40, 35));
            Fill(new Rectangle(868, GY - 46, 84, 46), new Color(50, 80, 150)); Fill(new Rectangle(864, GY - 54, 92, 8), new Color(35, 50, 90));
            Text("LEFT INC", 12, GY - 30, 1, Color.White); Text("RIGHT INC", 872, GY - 30, 1, Color.White);
            Text("$" + Price(0).ToString("0.0"), 10, GY - 74, 2, Color.White);
            Text("$" + Price(1).ToString("0.0"), 870, GY - 74, 2, Color.White);
            // silo + depo
            Fill(new Rectangle(455, GY - 60, 36, 60), new Color(150, 150, 155));
            int fh = (int)(56 * MathHelper.Clamp(silo / SiloCap(), 0f, 1f));
            Fill(new Rectangle(458, GY - 4 - fh, 30, fh), spillFlash > 0 ? Color.OrangeRed : new Color(25, 25, 30));
            Fill(new Rectangle(495, GY - 26, 40, 26), new Color(120, 80, 50)); Fill(new Rectangle(491, GY - 32, 48, 6), new Color(80, 50, 35));
            // vezove
            foreach (int rx in rigX) Derrick(rx * CS + 16, GY - 6, new Color(210, 180, 100), true);
            // vozy
            for (int i = 0; i < wagons.Count; i++)
            {
                var w = wagons[i]; float p = 0;
                if (w.State == 1) p = w.T / Dist[w.Buyer]; else if (w.State == 2) p = 1 - w.T / Dist[w.Buyer];
                float x = w.State == 0 ? 540 + i * 4 : (w.Buyer == 0 ? 470 - 370 * p : 470 + 390 * p);
                Fill(new Rectangle((int)x - 11, GY - 20, 22, 9), new Color(130, 85, 45));
                Fill(new Rectangle((int)x - 8, GY - 12, 5, 5), Color.Black); Fill(new Rectangle((int)x + 3, GY - 12, 5, 5), Color.Black);
                if (w.Load > 0) Fill(new Rectangle((int)x - 9, GY - 24, 18, 4), new Color(15, 15, 20));
            }
        }

        void DrawGrid()
        {
            for (int x = 0; x < W; x++)
                for (int y = 0; y < H; y++)
                    Fill(new Rectangle(x * CS, GY + y * CS, CS, CS), CellColor(x, y));
            Color pc = new Color(205, 205, 215);
            for (int x = 0; x < W; x++)
                for (int y = 0; y < H; y++)
                {
                    if (!Pipe[x, y]) continue;
                    int ox = x * CS, oy = GY + y * CS;
                    Fill(new Rectangle(ox + 12, oy + 12, 8, 8), pc);
                    if (x + 1 < W && Pipe[x + 1, y]) Fill(new Rectangle(ox + 20, oy + 12, 24, 8), pc);
                    if (y + 1 < H && Pipe[x, y + 1]) Fill(new Rectangle(ox + 12, oy + 20, 8, 24), pc);
                    if (y == 0) Fill(new Rectangle(ox + 12, oy - 6, 8, 18), pc);
                }
            for (int i = 0; i < drills.Count; i++)
            {
                var h = drills[i];
                int cx = h.Done ? h.LX : h.HX, cy = h.Done ? h.LY : h.HY;
                if (cy < 0) continue;
                int ox = cx * CS, oy = GY + cy * CS;
                if (h.Done) Fill(new Rectangle(ox + 10, oy + 10, 12, 12), new Color(80, 220, 230));
                else
                {
                    int pulse = (int)(3 * MathF.Sin(anim * 10));
                    Fill(new Rectangle(ox + 8 - pulse / 2, oy + 8 - pulse / 2, 16 + pulse, 16 + pulse), h.Blocked ? Color.Red : Color.Orange);
                    if (h.Blocked) Text("!", ox + 13, oy + 9, 2, Color.White);
                }
                if (i == sel) Border(new Rectangle(ox, oy, CS, CS), Color.White, 2);
            }
        }

        void DrawPanel()
        {
            int X = 970;
            Fill(new Rectangle(960, 0, 320, 720), new Color(28, 20, 15));
            int month = Math.Min(12, (int)(t / (YearLen / 12f)) + 1);
            Text("Rok " + meta.Year + "  Mesic " + month + "/12", X, 8, 2, Color.White);
            Fill(new Rectangle(X, 30, 300, 10), new Color(50, 40, 30));
            Fill(new Rectangle(X, 30, (int)(300 * MathHelper.Clamp(t / YearLen, 0, 1)), 10), new Color(230, 170, 40));
            Text("Hotovost $" + (int)Cash, X, 48, 2, new Color(255, 210, 120));
            Text("Silo " + (int)silo + "/" + (int)SiloCap(), X, 72, 2, spillFlash > 0 ? Color.OrangeRed : Color.White);
            Fill(new Rectangle(X, 92, 300, 10), new Color(50, 40, 30));
            Fill(new Rectangle(X, 92, (int)(300 * MathHelper.Clamp(silo / SiloCap(), 0, 1)), 10), spillFlash > 0 ? Color.OrangeRed : new Color(230, 170, 40));
            for (int b = 0; b < 2; b++)
            {
                int y = 110 + b * 76; Fill(new Rectangle(X, y, 300, 70), new Color(50, 38, 28));
                Text(BNames[b], X + 6, y + 6, 2, Color.White);
                float pr = Price(b), prev = hist[b].Count > 2 ? hist[b][hist[b].Count - 2] : pr;
                Text("$" + pr.ToString("0.0") + (pr >= prev ? " +" : " -"), X + 6, y + 30, 2, pr >= prev ? new Color(80, 220, 100) : Color.OrangeRed);
                Text("cesta " + (int)(Dist[b] / (1 + 0.25f * meta.THorse)) + "s", X + 6, y + 52, 1, Color.Gray);
                if (hist[b].Count > 1)
                {
                    float mn = hist[b].Min() - 0.5f, mx = hist[b].Max() + 0.5f;
                    for (int i = 1; i < hist[b].Count; i++)
                    {
                        Vector2 a = new Vector2(X + 130 + (i - 1) * 160f / 39, y + 64 - (hist[b][i - 1] - mn) / (mx - mn) * 56);
                        Vector2 c = new Vector2(X + 130 + i * 160f / 39, y + 64 - (hist[b][i] - mn) / (mx - mn) * 56);
                        Line(a, c, 2, new Color(255, 210, 80));
                    }
                }
            }
            if (gasTimer > 0) Text("Plyn! +" + (int)((0.25f + 0.1f * meta.TGas) * 100) + "% " + (int)gasTimer + "s", X, 266, 2, new Color(120, 230, 120));
            for (int i = 0; i < 3; i++)
                if (Btn(new Rectangle(X + i * 102, 292, 96, 36), i == 0 ? "Left" : i == 1 ? "Right" : "Best", true, dest == i)) dest = i;
            if (Btn(new Rectangle(X, 336, 300, 36), hold ? "Drzim olej (klik)" : "Prodavam (klik)", true, hold)) hold = !hold;
            Text("Vozy " + wagons.Count + "  nosnost " + (int)WagonCap(), X, 380, 2, Color.White);
            if (Btn(new Rectangle(X, 404, 148, 40), "Vez $200", Cash >= 200, tool == Tool.Rig)) tool = tool == Tool.Rig ? Tool.Steer : Tool.Rig;
            if (Btn(new Rectangle(X + 152, 404, 148, 40), "Dowser $60", Cash >= 60, tool == Tool.Dowse)) tool = tool == Tool.Dowse ? Tool.Steer : Tool.Dowse;
            if (Btn(new Rectangle(X, 452, 300, 36), "Ukoncit rok")) EndYear();
            for (int i = 0; i < 4; i++)
                if (Btn(new Rectangle(X + i * 76, 496, 70, 36), i == 0 ? "||" : i + "x", true, speed == i)) speed = i;
            string[] hints = { "Vez: klik na sloupec povrchu", "Dowser: klik na sloupec", "Klik na hlavu vrtu = vyber", "Klik do zeme = smer vrtani", "Klik na potrubi = odbocka $100", "Rozlite silo = pokuta!" };
            for (int i = 0; i < hints.Length; i++) Text(hints[i], X, 548 + i * 14, 1, Color.Gray);
            if (spilled > 0) Text("Rozlito " + (int)spilled + " bbl", X, 640, 2, Color.OrangeRed);
        }

        void HandleWorldClick()
        {
            if (!click) return;
            if (mouse.X < 0 || mouse.X >= PX || mouse.Y < 0 || mouse.Y >= GY + H * CS) return;
            int cx = Math.Clamp((int)MathF.Floor(mouse.X / CS), 0, W - 1);
            int cy = (int)MathF.Floor((mouse.Y - GY) / CS);
            if (tool != Tool.Steer)
            {
                click = false;
                if (tool == Tool.Rig)
                {
                    if (rigX.Contains(cx)) Msg("Tady uz vez stoji.");
                    else if (Cash < 200) Msg("Nedostatek penez!");
                    else
                    {
                        Cash -= 200; costs += 200; rigX.Add(cx);
                        drills.Add(new Drill { HX = cx, HY = 0, LX = cx, LY = -1, Dir = 0, Rig = rigX.Count - 1 });
                        Reveal(cx, 0, 2 + meta.TDowse); sel = drills.Count - 1; Msg("Vez postavena. Vrt jede dolu.");
                    }
                }
                else if (Cash >= 60)
                {
                    Cash -= 60; costs += 60;
                    int half = 1 + meta.TDowse;
                    for (int x = cx - half; x <= cx + half; x++)
                        for (int y = 0; y < H; y++)
                            if (x >= 0 && x < W) Known[x, y] = true;
                    Msg("Dowser odhalil sloupec.");
                }
                tool = Tool.Steer;
                return;
            }
            if (cy < 0) return;
            click = false;
            for (int i = 0; i < drills.Count; i++)
            {
                var h = drills[i];
                int hx = h.Done ? h.LX : h.HX, hy = h.Done ? h.LY : h.HY;
                if (hx == cx && hy == cy) { sel = i; return; }
            }
            if (Pipe[cx, cy]) { Branch(cx, cy); return; }
            if (sel >= 0 && sel < drills.Count) SteerTo(drills[sel], cx, cy);
            else if (drills.Count > 0) { sel = 0; SteerTo(drills[0], cx, cy); }
        }

        void DrawDig()
        {
            Fill(new Rectangle(0, 0, 1280, 720), new Color(20, 14, 10));
            DrawSurface(); DrawGrid();
            Fill(new Rectangle(0, GY + H * CS, PX, 720 - GY - H * CS), new Color(20, 14, 10));
            DrawLog(10, 650, PX);
            DrawPanel();
            HandleWorldClick();
        }

        // ------------------------------------------------------------ bitmap font
        static readonly Dictionary<char, byte[]> Font = BuildFont();
        static Dictionary<char, byte[]> BuildFont()
        {
            string[] d = {
                "A:0E,11,11,1F,11,11,11", "B:1E,11,11,1E,11,11,1E", "C:0E,11,10,10,10,11,0E", "D:1E,11,11,11,11,11,1E",
                "E:1F,10,10,1E,10,10,1F", "F:1F,10,10,1E,10,10,10", "G:0E,11,10,17,11,11,0F", "H:11,11,11,1F,11,11,11",
                "I:0E,04,04,04,04,04,0E", "J:07,02,02,02,02,12,0C", "K:11,12,14,18,14,12,11", "L:10,10,10,10,10,10,1F",
                "M:11,1B,15,15,11,11,11", "N:11,19,15,13,11,11,11", "O:0E,11,11,11,11,11,0E", "P:1E,11,11,1E,10,10,10",
                "Q:0E,11,11,11,15,12,0D", "R:1E,11,11,1E,14,12,11", "S:0F,10,10,0E,01,01,1E", "T:1F,04,04,04,04,04,04",
                "U:11,11,11,11,11,11,0E", "V:11,11,11,11,11,0A,04", "W:11,11,11,15,15,15,0A", "X:11,11,0A,04,0A,11,11",
                "Y:11,11,0A,04,04,04,04", "Z:1F,01,02,04,08,10,1F",
                "0:0E,11,13,15,19,11,0E", "1:04,0C,04,04,04,04,0E", "2:0E,11,01,02,04,08,1F", "3:1F,02,04,02,01,11,0E",
                "4:02,06,0A,12,1F,02,02", "5:1F,10,1E,01,01,11,0E", "6:06,08,10,1E,11,11,0E", "7:1F,01,02,04,08,08,08",
                "8:0E,11,11,0E,11,11,0E", "9:0E,11,11,0F,01,02,0C",
                ".:00,00,00,00,00,0C,0C", ",:00,00,00,00,0C,04,08", "::00,0C,0C,00,0C,0C,00", "-:00,00,00,1F,00,00,00",
                "+:00,04,04,1F,04,04,00", "/:01,02,02,04,08,08,10", "%:18,19,02,04,08,13,03", "!:04,04,04,04,04,00,04",
                "?:0E,11,01,02,04,00,04", "$:04,0F,14,0E,05,1E,04", "(:02,04,08,08,08,04,02", "):08,04,02,02,02,04,08",
                "|:04,04,04,04,04,04,04", "=:00,1F,00,1F,00,00,00", "*:00,0A,04,1F,04,0A,00",
                ">:08,04,02,01,02,04,08", "<:02,04,08,10,08,04,02", "_:00,00,00,00,00,00,1F"
            };
            var m = new Dictionary<char, byte[]>();
            m[' '] = new byte[7];
            foreach (var e in d)
            {
                var parts = e.Substring(2).Split(',');
                var b = new byte[7];
                for (int i = 0; i < 7; i++) b[i] = Convert.ToByte(parts[i], 16);
                m[e[0]] = b;
            }
            return m;
        }
    }
}
